# -*- coding: utf-8 -*-
"""
TSD10版 センサー箱（版3.1） Pico W 自動書き込み＆動作チェッカー
- 新品の Pico W（RPI-RP2 ドライブ）が挿さっていれば MicroPython (.uf2) を自動書き込み
- MicroPython の USB シリアルポート（VID=2E8A）を自動検出
- TSD10_センサー箱に入れる/ の 3ファイル（wifi_secret.py, main.py, app.mpy）を転送・サイズ検証
  （※ wifi_secret.py の中身は画面に一切表示しません。最大2つの Wi-Fi 登録に対応）
- 再起動後の出力を受け取り、A・B 両センサーが 35〜55 件/秒（実機標準 約42件/秒）出ているか＆状態ページ URL を判定表示
"""
import argparse
import base64
import ctypes
import os
import re
import shutil
import sys
import time

import serial
import serial.tools.list_ports

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
BOX_DIR = os.path.dirname(SRC_DIR)
DEPLOY_DIR = os.path.join(BOX_DIR, "TSD10_センサー箱に入れる")
UF2_CANDIDATES = (
    os.path.join(SRC_DIR, "firmware", "RPI_PICO_W-20241129-v1.24.1.uf2"),
    os.path.join(BOX_DIR, "新品PicoW用_MicroPython本体", "RPI_PICO_W-20241129-v1.24.1.uf2"),
)


def get_uf2_path():
    for p in UF2_CANDIDATES:
        if os.path.exists(p):
            return p
    return UF2_CANDIDATES[0]


def ensure_wifi_secret_ready(check_only=False):
    """配布ZIPのひな形（WIFI_SSID が空）のまま実行された場合、その場で入力して保存できるようにする"""
    p = os.path.join(DEPLOY_DIR, "wifi_secret.py")
    if not os.path.exists(p):
        if check_only:
            return False
    else:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        # WIFI_SSID に空でない値が入っていればそのまま使う（中身は一切表示しない）
        m = re.search(r'WIFI_SSID\s*=\s*["\']([^"\']+)["\']', txt)
        if m and m.group(1).strip() and "ここに" not in m.group(1):
            return True
        if check_only:
            return True
    print("\n📶 Wi-Fi 設定（wifi_secret.py）がまだ空欄です。接続する Wi-Fi を入力してください（最大2つ登録可）：")
    ssid = input("  ① 1つ目の Wi-Fi 名（SSID）: ").strip()
    pw = input("  ① 1つ目の Wi-Fi パスワード: ").strip()
    if not ssid:
        print("❌ Wi-Fi 名が空のため中止しました。")
        sys.exit(1)
    ssid2 = input("  ② 2つ目の Wi-Fi 名（お店/自宅など・不要なら Enter でスキップ）: ").strip()
    pw2 = input("  ② 2つ目の Wi-Fi パスワード: ").strip() if ssid2 else ""
    esc_s = ssid.replace("\\", "\\\\").replace('"', '\\"')
    esc_p = pw.replace("\\", "\\\\").replace('"', '\\"')
    esc_s2 = ssid2.replace("\\", "\\\\").replace('"', '\\"')
    esc_p2 = pw2.replace("\\", "\\\\").replace('"', '\\"')
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(
            f'# -*- coding: utf-8 -*-\n'
            f'WIFI_SSID = "{esc_s}"\nWIFI_PASS = "{esc_p}"\n'
            f'WIFI_SSID2 = "{esc_s2}"\nWIFI_PASS2 = "{esc_p2}"\n'
        )
    print("  → wifi_secret.py に保存しました！（あとから状態ページでも Wi-Fi 経由で変更・追加できます）")
    return True

FILES_TO_UPLOAD = (
    ("wifi_secret.py", True),   # (ファイル名, 機密ファイルフラグ)
    ("main.py", False),
    ("app.mpy", False),
)


def find_bootsel_drive():
    """BOOTSEL モード（RPI-RP2）でマウントされているドライブ文字を探す"""
    bitmask = ctypes.windll.kernel32.GetLogicalDrives()
    for i in range(26):
        if bitmask & (1 << i):
            drv = f"{chr(65 + i)}:\\"
            info_fn = os.path.join(drv, "INFO_UF2.TXT")
            if os.path.exists(info_fn):
                try:
                    with open(info_fn, "r", encoding="utf-8", errors="ignore") as f:
                        info = f.read()
                    return drv, info
                except OSError:
                    pass
    return None, ""


def find_pico_com_port():
    """Raspberry Pi Pico W (MicroPython USB Serial, VID=2E8A) の COM ポートを探す"""
    for p in serial.tools.list_ports.comports():
        hwid = (p.hwid or "").upper()
        if "VID:PID=2E8A:" in hwid:
            return p.device, p.description
    return None, ""


def flash_uf2_if_needed():
    drv, info = find_bootsel_drive()
    if not drv:
        return False
    print(f"\n[検出] 新品または BOOTSEL モードの Pico を検出しました ({drv})")
    if "RP2350" in info and "RPI-RP2" not in info:
        print("  ⚠️ Pico 2 W (RP2350) が検出されました。RP2040 用の UF2 は書き込めません。")
        print("  Thonny の右下から『MicroPython (Raspberry Pi Pico)』をインストールしてください。")
        sys.exit(1)
    uf2_path = get_uf2_path()
    if not os.path.exists(uf2_path):
        print(f"  ❌ MicroPython ファームウェアが見つかりません: {uf2_path}")
        sys.exit(1)
    dst = os.path.join(drv, os.path.basename(uf2_path))
    print(f"  → MicroPython 本体を書き込んでいます ({os.path.basename(uf2_path)}) ...")
    shutil.copyfile(uf2_path, dst)
    print("  → 書き込み完了！Pico W が再起動して COM ポートになるのを待っています...")
    for _ in range(30):
        time.sleep(0.5)
        port, _ = find_pico_com_port()
        if port:
            time.sleep(0.8)
            return True
    return True


def enter_raw_repl(ser):
    """実行中のプログラムを止めて MicroPython Raw REPL に入る"""
    ser.dtr = True
    ser.rts = True
    for _ in range(3):
        ser.write(b"\r\x03\x03")
        time.sleep(0.15)
    ser.reset_input_buffer()
    ser.write(b"\r\x01")
    buf = bytearray()
    t0 = time.time()
    while time.time() - t0 < 4.0:
        chunk = ser.read(ser.in_waiting or 1)
        if chunk:
            buf.extend(chunk)
            if b"raw REPL; CTRL-B to exit" in buf and buf.endswith(b">"):
                return
    raise RuntimeError(f"Raw REPL に入れませんでした (受信={bytes(buf[-120:])!r})")


def raw_exec(ser, code_str, timeout=15.0):
    """Raw REPL で Python コードを実行し (stdout, stderr) を返す"""
    ser.reset_input_buffer()
    payload = code_str.encode("utf-8")
    # バッファあふれ防止のため 256 バイトずつ送る
    for i in range(0, len(payload), 256):
        ser.write(payload[i:i + 256])
        time.sleep(0.005)
    ser.write(b"\x04")

    buf = bytearray()
    t0 = time.time()
    while time.time() - t0 < timeout:
        chunk = ser.read(ser.in_waiting or 1)
        if chunk:
            buf.extend(chunk)
            # 応答形式: OK<stdout>\x04<stderr>\x04>
            if buf.startswith(b"OK") and buf.count(b"\x04") >= 2 and buf.endswith(b">"):
                body = bytes(buf[2:-1])
                out_b, err_b = body.split(b"\x04", 2)[:2]
                err_s = err_b.decode("utf-8", errors="replace").strip()
                if err_s:
                    raise RuntimeError(f"Pico側エラー:\n{err_s}")
                return out_b.decode("utf-8", errors="replace")
    raise RuntimeError(f"Pico からの応答がタイムアウトしました (受信={bytes(buf[-120:])!r})")


def upload_file(ser, local_path, remote_name, is_secret=False):
    with open(local_path, "rb") as f:
        data = f.read()
    total = len(data)
    tmp_name = remote_name + ".tmp"
    label = f"{remote_name} (Wi-Fi設定・中身非表示)" if is_secret else f"{remote_name} ({total:,} bytes)"
    print(f"  → 転送中: {label} ...", end="", flush=True)

    raw_exec(ser, f"import ubinascii, os\n_f = open({tmp_name!r}, 'wb')\n")
    chunk_size = 768
    for i in range(0, total, chunk_size):
        b64 = base64.b64encode(data[i:i + chunk_size]).decode("ascii")
        raw_exec(ser, f"_f.write(ubinascii.a2b_base64('{b64}'))\n")
    out = raw_exec(
        ser,
        f"_f.close()\n"
        f"_sz = os.stat({tmp_name!r})[6]\n"
        f"assert _sz == {total}, (_sz, {total})\n"
        f"try:\n os.remove({remote_name!r})\nexcept OSError:\n pass\n"
        f"os.rename({tmp_name!r}, {remote_name!r})\n"
        f"print(_sz)\n",
    )
    assert int(out.strip()) == total
    print(" OK!")


def main():
    parser = argparse.ArgumentParser(description="TSD10版 センサー箱 Pico W 自動書き込み＆動作チェック")
    parser.add_argument("--wait", type=int, default=60, help="Pico W 接続待ち秒数")
    parser.add_argument("--check-only", action="store_true", help="ファイル確認のみ行って終了")
    args = parser.parse_args()

    print("============================================================")
    print("  入店チャイム センサー箱 TSD10版（版3.1・Wi-Fi 2件＆OTA対応）")
    print("  Pico W 自動書き込み ＆ センサー動作チェッカー")
    print("============================================================")

    for fn, _ in FILES_TO_UPLOAD:
        p = os.path.join(DEPLOY_DIR, fn)
        if not os.path.exists(p):
            print(f"❌ 書き込み用ファイルが見つかりません: {p}")
            sys.exit(1)
    if args.check_only:
        print("✅ 書き込み用ファイル一式（app.mpy / main.py / wifi_secret.py / UF2）準備OK！")
        return

    ensure_wifi_secret_ready(check_only=False)

    flash_uf2_if_needed()
    port, desc = find_pico_com_port()
    if not port:
        print(f"\n🔌 Pico W を micro-USB ケーブルでこのパソコンに挿してください（最大 {args.wait} 秒待機中）...")
        t0 = time.time()
        while time.time() - t0 < args.wait:
            flash_uf2_if_needed()
            port, desc = find_pico_com_port()
            if port:
                break
            time.sleep(0.5)
        if not port:
            print("\n❌ Pico W が見つかりませんでした。")
            print("   ・充電専用ケーブルではなく『通信できる micro-USB ケーブル』か確認してください。")
            print("   ・新品の Pico W でドライブが出ない場合は BOOTSEL ボタンを押しながら挿してください。")
            sys.exit(2)

    print(f"\n[接続] Pico W を検出しました: {port} ({desc})")
    try:
        ser = serial.Serial(port, baudrate=115200, timeout=0.5, write_timeout=2.0)
    except serial.SerialException as e:
        print(f"\n❌ {port} を開けませんでした: {e}")
        print("   ⚠️ Thonny など他のソフトが起動している場合は、閉じてからもう一度実行してください！")
        sys.exit(3)

    try:
        print("\n[1/3] Pico W を書き込みモードに切り替えています...")
        enter_raw_repl(ser)

        # 古い更新一時ファイルやロールバック印があれば掃除
        raw_exec(
            ser,
            "import os\n"
            "for _fn in ('app_ok.flag','app_new.mpy','app_prev.mpy','app_bad.mpy','crash.txt'):\n"
            " try:\n  os.remove(_fn)\n except OSError:\n  pass\n",
        )

        print("\n[2/3] TSD10版（版3.1）の 3 ファイルを転送しています...")
        for fn, is_sec in FILES_TO_UPLOAD:
            upload_file(ser, os.path.join(DEPLOY_DIR, fn), fn, is_secret=is_sec)

        print("\n[3/3] Pico W を起動して TSD10 センサー（A・B）の通信速度を測定しています（約8〜15秒）...")
        print("------------------------------------------------------------")
        # 通常REPLに戻してソフトリブート（Ctrl-B → Ctrl-D）
        ser.write(b"\x02")
        time.sleep(0.1)
        ser.reset_input_buffer()
        ser.write(b"\x04")

        diag_matches = []
        ip_found = None
        line_buf = ""
        t0 = time.time()
        while time.time() - t0 < 25.0:
            chunk = ser.read(ser.in_waiting or 1)
            if not chunk:
                continue
            txt = chunk.decode("utf-8", errors="replace")
            line_buf += txt
            while "\n" in line_buf:
                line, line_buf = line_buf.split("\n", 1)
                line_s = line.strip("\r ")
                if not line_s or line_s.startswith("MPY:"):
                    continue
                print("  Pico >", line_s)
                m_ip = re.search(r"http://(\d+\.\d+\.\d+\.\d+)/", line_s)
                if m_ip:
                    ip_found = m_ip.group(1)
                m_diag = re.search(
                    r"\[TSD10診断\]\s*A:(\d+)件/秒\(([^)]+)\)\s*\|\s*B:(\d+)件/秒\(([^)]+)\)\s*\|\s*IP:(\S+)",
                    line_s,
                )
                if m_diag:
                    diag_matches.append(
                        (
                            int(m_diag.group(1)),
                            m_diag.group(2),
                            int(m_diag.group(3)),
                            m_diag.group(4),
                            m_diag.group(5),
                        )
                    )
            # 2回目（5秒後）の安定した診断値を受け取ったら判定へ進む
            if len(diag_matches) >= 2:
                break

        print("------------------------------------------------------------")
        if diag_matches:
            hza, info_a, hzb, info_b, dip = diag_matches[-1]
            if dip and dip != "-":
                ip_found = dip
            ok_a = 35 <= hza <= 55
            ok_b = 35 <= hzb <= 55
            print("\n================== 【TSD10 動作診断結果】 ==================")
            print(f"  センサーA（ドア側・7番ピン） : {hza:2d} 件/秒  [{info_a}]  {'✅ 合格！' if ok_a else '⚠️ 要確認'}")
            print(f"  センサーB（店内側・17番ピン）: {hzb:2d} 件/秒  [{info_b}]  {'✅ 合格！' if ok_b else '⚠️ 要確認'}")
            if ip_found:
                print(f"  スマホ・PC 状態ページ URL    : http://{ip_found}/  （🧪 試験モード中）")
            print("============================================================")

            if ok_a and ok_b:
                print(f"\n🎉 大成功！A・B ともに {hza}〜{hzb} 件/秒（エラー0）でバッチリ通信できています！")
                print("   ・状態ページ http://" + (ip_found or "<IP>") + "/ の『Wi-Fi 設定』から2つ目のWi-Fi（お店/自宅）も登録できます。")
                print("   ・フタをパチンと閉じてハードウェア完成です！")
            else:
                print("\n✂️ 0件/秒（または少ない）側がある場合の手順：")
                if not ok_a:
                    print("   ・センサーA側：7番〜8番ピンの間にある『2.2kΩ』の足をニッパーで切ってみてください。")
                if not ok_b:
                    print("   ・センサーB側：17番〜18番ピンの間にある『2.2kΩ』の足をニッパーで切ってみてください。")
                print("   （※ 2.2kΩを切っても 0件/秒 の場合は、40番5V赤線・GND黒線・緑t線のはんだを確認）")
        else:
            print("\n⚠️ 診断行を時間内に取得できませんでした。上の『Pico >』の表示を確認してください。")
    finally:
        ser.close()


if __name__ == "__main__":
    main()
