# -*- coding: utf-8 -*-
# 入店チャイム センサー箱 TSD10版  Raspberry Pi Pico WH + PONO TSD10（dToF LiDAR、0.05〜10m）x2
# Pico には app.mpy（このファイルを mpy-cross で変換したもの）として入れる。main.py は起動役、Wi-Fi は wifi_secret.py
# 外部ドライバ（vl53l0x.py）は不要。Pico 標準の machine.UART だけで動作する。
# 外側(A・2°)→内側(B・25°)の順に通過したときだけチャイム（LAN経由）。B→A(退店)は無音でカウント。
# iPhone 等のブラウザで http://<このPicoのIP>/ を開くと状態ページが見られる。
# 必ず UTF-8（BOMなし）で保存すること。

APP_ID = "nyuten-sensor-tsd10"
APP_NAME = "センサー箱(TSD10)"
APP_TAG = "@@VER:3.1|2026-10-30 22:10@@"   # 版と作成日時（更新ページで表示。ここだけ書き換える）
# 3.1: ・Wi-Fi を2つまで登録＆周囲の電波スキャンで自動切替に対応（自宅とお店など。状態ページからWi-Fi経由で追加・変更でき、更新しても消えない）
#      ・前版(2.18)の全機能を総点検して完全統合：UART無応答時の自動再初期化(uart_recover)を追加、先鳴らし内訳の表示を追加
#      ・片方のセンサーだけ1.5秒以上遮られ続ける机上テスト中でも、状態ページ表示・Wi-Fi経由アップデート(OTA)が止まらないよう改善
#      ・実機 TSD10 の出力周期（約42件/秒）に合わせ、正常表示範囲を 35〜55件/秒 に調整し基準取得間隔を 25ms に最適化
# 3.0: センサーを VL53L0X×2 → PONO TSD10×2（UART 460800bps・50Hz・視野3°）に刷新。
#      ・UART受信バッファ1024バイト＋0x5Cヘッダ＆チェックサム検証＋1秒あたり正常件数/チェック失敗/65535回数の状態表示
#      ・細い光（3°）の腕振り・カバン途切れ対策として「空きの保持時間」（hold 既定140ms）と「連続反応回数」（streak 既定3回）を追加
#      ・65535（測距外）は人ありと決めつけず、直前の状態を最大200ms保ってから人なしに戻す安全設計
#      ・ループが100ms以上止まった後は、溜まった古いフレームを読み捨てて最新値のみ採用し判定の途中状態をリセット
#      ・現行の本番箱と並べて比較できるよう「試験モード」（testm 既定1：チャイム送信・音量同期を止め記録のみ、名前 nyuten-sensor2）を追加
#      ・測距上限を 8000mm に拡張し、通過記録（/trace）の距離単位を 25mm（最大6375mm）に見直し
VERSION, BUILD = APP_TAG[6:-2].split("|")

from machine import Pin, UART, PWM, Timer
import os, sys, time, machine

try:
    import network, urequests, ntptime, socket, json
    HAS_NET = True
except ImportError:
    HAS_NET = False

# ===== 設定 =====
# 2026-10-30 TSD10版（r4 ネジなし小型ケース）配線:
# センサーA（外側・ドア側 ←DOOR 2°）: UART1  RX=GP5(7番ピン)  TX=GP4(6番ピン・未接続)  GND=8番ピン
# センサーB（内側・店内側 B25  25°）: UART0  RX=GP13(17番ピン) TX=GP12(16番ピン・未接続) GND=18番ピン
# 電源: A・B とも VBUS 5V(40番ピン) ※3V3(36番)では動かない
PIN_BUZZER = 16
PIN_LED = "LED"

UART_CFG = ((1, 4, 5), (0, 12, 13))   # 物理0=A(UART1 GP4/GP5), 物理1=B(UART0 GP12/GP13)
UART_BAUD = 460800                    # TSD10 標準ボーレート（変更しない）
UART_RXBUF = 1024                     # 約5秒分の受信バッファ

WINDOW_MS = 1500       # 先に遮られた方から後の方までの許容時間（通過判定）
REFRACTORY_MS = 1200   # 判定後の不感時間
SAMPLE_MS = 5          # ループの休み（TSD10は待ち時間ゼロで読めるため 5ms＝秒間200周の高速応答）
CALIB_STEP_MS = 25     # 基準距離を取るときの間隔（実機42Hz＝約24ms周期の新しいフレームを確実に1回ずつ拾う）
STALL_RESET_MS = 100   # ループがこれ以上止まった後は古い受信分を捨てて判定の途中状態をリセット

DROP_MM = 250          # 基準距離からこれ以上縮んだら「人がいる」
HOLD_CLEAR_MS = 140    # 3.0: 「空き」がこの時間続いてから空いたとみなす（腕振り・カバンでの一瞬の途切れ対策）
HIT_STREAK = 3         # 3.0: 何フレーム連続で反応したら人とみなすか（50Hzで3回＝約40〜60ms。傘の先などを無視）
OOR_HOLD_MS = 200      # 3.0: 65535（測距外）が出たとき直前の状態を保つ上限 ms（超えたら人なしへ戻す）

GAP_MS = 700           # A が空いてから B が遮られるまでの許容
SHORT_LEAD_MS = 100    # 先に反応した側の「先行」がこれより短いときは、空いた順で確かめてから判定する
SIMUL_GAP_MS = 200     # 片方が一瞬反応して空いた直後に A・B が同時に反応したとき、先に反応した側を先とみなす許容
NO_TARGET_MM = 1700    # 向かいの壁が測れないときに使う仮の基準（スマホから変更可）
MIN_VALID_MM = 40      # これ未満は異常値として無視（TSD10仕様は50mm〜）
MAX_VALID_MM = 8000    # これ超は異常値として無視（Bが店内の奥の棚まで測れるよう 8000mm に拡張）
CALIB_SAMPLES = 60     # 起動時に基準距離を取る回数（約1.3秒。誰もいない状態で起動する）
RECALIB_S = 600        # 10分ごとに静止時の基準距離を取り直す

CHIME_MS = 350
PASSIVE_BUZZER = False
CHIME_HZ = 2000
LOCAL_BUZZER = False   # 本体のブザーを鳴らす場合 True。遠隔スピーカーのみなら False
QUIET_HOURS = []       # 日本時間で指定。例 [(20, 9)] = 20時〜翌9時は鳴らさない
TZ_OFFSET = 9 * 3600   # 日本時間（NTP は UTC で入るため）

WIFI_SSID = ""         # Wi-Fi 名とパスワードは wifi_secret.py または状態ページ（wifi_extra.json）に保存（更新しても消えない）
WIFI_PASS = ""
WIFI_SSID2 = ""        # 2つ目の Wi-Fi（お店と自宅など2か所登録用）
WIFI_PASS2 = ""
try:
    import wifi_secret as _ws
    WIFI_SSID = getattr(_ws, "WIFI_SSID", "") or ""
    WIFI_PASS = getattr(_ws, "WIFI_PASS", "") or ""
    WIFI_SSID2 = getattr(_ws, "WIFI_SSID2", "") or ""
    WIFI_PASS2 = getattr(_ws, "WIFI_PASS2", "") or ""
except ImportError:
    pass
WIFI_EXTRA_FILE = "wifi_extra.json"   # 状態ページからWi-Fi経由で追加・変更した最大2件のWi-Fi設定（更新しても消えない）
HOSTNAME_PROD = "nyuten-sensor"    # 本番モード時の DHCP 名
HOSTNAME_TEST = "nyuten-sensor2"   # 試験モード時の DHCP 名（本番機と名前がぶつからないように）
EVENT_URL = ""                     # ログ送信先（GAS等）。空なら送らない

# 遠隔チャイム: LAN内にUDPで "CHIME IN" を投げる。受信側（チャイム箱）が音を鳴らす
UDP_TARGET = "255.255.255.255"
UDP_PORT = 5005
UDP_REPEAT = 3


# ---------------------------------------------------------------- スマホから変えられる設定
# 状態ページの「調整」で変えた値は settings.json に保存され、次の起動でも使われる
CFG = {   # キー: (変数名, 型, 最小, 最大, 表示名)
    "testm":  ("TEST_MODE", int, 0, 1, "試験モード（1=チャイム鳴らさず記録のみ / 0=本番で鳴らす）"),
    "swap":   ("SWAP_AB", int, 0, 1, "A と B の入れ替え（0=7番がドア側A / 1=17番がドア側A）"),
    "drop":   ("DROP_MM", int, 50, 1500, "感度（mm 縮んだら人）"),
    "rangea": ("RANGE_A_MM", int, 0, 8000, "A が反応する一番奥 mm（0=制限なし）"),
    "rangeb": ("RANGE_B_MM", int, 0, 8000, "B が反応する一番奥 mm（0=制限なし。奥の棚・椅子よけ）"),
    "wall":   ("NO_TARGET_MM", int, 300, 8000, "壁が測れないときの仮基準 mm"),
    "hold":   ("HOLD_CLEAR_MS", int, 0, 600, "空きの保持時間 ms（腕振り・カバンの途切れ対策）"),
    "streak": ("HIT_STREAK", int, 1, 10, "連続反応回数（何回続けて反応したら人とするか）"),
    "oorh":   ("OOR_HOLD_MS", int, 0, 600, "65535（測距外）の保持上限 ms"),
    "pre":    ("PRE_RING", int, 0, 1, "先鳴らし（1=ドア側 A に入った瞬間に鳴らす）"),
    "preq":   ("PRE_QUIET_MS", int, 0, 20000, "先鳴らしを控える時間 ms（店内側B反応後の待機）"),
    "early":  ("EARLY_IN", int, 0, 1, "早め判定（1=店内側に入った瞬間に確定）"),
    "window": ("WINDOW_MS", int, 300, 5000, "通過の許容時間 ms"),
    "gap":    ("GAP_MS", int, 0, 3000, "A→B のすき間の許容 ms"),
    "refr":   ("REFRACTORY_MS", int, 300, 5000, "連続で鳴らさない時間 ms"),
    "diff":   ("DIFF_JUDGE", int, 0, 1, "A・B同時のとき距離差で向きを推測（0=しない）"),
    "vol":    ("CHIME_VOL", int, 0, 30, "チャイム音量 0〜30（本番モード時に送信）"),
    "trk":    ("CHIME_TRK", int, 1, 99, "チャイムの音・曲番号（本番モード時に送信）"),
}
CFG_GROUPS = (
    ("試験・取り付け", ("testm", "swap")),
    ("感度・見る範囲", ("drop", "rangea", "rangeb", "wall")),
    ("細い線（TSD10）対策", ("hold", "streak", "oorh")),
    ("判定", ("pre", "preq", "early", "window", "gap", "refr", "diff")),
    ("チャイム", ("vol", "trk")),
)
QUIET_FROM, QUIET_TO = -1, -1
# 営業時間（日本時間）。この外は鳴らさない。開始=終了ならその曜日は休み。
OPEN_WD, CLOSE_WD = (8, 45), (19, 0)     # 月〜金
OPEN_SAT, CLOSE_SAT = (8, 45), (15, 0)   # 土
OPEN_SUN, CLOSE_SUN = (0, 0), (0, 0)     # 日（休み）

TEST_MODE = 1           # 3.0: 初期値は 1（試験モード：本番チャイム箱を鳴らさず並行試験できる安全設定）
SWAP_AB = 0             # 3.0: 新箱は配線どおり 0（物理0=7番GP5がドア側A、物理1=17番GP13が店内側B）
RANGE_A_MM = 1420       # 3.0: ドア側Aの反応上限（考察メモ標準値。スマホから変更可）
RANGE_B_MM = 1500       # 3.0: 店内側Bの反応上限（斜め25°の奥にある棚・椅子を拾わない制限。スマホから変更可）
CHIME_VOL = 20
EARLY_IN = 1
PRE_RING = 1
PRE_QUIET_MS = 5000
PRE_KEEP_MS = 5000
DIFF_JUDGE = 0
CHIME_TRK = 1
CFG_FILE = "settings.json"


def cfg_apply(d):
    global QUIET_HOURS
    changed = []
    for k, v in d.items():
        if k not in CFG:
            continue
        name, typ, lo, hi, _ = CFG[k]
        try:
            v = typ(v)
        except Exception:
            continue
        v = max(lo, min(hi, v))
        if globals()[name] != v:
            globals()[name] = v
            changed.append(k)
    QUIET_HOURS = [(QUIET_FROM, QUIET_TO)] if QUIET_FROM >= 0 and QUIET_TO >= 0 else []
    return changed


def cfg_load():
    try:
        import json as _j
        with open(CFG_FILE) as f:
            cfg_apply(_j.load(f))
    except Exception:
        pass


SETLOG_FILE = "setlog.txt"


def setlog_add(line):
    try:
        try:
            with open(SETLOG_FILE) as f:
                rows = f.read().split("\n")
        except OSError:
            rows = []
        rows = [r for r in rows if r][-9:] + [line]
        with open(SETLOG_FILE, "w") as f:
            f.write("\n".join(rows))
    except Exception as e:
        print("設定の記録に失敗:", e)


def setlog_read():
    try:
        with open(SETLOG_FILE) as f:
            return [r for r in f.read().split("\n") if r][::-1]
    except OSError:
        return []


def cfg_save():
    try:
        import json as _j
        with open(CFG_FILE, "w") as f:
            _j.dump({k: globals()[CFG[k][0]] for k in CFG}, f)
    except Exception as e:
        print("設定の保存に失敗:", e)


WEB_PORT = 80
EVENT_KEEP = 20
# ===== 設定ここまで =====

_mono_s = 0
_mono_ms = 0
_mono_last = time.ticks_ms()


def mono():
    """起動からの秒数。時刻合わせ（NTP）で時計が飛んでも狂わない。ループで頻繁に呼ぶこと"""
    global _mono_s, _mono_ms, _mono_last
    n = time.ticks_ms()
    d = time.ticks_diff(n, _mono_last)
    _mono_last = n
    if d > 0:
        _mono_ms += d
        _mono_s += _mono_ms // 1000
        _mono_ms %= 1000
    return _mono_s


def clock_ok():
    return time.localtime()[0] >= 2024


led = Pin(PIN_LED, Pin.OUT)
if PASSIVE_BUZZER:
    buzzer = PWM(Pin(PIN_BUZZER)); buzzer.duty_u16(0)
else:
    buzzer = Pin(PIN_BUZZER, Pin.OUT); buzzer.off()


# ---------------------------------------------------------------- TSD10 UART 読み取り（460800bps・4バイトフレーム）
# フレーム仕様: [0]=0x5C, [1]=Dist_L, [2]=Dist_H, [3]=~(Dist_L + Dist_H) & 0xFF
# メモリ断片化を防ぐため、固定バッファ（_ubuf）と memoryview で割り当てゼロのまま毎周すべて読み切る
def uart_open(p):
    bus, tx_pin, rx_pin = UART_CFG[p]
    return UART(bus, UART_BAUD, tx=Pin(tx_pin), rx=Pin(rx_pin), rxbuf=UART_RXBUF)


cfg_load()
uarts = [uart_open(0), uart_open(1)]

_ubuf = bytearray(UART_RXBUF + 8)
_umv = memoryview(_ubuf)
_urem = (bytearray(3), bytearray(3))
_ulen = [0, 0]

u_last_mm = [None, None]       # 直近の有効距離 mm（範囲外・65535・未受信は None）
u_last_raw = [None, None]      # 直近の生値（0〜65535、未受信は None）
u_last_ms = [None, None]       # 最後に正常フレームを受けた ticks_ms
u_occ = [False, False]         # 保持時間・連続反応フィルタを通したあとの「人あり」状態（物理番号）
u_streak = [0, 0]              # 連続して閾値より近いフレームが来た回数
u_clear_since = [None, None]   # 人あり中に「空き（または65535）」が始まった時刻

u_ok_sec = [0, 0]              # 直近1秒間の正常フレーム数カウンタ
u_oor_sec = [0, 0]             # 直近1秒間の 65535 カウンタ
u_hz = [0, 0]                  # 状態ページ表示用：1秒あたりの正常フレーム数（49〜50が正常）
u_oor_hz = [0, 0]              # 状態ページ表示用：1秒あたりの 65535 件数
u_cerr = [0, 0]                # チェックサム失敗の累計回数
u_oor = [0, 0]                 # 65535（測距外）の累計回数
u_hz_t = time.ticks_ms()

baseA = NO_TARGET_MM
baseB = NO_TARGET_MM
_calibrated = False


def thr(base, rng):
    """この距離より近ければ「人がいる」。基準−感度 と 反応する一番奥 の近い方"""
    t = base - DROP_MM
    return t if not rng or rng >= t else rng


def _phys_thr(p):
    """物理センサー p (0/1) に対応する現在の検知距離閾値 mm"""
    if not _calibrated:
        return 0
    log_i = (1 - p) if SWAP_AB else p
    return thr(baseA, RANGE_A_MM) if log_i == 0 else thr(baseB, RANGE_B_MM)


def uart_reset_state():
    """ループが大きく止まった後などに、途中の検知状態だけを安全にクリアする"""
    for p in (0, 1):
        u_occ[p] = False
        u_streak[p] = 0
        u_clear_since[p] = None


def uart_poll_one(p, now, skip_occ=False):
    """物理センサー p の受信バッファをすべて読み切り、最新値と検知状態を更新する"""
    u = uarts[p]
    th = 0 if skip_occ else _phys_thr(p)
    rem_buf = _urem[p]
    while True:
        avail = u.any()
        if not avail:
            break
        rlen = _ulen[p]
        if rlen:
            _ubuf[0:rlen] = rem_buf[0:rlen]
        take = avail if avail <= UART_RXBUF else UART_RXBUF
        got = u.readinto(_umv[rlen:rlen + take])
        if not got:
            break
        total = rlen + got
        idx = 0
        lim4 = total - 3
        while idx < lim4:
            if _ubuf[idx] != 0x5C:
                idx += 1
                continue
            b1 = _ubuf[idx + 1]
            b2 = _ubuf[idx + 2]
            cs = _ubuf[idx + 3]
            if cs != ((~(b1 + b2)) & 0xFF):
                u_cerr[p] += 1
                idx += 1
                continue
            # 正常な4バイトフレーム
            u_ok_sec[p] += 1
            raw = b1 | (b2 << 8)
            u_last_raw[p] = raw
            u_last_ms[p] = now
            if raw == 0xFFFF:
                u_oor[p] += 1
                u_oor_sec[p] += 1
                u_last_mm[p] = None
                if th > 0 and u_occ[p] and u_clear_since[p] is None:
                    u_clear_since[p] = now
            else:
                mm = raw if MIN_VALID_MM <= raw <= MAX_VALID_MM else None
                u_last_mm[p] = mm
                if th > 0:
                    if mm is not None and mm < th:
                        u_clear_since[p] = None
                        u_streak[p] += 1
                        if u_streak[p] >= HIT_STREAK:
                            u_occ[p] = True
                    else:
                        if not u_occ[p]:
                            u_streak[p] = 0
                        elif u_clear_since[p] is None:
                            u_clear_since[p] = now
            idx += 4
        left = total - idx
        if left > 0:
            rem_buf[0:left] = _umv[idx:total]
        _ulen[p] = left

    # フレームが途絶えたとき・空き保持時間が過ぎたときの解除判定
    if u_last_ms[p] is None or time.ticks_diff(now, u_last_ms[p]) > max(OOR_HOLD_MS, 250):
        u_last_mm[p] = None
        u_occ[p] = False
        u_streak[p] = 0
        u_clear_since[p] = None
    elif not skip_occ and u_occ[p] and u_clear_since[p] is not None:
        hold_lim = OOR_HOLD_MS if u_last_raw[p] == 0xFFFF else HOLD_CLEAR_MS
        if time.ticks_diff(now, u_clear_since[p]) >= hold_lim:
            u_occ[p] = False
            u_streak[p] = 0
            u_clear_since[p] = None


def uart_poll_all(now, skip_occ=False):
    global u_hz_t
    uart_poll_one(0, now, skip_occ)
    uart_poll_one(1, now, skip_occ)
    if skip_occ:
        uart_reset_state()
    dt_hz = time.ticks_diff(now, u_hz_t)
    if dt_hz >= 1000:
        u_hz[0] = (u_ok_sec[0] * 1000 + dt_hz // 2) // dt_hz
        u_hz[1] = (u_ok_sec[1] * 1000 + dt_hz // 2) // dt_hz
        u_oor_hz[0] = (u_oor_sec[0] * 1000 + dt_hz // 2) // dt_hz
        u_oor_hz[1] = (u_oor_sec[1] * 1000 + dt_hz // 2) // dt_hz
        u_ok_sec[0] = u_ok_sec[1] = 0
        u_oor_sec[0] = u_oor_sec[1] = 0
        u_hz_t = now


def _phys_idx(logical_i):
    return (1 - logical_i) if SWAP_AB else logical_i


def logical_mm(logical_i):
    return u_last_mm[_phys_idx(logical_i)]


def logical_occ(logical_i):
    return u_occ[_phys_idx(logical_i)]


def logical_raw(logical_i):
    return u_last_raw[_phys_idx(logical_i)]


u_fix_t = [-10, -10]
u_down = [False, False]


def uart_recover(now):
    """5秒以上フレームが途絶えたセンサーの UART を、ループを止めずに開き直す（10秒に1回まで・前版 tof_recover 相当）"""
    up_s = mono()
    if up_s < 5:
        return
    for p in (0, 1):
        silent = u_last_ms[p] is None or time.ticks_diff(now, u_last_ms[p]) > 5000
        if not silent:
            if u_down[p]:
                u_down[p] = False
                name = "AB"[(1 - p) if SWAP_AB else p]
                log_event("センサー", "%s の受信が復帰しました" % name)
            continue
        if up_s - u_fix_t[p] < 10:
            continue
        u_fix_t[p] = up_s
        try:
            try:
                uarts[p].deinit()
            except Exception:
                pass
            uarts[p] = uart_open(p)
            _ulen[p] = 0
            if not u_down[p]:
                u_down[p] = True
                name = "AB"[(1 - p) if SWAP_AB else p]
                log_event("センサー", "%s の受信が途絶えたため UART を初期化し直しました" % name)
        except Exception as e:
            print("UART再初期化失敗:", e)
        wd_feed()


# ---------------------------------------------------------------- 見張り（固まったら自動で再起動）
WD_TIMEOUT_MS = 30000
_wd_last = time.ticks_ms()
_wd_timer = None


def wd_feed():
    global _wd_last
    _wd_last = time.ticks_ms()


def _wd_check(t):
    if time.ticks_diff(time.ticks_ms(), _wd_last) > WD_TIMEOUT_MS:
        try:
            with open("wd_reset.txt", "a") as f:
                f.write("%d\n" % time.time())
        except Exception:
            pass
        machine.reset()


def wd_start():
    global _wd_timer
    wd_feed()
    _wd_timer = Timer(-1)
    _wd_timer.init(period=2000, mode=Timer.PERIODIC, callback=_wd_check)


def wd_stop():
    if _wd_timer is not None:
        _wd_timer.deinit()


# ---------------------------------------------------------------- プログラム更新（ブラウザから）
def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def ota_receive(cl, buf):
    """POST /upload の本文（.mpy）を app_new.mpy に保存。(成功?, メッセージ) を返す。"""
    import gc
    gc.collect()
    while b"\r\n\r\n" not in buf:
        if len(buf) > 4096:
            return False, "見出しが長すぎます"
        wd_feed()
        more = cl.recv(512)
        if not more:
            return False, "受信が途中で切れました（見出し）"
        buf += more
    head, body = buf.split(b"\r\n\r\n", 1)
    n = 0
    for line in head.split(b"\r\n"):
        if line.lower().startswith(b"content-length:"):
            n = int(line.split(b":")[1])
    if n <= 0 or n > 120000:
        return False, "ファイルの大きさが正しくありません（%d）" % n
    idb = APP_ID.encode()
    found_id = False
    tag = b""
    tail = b""
    got = 0
    first = b""
    with open("app_new.mpy", "wb") as f:
        chunk = body
        while True:
            if chunk:
                f.write(chunk)
                got += len(chunk)
                if len(first) < 4:
                    first = (first + chunk)[:4]
                win = tail + chunk
                if not found_id and idb in win:
                    found_id = True
                if not tag:
                    i = win.find(b"@@VER:")
                    j = win.find(b"@@", i + 6) if i >= 0 else -1
                    if j > 0:
                        tag = win[i + 6:j]
                tail = win[-80:]
            if got >= n:
                break
            wd_feed()
            chunk = cl.recv(min(1024, n - got))
            if not chunk:
                break
    gc.collect()
    if got != n:
        os.remove("app_new.mpy")
        return False, "途中で切れました（%d / %d バイト）。もう一度送ってください" % (got, n)
    if first[:1] != b"M":
        os.remove("app_new.mpy")
        return False, "形式が違います（.mpy のファイルを選んでください）"
    if not found_id:
        os.remove("app_new.mpy")
        return False, "%s用のプログラムではありません。ファイルを確かめてください" % APP_NAME
    v = tag.decode().split("|") if tag else ["不明", "不明"]
    return True, "受け取りました：版 %s（%s 作成）。「更新を適用」を押すと切り替わります" % (v[0], v[1] if len(v) > 1 else "不明")


def _tag_of(data):
    i = data.find(b"@@VER:")
    j = data.find(b"@@", i + 6) if i >= 0 else -1
    if i < 0 or j < 0:
        return ("不明", "不明")
    v = data[i + 6:j].decode().split("|")
    return (v[0], v[1] if len(v) > 1 else "不明")


def _tag_file(fn):
    tail = b""
    with open(fn, "rb") as f:
        while True:
            c = f.read(1024)
            if not c:
                break
            w = tail + c
            if b"@@VER:" in w and w.find(b"@@", w.find(b"@@VER:") + 6) > 0:
                return _tag_of(w)
            tail = w[-80:]
    return ("不明", "不明")


def now_str():
    t = time.localtime(time.time() + 9 * 3600)
    if t[0] < 2024:
        return "時刻不明"
    return "%d/%d %02d:%02d" % (t[1], t[2], t[3], t[4])


def ota_info():
    s = "今の版 <b>%s</b>（%s 作成）" % (VERSION, BUILD)
    try:
        with open("app_updated.txt") as f:
            s += "<br>最後に更新：" + f.read().strip()
    except OSError:
        s += "<br>最後に更新：記録なし（USB で入れた版）"
    if _exists("crash.txt") and _exists("app_bad.mpy"):
        s += "<br><span style='color:var(--hot)'>前回の更新は起動に失敗したため、自動で元の版に戻しました</span>"
    if _exists("app_new.mpy"):
        try:
            v = _tag_file("app_new.mpy")
            s += "<br><span style='color:var(--hot)'>受け取り済み・未適用：版 %s（%s 作成）</span>" % v
        except Exception:
            pass
    return s


def ota_apply():
    if not _exists("app_new.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    try:
        v = _tag_file("app_new.mpy")
        with open("app_updated.txt", "w") as f:
            f.write("%s　版 %s → %s" % (now_str(), VERSION, v[0]))
    except Exception:
        pass
    if _exists("crash.txt"):
        os.remove("crash.txt")
    if _exists("app_prev.mpy"):
        os.remove("app_prev.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_prev.mpy")
    os.rename("app_new.mpy", "app.mpy")
    return True


def ota_rollback():
    if not _exists("app_prev.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    try:
        with open("app_updated.txt", "w") as f:
            f.write("%s　前の版に戻した" % now_str())
    except Exception:
        pass
    return True


_ok_marked = False


def ota_mark_ok(uptime_s):
    global _ok_marked
    if _ok_marked or uptime_s < 60:
        return
    _ok_marked = True
    try:
        if not _exists("app_ok.flag"):
            with open("app_ok.flag", "w") as f:
                f.write(VERSION)
    except Exception:
        pass
    launcher_update()


# @@LAUNCHER-BEGIN（main.py と同じ内容を保持）
LAUNCHER = """# -*- coding: utf-8 -*-
# 入店チャイム 起動役（センサー箱・チャイム箱 共通）。Pico に main.py として保存する。
# 本体のプログラムは app.mpy。更新後の app.mpy が起動に失敗したら、自動で前の版（app_prev.mpy）に戻す。
# 起動役 版 3（2026-10-30）：TSD10版センサー箱（外部ドライバ不要）に対応した案内文に更新
# 必ず UTF-8（BOMなし）で保存すること。
import os, sys, time, machine


def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def _crash(e):
    try:
        with open("crash.txt", "w") as f:
            sys.print_exception(e, f)
    except Exception:
        pass


def _rollback():
    # 更新したばかり（まだ「正常」の印が無い）で、前の版が残っていれば戻す
    if _exists("app_ok.flag") or not _exists("app_prev.mpy"):
        return False
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    return True


# 更新の途中で電源が切れて app.mpy が無いときの立て直し
if not (_exists("app.mpy") or _exists("app.py")):
    if _exists("app_new.mpy"):
        os.rename("app_new.mpy", "app.mpy")
        print("更新の途中だったので、新しい版の適用を済ませました")
    elif _exists("app_prev.mpy"):
        os.rename("app_prev.mpy", "app.mpy")
        print("app.mpy が無かったので、前の版を使います")

try:
    if not (_exists("app.mpy") or _exists("app.py")):
        print("app.mpy がありません。Thonny の「表示」→「ファイル」で app.mpy を Pico に入れてください")
        print("（名前が sensor_app.mpy / chime_app.mpy のままなら、右クリック →「リネーム」で app.mpy に）")
        raise SystemExit
    import app
except (KeyboardInterrupt, SystemExit):
    raise
except ImportError as e:
    if _rollback():
        _crash(e)
        print("新しい版に必要なファイルが無いため（%s）、前の版に戻して再起動します" % e)
        time.sleep(5)
        machine.reset()
    # 部品ファイルが足りないときは、再起動を繰り返さずに止める（Thonny で直せるように）
    print("必要なファイルが Pico にありません:", e)
    print("wifi_secret.py（旧VL53版センサー箱なら vl53l0x.py も）が入っているか確認してください")
    raise SystemExit
except Exception as e:
    sys.print_exception(e)
    _crash(e)
    if _rollback():
        print("新しい版で起動できなかったため、前の版に戻して再起動します")
    else:
        print("エラーで止まったため、5秒後に再起動します")
    time.sleep(5)
    machine.reset()
"""
# @@LAUNCHER-END


def launcher_update():
    try:
        try:
            with open("main.py") as f:
                if f.read() == LAUNCHER:
                    return
        except OSError:
            pass
        with open("main.tmp", "w") as f:
            f.write(LAUNCHER)
        try:
            os.rename("main.tmp", "main.py")
        except OSError:
            os.remove("main.py")
            os.rename("main.tmp", "main.py")
        log_event("更新", "起動役 main.py を新しくしました")
    except Exception as e:
        print("main.py の更新に失敗:", e)


OTA_HTML = """<div class="c"><details><summary><b>プログラム更新（Wi-Fi経由）</b>　<small>版 %s</small></summary>
<small>%s</small><br>
<small>Wi-Fi経由で更新できます。新しい %s 用のファイル（.mpy）を選んで「送る」→「更新を適用」を押してください（登録したWi-Fiや調整の設定は消えません。起動に失敗したら自動で前の版に戻ります）。</small><br>
<input type="file" id="up" accept=".mpy" style="margin-top:8px;max-width:100%%"><br>
<button onclick="upl()">送る</button><button onclick="if(confirm('新しい版に切り替えて再起動しますか？'))apl('/apply')">更新を適用</button>
<button onclick="if(confirm('ひとつ前の版に戻して再起動しますか？'))apl('/rollback')">前の版に戻す</button>
<br><small id="um"></small>
<br><small><a href="https://msmttng.github.io/nyuten-tsd10-manual/flash.html" target="_blank" style="color:var(--acc)">📥 最新更新ファイル(.mpy)とマニュアルのページを開く</a></small></details></div>
<script>
function upl(){var f=document.getElementById('up').files[0],m=document.getElementById('um');if(!f){m.textContent='ファイルを選んでください';return}
window.PAUSE=1;var x=new XMLHttpRequest();x.open('POST','/upload');x.timeout=60000;
x.upload.onprogress=function(e){if(e.lengthComputable)m.textContent='送信中… '+Math.round(e.loaded/e.total*100)+'%%'};
x.onload=function(){window.PAUSE=0;try{m.textContent=JSON.parse(x.responseText).msg}catch(e){m.textContent='返事が読めません: '+x.status}};
x.onerror=function(){window.PAUSE=0;m.textContent='送信に失敗しました（Wi-Fi が切れたか、箱が応答しません）。ページを再読み込みしてもう一度'};
x.ontimeout=function(){window.PAUSE=0;m.textContent='時間切れです。もう一度送ってください'};
m.textContent='送信中…';x.send(f)}
function apl(p){var m=document.getElementById('um');fetch(p,{method:'POST'}).then(function(r){return r.json()}).then(function(r){m.textContent=r.msg;if(r.ok)setTimeout(function(){location.reload()},25000)})}
</script>"""


# ---------------------------------------------------------------- 時刻・ログ
def jst():
    return time.localtime(time.time() + TZ_OFFSET)


def hhmmss():
    t = jst()
    return "%02d:%02d:%02d" % (t[3], t[4], t[5])


events = []


def log_event(kind, note=""):
    events.insert(0, [hhmmss(), kind, note])
    if len(events) > EVENT_KEEP:
        events.pop()
    print(kind, note)


# ---------------------------------------------------------------- UDP（チャイム送信）
udp_sock = None
seq = 0


def udp_setup():
    global udp_sock
    if not HAS_NET:
        return
    if udp_sock is not None:
        try:
            udp_sock.close()
        except Exception:
            pass
        udp_sock = None
    try:
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, 0x20, 1)  # SO_BROADCAST
    except Exception as e:
        print("UDP初期化失敗:", e)
        udp_sock = None


def send_cmd(text):
    if udp_sock is None or TEST_MODE:
        return
    for _ in range(UDP_REPEAT):
        try:
            udp_sock.sendto(text.encode(), (UDP_TARGET, UDP_PORT))
        except Exception as e:
            print("UDP送信失敗:", e)
        time.sleep_ms(20)


def send_chime(kind):
    """受信機へ "CHIME IN <seq>" を送る。試験モード（TEST_MODE=1）のときは送らない"""
    global seq
    if udp_sock is None or TEST_MODE:
        return
    seq += 1
    msg = ("CHIME %s %d" % (kind, seq)).encode()
    targets = [UDP_TARGET]
    try:
        if chime_t is not None and mono() - chime_t < 60:
            targets.insert(0, chime_info["ip"])
    except Exception:
        pass
    for i in range(UDP_REPEAT):
        for ip in targets:
            try:
                udp_sock.sendto(msg, (ip, UDP_PORT))
            except Exception as e:
                print("UDP送信失敗:", e)
        if i < UDP_REPEAT - 1:
            time.sleep_ms(5)


led_off_t = None


def chime():
    """入店時のチャイム動作。試験モード中は本番チャイム箱を鳴らさず本体LEDのみ点灯する"""
    global led_off_t
    led.on()
    if not TEST_MODE:
        send_chime("IN")
    if not LOCAL_BUZZER or TEST_MODE:
        led_off_t = time.ticks_add(time.ticks_ms(), 100)
        return
    if PASSIVE_BUZZER:
        buzzer.freq(CHIME_HZ); buzzer.duty_u16(32768)
        time.sleep_ms(CHIME_MS); buzzer.duty_u16(0)
    else:
        buzzer.on(); time.sleep_ms(CHIME_MS); buzzer.off()
    led.off()


def in_quiet_hours():
    if clock_ok():
        t = jst()
        wd = t[6]
        o, c = (OPEN_SUN, CLOSE_SUN) if wd == 6 else (OPEN_SAT, CLOSE_SAT) if wd == 5 else (OPEN_WD, CLOSE_WD)
        now_m = t[3] * 60 + t[4]
        if not (o[0] * 60 + o[1] <= now_m < c[0] * 60 + c[1]):
            return True
    if not QUIET_HOURS:
        return False
    h = jst()[3]
    for s, e in QUIET_HOURS:
        if (s <= e and s <= h < e) or (s > e and (h >= s or h < e)):
            return True
    return False


# ---------------------------------------------------------------- Wi-Fi（最大2件登録・電波スキャン自動切替）
wifi_cur_ssid = ""


def cur_hostname():
    return HOSTNAME_TEST if TEST_MODE else HOSTNAME_PROD


def wlan():
    return network.WLAN(network.STA_IF) if HAS_NET else None


def wifi_slots():
    """状態ページに表示・編集する2枠 [[ssid1, pass1], [ssid2, pass2]] を返す"""
    s = [[WIFI_SSID, WIFI_PASS], [WIFI_SSID2, WIFI_PASS2]]
    if not HAS_NET:
        return s
    try:
        with open(WIFI_EXTRA_FILE) as f:
            d = json.load(f)
        if isinstance(d, dict):
            if "s1" in d:
                s[0] = [str(d.get("s1") or ""), str(d.get("p1") or "")]
            if "s2" in d:
                s[1] = [str(d.get("s2") or ""), str(d.get("p2") or "")]
    except Exception:
        pass
    return s


def wifi_save_slots(s1, p1, s2, p2):
    tmp = WIFI_EXTRA_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"s1": s1, "p1": p1, "s2": s2, "p2": p2}, f)
    try:
        os.rename(tmp, WIFI_EXTRA_FILE)
    except OSError:
        try:
            os.remove(WIFI_EXTRA_FILE)
        except OSError:
            pass
        os.rename(tmp, WIFI_EXTRA_FILE)


def wifi_candidates():
    """接続を試す (ssid, pass) のリスト。万一の入力ミスでも締め出されないよう wifi_secret.py の値も末尾に予備保持"""
    out = []
    seen = []
    for ss, pw in wifi_slots() + [[WIFI_SSID, WIFI_PASS], [WIFI_SSID2, WIFI_PASS2]]:
        ss = (ss or "").strip()
        if not ss:
            continue
        pair = (ss, pw or "")
        if pair not in seen:
            seen.append(pair)
            out.append(pair)
    return out


def wifi_connect():
    global wifi_cur_ssid
    cands = wifi_candidates()
    if not HAS_NET or not cands:
        return False
    try:
        network.hostname(cur_hostname())
    except Exception:
        pass
    try:
        import rp2
        rp2.country("JP")
    except Exception:
        pass
    w = wlan(); w.active(True)
    try:
        w.config(pm=0xa11140)
    except Exception:
        pass
    if w.isconnected():
        if not wifi_cur_ssid:
            try:
                wifi_cur_ssid = w.config("ssid") or cands[0][0]
            except Exception:
                wifi_cur_ssid = cands[0][0]
        return True
    # 2つ以上登録されているときは周囲の電波をスキャンし、今その場にあるWi-Fiから先につなぐ（隠れSSIDも後ろで試す）
    order = cands
    if len(cands) > 1:
        try:
            vis = {}
            for item in (w.scan() or ()):
                try:
                    raw_s = item[0]
                    ss = raw_s.decode("utf-8", "ignore") if isinstance(raw_s, (bytes, bytearray)) else str(raw_s)
                    rs = item[3]
                    if ss and (ss not in vis or rs > vis[ss]):
                        vis[ss] = rs
                except Exception:
                    pass
            wd_feed()
            if vis:
                hit = [c for c in cands if c[0] in vis]
                hit.sort(key=lambda c: vis[c[0]], reverse=True)
                miss = [c for c in cands if c[0] not in vis]
                order = hit + miss
        except Exception:
            order = cands
    for idx, (ssid, pw) in enumerate(order):
        if idx > 0:
            try:
                w.disconnect()
            except Exception:
                pass
            w.active(False); time.sleep_ms(200); w.active(True)
            try:
                w.config(pm=0xa11140)
            except Exception:
                pass
        w.connect(ssid, pw)
        steps = 22 if len(order) > 1 else 30
        for _ in range(steps):
            if w.isconnected():
                break
            led.toggle()
            wd_feed()
            time.sleep(0.5)
        led.off()
        if w.isconnected():
            wifi_cur_ssid = ssid
            print("WiFi:", w.ifconfig()[0], "(%s) [%s] → iPhone で http://%s/ を開く" % (
                cur_hostname(), ssid, w.ifconfig()[0]))
            try:
                ntptime.settime()
            except Exception as e:
                print("NTP失敗:", e)
            return True
    wifi_cur_ssid = ""
    print("WiFi接続失敗")
    return False


def wifi_ok():
    try:
        return HAS_NET and wlan().isconnected()
    except Exception:
        return False


def post_event(kind):
    if not EVENT_URL or not HAS_NET:
        return
    try:
        t = jst()
        ts = "%04d-%02d-%02d %02d:%02d:%02d" % t[:6]
        r = urequests.post(EVENT_URL, json={"event": kind, "time_jst": ts,
                                            "in": in_count, "out": out_count,
                                            "test": TEST_MODE})
        r.close()
    except Exception as e:
        print("送信失敗:", e)


# ---------------------------------------------------------------- 基準距離の取得
def median(xs):
    xs = sorted(xs); n = len(xs)
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) // 2


def wait_sensors_boot(timeout_ms=500):
    """起動直後、TSD10 から最初のフレームが届くのを最大0.5秒だけ待つ（未接続でも止まらず進む）"""
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < timeout_ms:
        now = time.ticks_ms()
        uart_poll_all(now, skip_occ=True)
        wd_feed()
        if u_last_ms[0] is not None and u_last_ms[1] is not None:
            break
        time.sleep_ms(10)


def calibrate(prev=None, accept=False):
    """基準距離を取る。50Hzの新しいフレームを1回ずつ拾うため CALIB_STEP_MS(22ms) 間隔で測る。"""
    a, b = [], []
    # 古い残りフレームを一度読み切ってから新しい測定を始める
    uart_poll_all(time.ticks_ms(), skip_occ=True)
    for i in range(CALIB_SAMPLES):
        time.sleep_ms(CALIB_STEP_MS)
        uart_poll_all(time.ticks_ms(), skip_occ=True)
        da, db = logical_mm(0), logical_mm(1)
        if da:
            a.append(da)
        if db:
            b.append(db)
        led.value(i % 2)
        wd_feed()
    led.off()
    return base_from(a, b, CALIB_SAMPLES, prev, accept)


def base_from(a, b, n, prev=None, accept=False):
    ba = median(a) if len(a) >= n // 3 else NO_TARGET_MM
    bb = median(b) if len(b) >= n // 3 else NO_TARGET_MM
    limit = 0 if accept else NO_TARGET_MM - 2 * DROP_MM
    blocked = ""
    if ba < limit:
        blocked += "A%d" % ba
        ba = prev[0] if prev and prev[0] >= limit else NO_TARGET_MM
    if bb < limit:
        blocked += " B%d" % bb
        bb = prev[1] if prev and prev[1] >= limit else NO_TARGET_MM
    note = "A=%dmm B=%dmm" % (ba, bb)
    who = ("A" if len(a) < n // 3 else "") + ("B" if len(b) < n // 3 else "")
    if who:
        note += "（%s は向かいが測れず仮の値 %dmm）" % (who, NO_TARGET_MM)
    if blocked:
        note += "（前に人か物があった：%smm → 基準は変えず1分後に取り直し）" % blocked.strip()
    if accept:
        note += "（2分以上ずっと遮られているので、置き物とみなしてこの距離を基準にしました）"
    log_event("基準", note)
    return ba, bb, bool(blocked)


# ---------------------------------------------------------------- 状態ページ
PAGE = """<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>入店センサー(TSD10)</title><style>
:root{--bg:#f4f3ef;--fg:#222;--mut:#8a8884;--card:#fff;--acc:#1d9e75;--hot:#d85a30;--trk:#e6e4de;--warnbg:#fff4e5;--warnbd:#f0a848}
@media(prefers-color-scheme:dark){:root{--bg:#1a1a19;--fg:#eee;--mut:#9a9890;--card:#262624;--trk:#3a3a38;--warnbg:#332714;--warnbd:#b87b28}}
body{margin:0;padding:16px;font-family:-apple-system,system-ui,sans-serif;background:var(--bg);color:var(--fg)}
.c{background:var(--card);border-radius:14px;padding:14px;margin-bottom:12px}
.tm-ban{background:var(--warnbg);border:2px solid var(--warnbd);border-radius:14px;padding:12px 14px;margin-bottom:12px;display:none}
.n{display:flex}.n div{flex:1;text-align:center}.n b{display:block;font-size:44px;font-weight:600}
.lb{display:flex;justify-content:space-between;font-size:15px;margin-top:8px}
.bar{height:22px;background:var(--trk);border-radius:6px;position:relative;margin:6px 0}
.f{height:100%;border-radius:6px;background:var(--acc);transition:width .15s}.f.on{background:var(--hot)}
.th{position:absolute;top:-4px;bottom:-4px;width:2px;background:var(--fg)}
small{color:var(--mut);font-size:13px}ul{list-style:none;padding:0;margin:6px 0 0}
li{display:flex;gap:10px;padding:5px 0;border-top:1px solid var(--trk);font-size:14px}
li span:first-child{color:var(--mut);width:64px}.IN{color:var(--acc);font-weight:600}
button{font-size:15px;padding:10px 12px;border-radius:10px;border:1px solid var(--trk);background:var(--card);color:var(--fg);margin:8px 6px 0 0}
#dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--acc);margin-right:6px}
.hzok{color:var(--acc);font-weight:600}.hzng{color:var(--hot);font-weight:600}
</style></head><body>
<div class="tm-ban" id="tmb"><b>🧪 試験モード中（チャイム箱は鳴らしません）</b><br><small>入店・退店の記録だけを行います（本番箱と並べて比較用）。本番としてチャイムを鳴らすときは下の「調整」→「試験モード」を <b>0</b> にして保存してください。</small></div>
<div class="c n"><div><small>今日の入店</small><b id="in">-</b></div><div><small>退店</small><b id="out">-</b></div></div>
<div class="c"><b>センサー（TSD10 LiDAR）</b>
<div class="lb"><span>A 外側（ドア側）</span><span id="ta"></span></div><div class="bar"><div class="f" id="fa"></div><div class="th" id="ha"></div></div>
<div class="lb"><span>B 内側（店内25°）</span><span id="tb"></span></div><div class="bar"><div class="f" id="fb"></div><div class="th" id="hb"></div></div>
<small>棒が短い＝近くに人。縦線より短くなると「検知」</small><br><small id="tm"></small></div>
<div class="c"><b>チャイム箱</b>　<small id="chs">確認中…</small></div>
<div class="c"><b>最近の判定</b><ul id="ev"></ul></div>
<div class="c"><small><span id="dot"></span><span id="st">接続中…</span></small><br>
<button onclick="go('/test')">チャイム試験</button><button onclick="go('/recal')">基準を取り直す</button>
<button onclick="if(confirm('今日の件数を0に戻しますか？'))go('/reset')">件数リセット</button><br><small id="gm"></small></div>
<div class="c"><details id="adj" ontoggle="if(this.open)lc()"><summary><b>調整</b>　<small>変えたら「保存」。すぐ反映・電源を切っても残ります</small></summary>
<small>鳴らす時間（固定）：平日 8:45〜19:00・土曜 8:45〜15:00・日曜 休み。この外は数えるだけで鳴らしません</small>
<div id="cf"></div>
<button onclick="save()">保存</button><button onclick="if(confirm('センサー箱を再起動しますか？'))P('/reboot')">再起動</button>
<br><small id="cmsg">「試験モード」は 1=鳴らさず記録のみ、0=本番でチャイムを鳴らす（ホスト名の変更は再起動で反映）。</small>
<br><small><b>設定を変えた記録</b></small><ul id="slog" style="font-size:12px;margin:4px 0 0 0;padding-left:16px"></ul></details></div>
<div class="c"><details id="wdet" ontoggle="if(this.open)lwf()"><summary><b>Wi-Fi 設定（2つまで登録）</b>　<small>自宅とお店など自動切替・更新しても残ります</small></summary>
<small id="wcur">現在接続中の Wi-Fi を確認中…</small>
<div style="margin-top:8px;font-weight:bold;font-size:13px">① 1つ目の Wi-Fi（お店 または 自宅）</div>
<div class="lb" style="align-items:center;gap:8px"><span style="min-width:76px">Wi-Fi名</span><input id="ws1" placeholder="SSID（2.4GHz）" autocomplete="off" style="flex:1;font-size:15px;padding:6px 8px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg)"></div>
<div class="lb" style="align-items:center;gap:8px"><span style="min-width:76px">パスワード</span><input id="wp1" type="password" placeholder="パスワード" autocomplete="off" style="flex:1;font-size:15px;padding:6px 8px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg)"></div>
<div style="margin-top:10px;font-weight:bold;font-size:13px">② 2つ目の Wi-Fi（もう1つの場所・任意）</div>
<div class="lb" style="align-items:center;gap:8px"><span style="min-width:76px">Wi-Fi名</span><input id="ws2" placeholder="2つ目のSSID（空欄で解除）" autocomplete="off" style="flex:1;font-size:15px;padding:6px 8px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg)"></div>
<div class="lb" style="align-items:center;gap:8px"><span style="min-width:76px">パスワード</span><input id="wp2" type="password" placeholder="パスワード" autocomplete="off" style="flex:1;font-size:15px;padding:6px 8px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg)"></div>
<div style="margin-top:6px"><label style="font-size:13px;color:var(--mut)"><input type="checkbox" onchange="$('wp1').type=$('wp2').type=this.checked?'text':'password'"> パスワードを表示する</label></div>
<button onclick="swfi()">Wi-Fi設定を保存</button><button onclick="if(confirm('再起動してWi-Fiをつなぎ直しますか？'))P('/reboot')">再起動</button>
<br><small id="wmsg">※すでに登録済みの Wi-Fi はパスワード欄が空欄のままでも維持されます。電源を入れた場所にある方の電波を自動で選んでつながります。</small></details></div>
<script>
function $(i){return document.getElementById(i)}
function E(s){return String(s).replace(/[&<>"']/g,function(c){return '&#'+c.charCodeAt(0)+';'})}
function P(p){return fetch(p,{method:'POST'})}
function go(p){P(p).then(function(r){return r.json()}).then(function(r){$('gm').textContent=r.msg||''}).catch(function(){}).then(u)}
function bar(k,d,b,dr,o,raw,hz){var m=Math.max(b,1);$('f'+k).style.width=Math.min(100,(d||m)/m*100)+'%';
$('f'+k).className='f'+(o?' on':'');$('h'+k).style.left=Math.max(0,(b-dr)/m*100)+'%';
var txt=d?d+' mm':(hz===0?'-- mm[受信なし]':(raw===65535?'-- mm[測距外65535]':'-- mm'));
$('t'+k).textContent=txt+'（基準 '+b+'）'+(o?' ●検知':'')}
function hm(s){var h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+'時間':'')+m+'分'}
function hzSpan(lbl,v){var ok=(v>=35&&v<=55);return lbl+' <span class="'+(ok?'hzok':'hzng')+'">'+v+' 件/秒</span>'}
function u(){if(window.PAUSE)return;fetch('/s',{cache:'no-store'}).then(function(r){return r.json()}).then(function(s){
$('tmb').style.display=s.testm?'block':'none';
$('in').textContent=s.in;$('out').textContent=s.out;
bar('a',s.a,s.ba,s.da||s.drop,s.oa,s.rawa,s.hz[0]);bar('b',s.b,s.bb,s.db||s.drop,s.ob,s.rawb,s.hz[1]);
$('ev').innerHTML=s.ev.map(function(e){return '<li><span>'+E(e[0])+'</span><span class="'+(e[1]=='IN'?'IN':'')+'">'+E(e[1])+'</span><span>'+E(e[2])+'</span></li>'}).join('')||'<li><span>まだありません</span></li>';
var hmsg='1秒あたりの正常測定（35〜55が正常）：'+hzSpan('A',s.hz[0])+' ／ '+hzSpan('B',s.hz[1]);
hmsg+='<br>チェック失敗 A:'+s.cerr[0]+'回・B:'+s.cerr[1]+'回 ／ 65535(測距外) A:'+s.oor[0]+'回・B:'+s.oor[1]+'回';
if(s.pre&&(s.pre[0]||s.pre[1]||s.pre[2])){hmsg+='<br>先鳴らし '+s.pre[0]+'回（入店 '+s.pre[1]+'・空振り '+s.pre[2]+'）'}
if(s.hz[0]===0||s.hz[1]===0){hmsg+='<br><span class="hzng">⚠️ 0件/秒の側：2.2kΩが付いていればニッパーで切断／緑(t)・赤(v=40番)・黒(g)のはんだを確認</span>'}
$('tm').innerHTML=hmsg;
var c=s.ch;$('chs').innerHTML=!c?'まだ応答がありません（チャイム箱の電源・Wi-Fi を確認）':(c.age>40?'<span style="color:var(--hot)">● 応答なし（'+c.age+'秒前が最後）</span>':'<span style="color:var(--acc)">● 接続中</span>')+(s.testm?'　<b>[試験モード：送信停止中]</b>':'')+(c?'　音量 '+E(c.vol)+'・音 '+E(c.trk)+'・SD '+(c.sd?'OK（'+E(c.n)+'曲）':'<span style="color:var(--hot)">読めない</span>')+(c.cnt?'<br>起動から 受けた '+c.cnt[0]+'・鳴らした '+c.cnt[1]+'・失敗 '+c.cnt[2]+'・間隔で省略 '+c.cnt[3]:'')+'<br><a href="http://'+E(c.ip)+'/" style="color:var(--mut)">チャイム箱のページ（'+E(c.ip)+'・版 '+E(c.ver)+'）</a>':'');
$('dot').style.background='var(--acc)';
$('st').innerHTML=E(s.host)+' ('+s.ip+')　Wi-Fi '+(s.ssid?'['+E(s.ssid)+'] ':'')+(s.rssi===null?'--':s.rssi+'dBm')+'　稼働 '+hm(s.up)+'<br>昨日 入'+s.yin+' / 出'+s.yout+(s.quiet?'　営業時間外（鳴らさない）':'')+(s.testm?'　🧪試験モード':'');
}).catch(function(){$('dot').style.background='var(--hot)';$('st').textContent='センサー箱に接続できません'})}
function lc(){fetch('/cfg',{cache:'no-store'}).then(function(r){return r.json()}).then(function(c){
var g0='';$('cf').innerHTML=c.map(function(x){var h='';if(x[3]&&x[3]!==g0){g0=x[3];h='<div style="margin:10px 0 2px;font-weight:bold;font-size:13px">'+E(x[3])+'</div>'}return h+'<div class="lb" style="align-items:center"><span>'+E(x[2])+'</span><input id="k_'+E(x[0])+'" value="'+E(x[1])+'" data-o="'+E(x[1])+'" inputmode="decimal" style="width:90px;font-size:16px;padding:6px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg);text-align:right"></div>'}).join('')});
fetch('/setlog',{cache:'no-store'}).then(function(r){return r.json()}).then(function(l){$('slog').innerHTML=l.map(function(x){return '<li>'+E(x)+'</li>'}).join('')||'<li>まだありません</li>'})}
function save(){var q=[];document.querySelectorAll('#cf input').forEach(function(i){if(i.value!==i.getAttribute('data-o'))q.push(i.id.slice(2)+'='+encodeURIComponent(i.value))});
if(!q.length){$('cmsg').textContent='変更はありません';return}
P('/set?'+q.join('&')).then(function(r){return r.json()}).then(function(r){$('cmsg').textContent=r.changed.length?'保存しました：'+r.changed.join('・')+(r.reboot?'（ホスト名の反映には再起動）':''):'変更はありません';lc();u()})}
function lwf(){fetch('/wcfg',{cache:'no-store'}).then(function(r){return r.json()}).then(function(r){
$('wcur').textContent='現在接続中：'+(r.cur||'未接続')+'（電源を入れた場所にある方の Wi-Fi へ自動でつながります）';
$('ws1').value=r.w[0][0]||'';$('wp1').value='';$('wp1').placeholder=r.w[0][1]?'登録済み（変更するときだけ入力）':'パスワードを入力';
$('ws2').value=r.w[1][0]||'';$('wp2').value='';$('wp2').placeholder=r.w[1][1]?'登録済み（変更するときだけ入力）':'パスワードを入力';
}).catch(function(){})}
function swfi(){var m=$('wmsg');m.textContent='保存中…';
fetch('/wset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({s1:$('ws1').value,p1:$('wp1').value,s2:$('ws2').value,p2:$('wp2').value})})
.then(function(r){return r.json()}).then(function(r){m.textContent=r.msg||'';if(r.ok)lwf()}).catch(function(){m.textContent='保存に失敗しました'})}
setInterval(u,500);u();lc();
</script><!--OTA--></body></html>"""
PAGE_A, PAGE_B = (x.encode() for x in PAGE.split("<!--OTA-->"))
del PAGE

HB_PORT = 5006
hb_sock = None
chime_t = None
chime_info = {}
chime_down = False


def hb_setup():
    global hb_sock
    if not HAS_NET:
        return
    try:
        hb_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        hb_sock.bind(("0.0.0.0", HB_PORT))
        hb_sock.setblocking(False)
    except Exception as e:
        print("生存確認の受信準備に失敗:", e)


def hb_poll():
    """ALIVE CHIME <sd> <vol> <trk> <曲数> <版>。試験モード時はチャイム箱の音量・曲を書き換えない"""
    global chime_t, chime_info, chime_down
    if hb_sock is None:
        return
    try:
        data, addr = hb_sock.recvfrom(128)
    except OSError:
        data = None
    if data:
        try:
            p = data.decode().split()
            if len(p) >= 7 and p[0] == "ALIVE" and p[1] == "CHIME":
                chime_info = {"ip": addr[0], "sd": p[2] == "1", "vol": int(p[3]), "trk": int(p[4]),
                              "n": int(p[5]), "ver": p[6]}
                if len(p) >= 11:
                    chime_info["cnt"] = [int(x) for x in p[7:11]]
                if chime_down or chime_t is None:
                    log_event("チャイム箱", ("復帰" if chime_down else "接続") + " %s" % addr[0])
                chime_down = False
                chime_t = mono()
                if not TEST_MODE:
                    if chime_info["vol"] != CHIME_VOL:
                        send_cmd("CHIME VOL %d" % CHIME_VOL)
                    if chime_info["trk"] != CHIME_TRK:
                        send_cmd("CHIME TRK %d" % CHIME_TRK)
        except Exception:
            pass
    if chime_t is not None and not chime_down and mono() - chime_t > 40:
        chime_down = True
        log_event("チャイム箱", "応答なし（電源・Wi-Fi を確認）")


web_sock = None
recal_req = False
reboot_req = False


def web_setup():
    global web_sock
    if not HAS_NET:
        return
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", WEB_PORT))
        s.listen(2)
        s.setblocking(False)
        web_sock = s
    except Exception as e:
        print("状態ページ起動失敗:", e)


def _mem_free():
    try:
        import gc
        return gc.mem_free()
    except Exception:
        return -1


def _pair_logical(arr):
    return [arr[1], arr[0]] if SWAP_AB else [arr[0], arr[1]]


def status_json():
    rssi = None
    ip = "-"
    try:
        w = wlan()
        if w.isconnected():
            ip = w.ifconfig()[0]
            rssi = w.status("rssi")
    except Exception:
        pass
    return json.dumps({
        "a": dA or 0, "b": dB or 0, "rawa": logical_raw(0), "rawb": logical_raw(1),
        "ba": baseA, "bb": baseB, "drop": DROP_MM,
        "da": baseA - thr(baseA, RANGE_A_MM), "db": baseB - thr(baseB, RANGE_B_MM),
        "oa": occA, "ob": occB, "in": in_count, "out": out_count,
        "yin": y_in, "yout": y_out, "up": mono(),
        "hz": _pair_logical(u_hz), "oorhz": _pair_logical(u_oor_hz),
        "cerr": _pair_logical(u_cerr), "oor": _pair_logical(u_oor),
        "testm": TEST_MODE, "host": cur_hostname(), "ssid": wifi_cur_ssid,
        "rssi": rssi, "ip": ip, "quiet": in_quiet_hours(), "ev": events,
        "ver": VERSION, "werr": web_err[0], "mem": _mem_free(), "pre": pre_cnt,
        "ch": (None if chime_t is None else dict(chime_info, age=mono() - chime_t)),
    })


def send_all(cl, data):
    mv = memoryview(data)
    i = 0
    while i < len(data):
        n = cl.send(mv[i:i + 1024])
        if not n:
            break
        i += n


def _read_json_body(cl, buf):
    """POST 本文の JSON を分割パケットに対応して読み取る（パスワード内の特殊記号も安全に保持）"""
    while b"\r\n\r\n" not in buf:
        if len(buf) > 4096:
            return None
        wd_feed()
        more = cl.recv(512)
        if not more:
            return None
        buf += more
    head, body = buf.split(b"\r\n\r\n", 1)
    n = 0
    for hl in head.split(b"\r\n"):
        if hl.lower().startswith(b"content-length:"):
            n = int(hl.split(b":")[1])
    if n <= 0 or n > 2048:
        return None
    while len(body) < n:
        wd_feed()
        more = cl.recv(min(512, n - len(body)))
        if not more:
            break
        body += more
    return json.loads(body[:n].decode("utf-8"))


web_err = [0]
POST_ONLY = ("/set", "/wset", "/apply", "/rollback", "/reboot", "/test", "/recal", "/reset")
TRACE_UNIT_MM = 25          # 3.0: 1バイト(0〜255)で 0〜6375mm まで記録できるよう 25mm 単位に変更


def web_poll():
    """1回のループで最大1接続だけ処理する（通過中の1.5秒間だけセンサー最優先、それ以外は即応答）"""
    global recal_req, in_count, out_count, reboot_req, led_off_t
    crossing_now = ((occA and (startA is None or time.ticks_diff(now, startA) <= WINDOW_MS))
                    or (occB and (startB is None or time.ticks_diff(now, startB) <= WINDOW_MS)))
    if web_sock is None or crossing_now:
        return
    try:
        cl, addr = web_sock.accept()
    except OSError:
        return
    try:
        cl.settimeout(3)
        req = cl.recv(1024)
        if not req:
            return
        line = req.split(b"\r\n", 1)[0].decode()
        parts = line.split(" ")
        path = parts[1] if len(parts) > 1 else "/"
        query = ""
        if "?" in path:
            path, query = path.split("?", 1)
        ctype = "application/json"
        if path in POST_ONLY and not line.startswith("POST"):
            body = json.dumps({"ok": 0, "msg": "この操作は状態ページのボタンから行ってください"})
        elif path == "/s":
            body = status_json()
        elif path == "/trace":
            import ubinascii
            if query.startswith("i="):
                k = int(query[2:])
                if 0 <= k < len(traces):
                    t = traces[k]
                    body = json.dumps({"t": t[0], "res": t[2], "seen": t[3], "ba": t[4], "bb": t[5],
                                       "unit_mm": TRACE_UNIT_MM,
                                       "hex": ubinascii.hexlify(t[1]).decode()})
                else:
                    body = "{}"
            else:
                body = json.dumps([[t[0], t[2], t[3], len(t[1]) // 4, TRACE_UNIT_MM] for t in traces])
        elif path == "/cfg":
            body = json.dumps([[k, globals()[CFG[k][0]], CFG[k][4], g] for g, ks in CFG_GROUPS for k in ks if k in CFG])
        elif path == "/setlog":
            body = json.dumps(setlog_read())
        elif path == "/wcfg":
            sl = wifi_slots()
            body = json.dumps({
                "cur": wifi_cur_ssid,
                "w": [[sl[0][0], 1 if sl[0][1] else 0], [sl[1][0], 1 if sl[1][1] else 0]],
            })
        elif path == "/wset":
            d = _read_json_body(cl, req)
            if not isinstance(d, dict):
                body = json.dumps({"ok": 0, "msg": "送信データを読み取れませんでした"})
            else:
                old = wifi_slots()
                ns1 = str(d.get("s1") or "").strip()
                ns2 = str(d.get("s2") or "").strip()
                in_p1 = str(d.get("p1") or "")
                in_p2 = str(d.get("p2") or "")
                if not ns1:
                    np1 = ""
                elif in_p1:
                    np1 = in_p1
                elif ns1 == old[0][0]:
                    np1 = old[0][1]
                elif ns1 == old[1][0]:
                    np1 = old[1][1]
                else:
                    np1 = None
                if not ns2:
                    np2 = ""
                elif in_p2:
                    np2 = in_p2
                elif ns2 == old[1][0]:
                    np2 = old[1][1]
                elif ns2 == old[0][0]:
                    np2 = old[0][1]
                else:
                    np2 = None
                if not ns1 and not ns2:
                    body = json.dumps({"ok": 0, "msg": "少なくとも1つは Wi-Fi 名（SSID）を入力してください"})
                elif np1 is None or np2 is None:
                    which = "① 1つ目のWi-Fi" if np1 is None else "② 2つ目のWi-Fi"
                    body = json.dumps({"ok": 0, "msg": "%s に新しい Wi-Fi 名を入れるときはパスワードも入力してください" % which})
                else:
                    if not ns1 and ns2:
                        ns1, np1, ns2, np2 = ns2, np2, "", ""
                    wifi_save_slots(ns1, np1, ns2, np2)
                    who = addr[0] if addr else "?"
                    wsum = "Wi-Fi①=%s / Wi-Fi②=%s" % (ns1 or "(未設定)", ns2 or "(なし)")
                    log_event("Wi-Fi設定", "%s（%s から）" % (wsum, who))
                    t = jst()
                    setlog_add("%d/%d %02d:%02d %s から %s" % (t[1], t[2], t[3], t[4], who, wsum))
                    body = json.dumps({"ok": 1, "msg": "保存しました（%s）。場所を移したときや再起動時に自動で切り替わります（プログラム更新しても消えません）" % wsum})
        elif path == "/set":
            d = {}
            for kv in query.split("&"):
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    d[k] = v.replace("%2E", ".").replace("%2D", "-")
            changed = cfg_apply(d)
            if changed:
                cfg_save()
                who = addr[0] if addr else "?"
                what = "、".join("%s=%s" % (k, globals()[CFG[k][0]]) for k in changed)
                log_event("設定", "%s（%s から）" % (what, who))
                t = jst()
                setlog_add("%d/%d %02d:%02d %s から %s" % (t[1], t[2], t[3], t[4], who, what))
                if not TEST_MODE:
                    if "vol" in changed:
                        send_cmd("CHIME VOL %d T" % CHIME_VOL)
                    if "trk" in changed:
                        send_cmd("CHIME TRK %d T" % CHIME_TRK)
                if "wall" in changed or "swap" in changed:
                    recal_req = True
            body = json.dumps({"changed": [CFG[k][4] for k in changed],
                               "reboot": ("testm" in changed)})
        elif path == "/upload" and line.startswith("POST"):
            try:
                ok, msg = ota_receive(cl, req)
            except Exception as e:
                ok, msg = False, "受信中にエラー: %r（もう一度送ってください）" % (e,)
                try:
                    os.remove("app_new.mpy")
                except OSError:
                    pass
            log_event("更新", msg)
            body = json.dumps({"ok": ok, "msg": msg})
        elif path == "/apply":
            ok = ota_apply()
            body = json.dumps({"ok": ok, "msg": "新しい版で再起動します。25秒ほどで再表示します" if ok else "先にファイルを送ってください"})
            if ok:
                log_event("更新", "新しい版を適用")
                reboot_req = True
        elif path == "/rollback":
            ok = ota_rollback()
            body = json.dumps({"ok": ok, "msg": "前の版に戻して再起動します" if ok else "前の版がありません"})
            if ok:
                reboot_req = True
        elif path == "/reboot":
            reboot_req = True
            body = '{"ok":1,"msg":"再起動します…"}'
        elif path == "/test":
            if TEST_MODE:
                led.on()
                led_off_t = time.ticks_add(time.ticks_ms(), 200)
                log_event("試験", "LEDのみ点灯（試験モード中のためチャイム送信せず）")
                body = json.dumps({"ok": 0, "msg": "試験モード中（testm=1）のため本番チャイム箱は鳴らしません（本体LEDのみ点灯）。鳴らすには「調整」で試験モードを 0 にしてください。"})
            else:
                send_chime("IN")
                log_event("試験", "チャイム試験を送信")
                body = json.dumps({"ok": 1, "msg": "チャイム試験を送信しました"})
        elif path == "/recal":
            recal_req = True
            body = '{"ok":1,"msg":"基準距離を取り直します…"}'
        elif path == "/reset":
            in_count = out_count = 0
            log_event("リセット", "件数を0に")
            body = '{"ok":1,"msg":"件数を0に戻しました"}'
        else:
            import gc
            gc.collect()
            mid = (OTA_HTML % (VERSION, ota_info(), APP_NAME)).encode()
            head = ("HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\n"
                    "Content-Length: %d\r\nConnection: close\r\n\r\n" % (len(PAGE_A) + len(mid) + len(PAGE_B))).encode()
            for part in (head, PAGE_A, mid, PAGE_B):
                send_all(cl, part)
            return
        data = body.encode()
        body = None
        head = ("HTTP/1.0 200 OK\r\nContent-Type: %s\r\nCache-Control: no-store\r\n"
                "Content-Length: %d\r\nConnection: close\r\n\r\n" % (ctype, len(data))).encode()
        if len(data) <= 2048:
            send_all(cl, head + data)
        else:
            send_all(cl, head)
            send_all(cl, data)
    except Exception as e:
        if isinstance(e, MemoryError):
            web_err[0] += 1
    finally:
        try:
            cl.close()
        except Exception:
            pass


# ---------------------------------------------------------------- 起動
wait_sensors_boot(500)
wifi_connect()
udp_setup()
web_setup()
hb_setup()
dA = dB = None
occA = occB = False
in_count = out_count = 0
y_in = y_out = 0
baseA, baseB, _blk = calibrate()
_calibrated = True
last_calib = mono() - (RECALIB_S - 60 if _blk else 0)
last_wifi_check = mono()
last_ntp_try = mono()
today = jst()[2] if clock_ok() else None
log_event("起動", "TSD10版%s（%s）" % (VERSION, "試験モード・鳴らさず" if TEST_MODE else "本番モード"))
_ra, _rb = logical_raw(0), logical_raw(1)
log_event("センサー", "A:%s B:%s" % (
    ("未受信(配線/2.2kΩ確認)" if _ra is None else ("測距外65535" if _ra == 65535 else "%dmm" % _ra)),
    ("未受信(配線/2.2kΩ確認)" if _rb is None else ("測距外65535" if _rb == 65535 else "%dmm" % _rb)),
))

# ---- 判定ロジック ----
t_last_judge = None
startA = startB = None
a_done = b_done = False
clearA_t = clearB_t = None
lastA_off = lastB_off = None
pend_in = pend_out = False
ab_first_diff = ab_last_diff = None
idle_since = mono()
cal_a, cal_b = [], []
last_cal_sample_ms = time.ticks_ms()
pre_t = None
lastB_seen = None
pre_cnt = [0, 0, 0]          # 先鳴らし [回数, 入店になった, 空振り]
occ_since = None
STATIC_S = 120

OPP_LOCK_MS = 2500
OPP_CLEAR_MS = 400
last_kind = None
last_kind_t = 0
gap_ok = True
clear_since = None


def opp_blocked(kind):
    if last_kind is None or last_kind == kind or gap_ok:
        return False
    if time.ticks_diff(now, last_kind_t) >= OPP_LOCK_MS:
        return False
    return True


def _judged(kind):
    global last_kind, last_kind_t, gap_ok
    last_kind = kind; last_kind_t = now; gap_ok = False


def judged_in(note):
    global in_count, t_last_judge, pre_t
    if opp_blocked("IN"):
        tr_res.append("(IN 見送り) " + note)
        t_last_judge = now
        return
    _judged("IN")
    quiet = in_quiet_hours()
    if pre_t is not None:
        pre_t = None
        pre_cnt[1] += 1
        note += "（先鳴らし）"
    elif not quiet:
        chime()
    in_count += 1; t_last_judge = now
    suffix = "（試験・鳴らさず）" if TEST_MODE else ("（静音）" if quiet else "")
    log_event("IN", note + suffix)
    tr_res.append("IN " + note + (" [試験]" if TEST_MODE else ""))
    post_event("in")


def judged_out(note):
    global out_count, t_last_judge
    if opp_blocked("OUT"):
        tr_res.append("(OUT 見送り) " + note)
        t_last_judge = now
        return
    _judged("OUT")
    out_count += 1; t_last_judge = now
    log_event("OUT", note)
    tr_res.append("OUT " + note)
    post_event("out")


# ---- 通過ごとの記録（3.0：距離は25mm単位＝最大6375mm、20ms間隔または状態変化時に記録） ----
TRACE_KEEP = 12
TRACE_MAX = 300             # 50Hzで約6秒分
traces = []
tr_buf = None
tr_res = []
tr_prev = 0
tr_last_occ = -1
tr_clear = None
tr_seen = 0
tr_start = ""


def _enc(d):
    return 0 if d is None else min(255, (d + TRACE_UNIT_MM // 2) // TRACE_UNIT_MM)


def trace_step():
    global tr_buf, tr_res, tr_prev, tr_last_occ, tr_clear, tr_seen, tr_start
    active = occA or occB
    occ_bits = (1 if occA else 0) | (2 if occB else 0)
    if tr_buf is None:
        if not active:
            tr_res = []
            return
        tr_buf = bytearray()
        tr_prev = now
        tr_last_occ = -1
        tr_clear = None
        tr_seen = 0
        tr_start = hhmmss()
        tr_res = tr_res[-2:]
    elapsed_ms = max(0, time.ticks_diff(now, tr_prev))
    if len(tr_buf) < TRACE_MAX * 4 and (tr_last_occ < 0 or occ_bits != tr_last_occ or elapsed_ms >= 20):
        dt = min(255, elapsed_ms // 10)
        tr_prev = time.ticks_add(tr_prev, dt * 10)
        tr_last_occ = occ_bits
        tr_buf.extend(bytes((dt, _enc(dA), _enc(dB), occ_bits)))
    tr_seen |= occ_bits
    if active:
        tr_clear = None
    elif tr_clear is None:
        tr_clear = now
    elif time.ticks_diff(now, tr_clear) > 1000:
        traces.insert(0, [tr_start, bytes(tr_buf), list(tr_res), tr_seen, baseA, baseB])
        if len(traces) > TRACE_KEEP:
            traces.pop()
        if not tr_res and tr_seen == 3:
            log_event("判定なし", "A・B とも反応したが判定できず（記録あり）")
        tr_buf = None
        tr_res = []


def reset_crossing_state():
    """ループが STALL_RESET_MS(100ms) 以上止まった後、古い途中状態で誤判定しないようリセットする"""
    global startA, startB, a_done, b_done, clearA_t, clearB_t
    global lastA_off, lastB_off, pend_in, pend_out, ab_first_diff, ab_last_diff
    startA = startB = None
    a_done = b_done = False
    clearA_t = clearB_t = None
    lastA_off = lastB_off = None
    pend_in = pend_out = False
    ab_first_diff = ab_last_diff = None
    uart_reset_state()


wd_start()
prev_loop_ms = time.ticks_ms()
_boot_diag_step = 0
_boot_diag_t0 = prev_loop_ms
try:
    while True:
        now = time.ticks_ms()
        loop_dt = time.ticks_diff(now, prev_loop_ms)
        prev_loop_ms = now

        if led_off_t is not None and time.ticks_diff(now, led_off_t) >= 0:
            led.off()
            led_off_t = None
        mono()

        # ループが100ms以上止まっていたら、溜まった受信分を読み切って最新値だけ残し途中状態をリセット
        if loop_dt > STALL_RESET_MS:
            uart_poll_all(now, skip_occ=True)
            reset_crossing_state()
        else:
            uart_poll_all(now, skip_occ=False)

        dA, dB = logical_mm(0), logical_mm(1)
        occA, occB = logical_occ(0), logical_occ(1)

        if t_last_judge is not None and time.ticks_diff(now, t_last_judge) >= REFRACTORY_MS:
            t_last_judge = None
        in_refractory = t_last_judge is not None
        sway_lock = (tr_buf is not None
                     and any(r.startswith("IN") for r in tr_res)
                     and any(r.startswith("OUT") for r in tr_res))

        if occA and occB and dA is not None and dB is not None:
            diff = dA - dB
            if ab_first_diff is None:
                ab_first_diff = diff
            ab_last_diff = diff

        sA, sB = startA, startB
        both_long = (sA is not None and sB is not None
                     and time.ticks_diff(now, sA) > WINDOW_MS
                     and time.ticks_diff(now, sB) > WINDOW_MS)

        # --- A が空いた瞬間 ---
        if not occA and startA is not None and a_done:
            if (clearB_t is not None and not in_refractory
                    and time.ticks_diff(now, clearB_t) < WINDOW_MS):
                judged_out("入口で止まったあと外へ")
                clearB_t = None
            startA = None
            a_done = False
        if not occA and startA is not None:
            gap = time.ticks_diff(sB, sA) if sB is not None else -1
            if (not in_refractory and not sway_lock and sB is not None and not b_done
                    and time.ticks_diff(now, sB) < WINDOW_MS
                    and (gap >= SHORT_LEAD_MS
                         or (0 < gap < SHORT_LEAD_MS and occB)
                         or (gap == 0 and occB and (pend_in or time.ticks_diff(now, sA) >= 160)
                             and (not DIFF_JUDGE or ab_last_diff is None or ab_last_diff >= 0)))):
                judged_in(("A→B %dms" % gap) if gap < WINDOW_MS else "立ち止まり後に店内へ")
                if occB:
                    b_done = True
            elif (not in_refractory and not sway_lock and not occB and sB is not None and not b_done
                    and DIFF_JUDGE and gap == 0 and 160 <= time.ticks_diff(now, sB) < WINDOW_MS
                    and ab_first_diff is not None and ab_last_diff is not None
                    and ab_last_diff - ab_first_diff >= 50 and ab_first_diff <= 0 and ab_last_diff >= 30):
                judged_in("A→B 同時")
                b_done = True
            elif both_long:
                clearA_t = now
            elif (clearB_t is not None and not in_refractory
                    and time.ticks_diff(now, clearB_t) < WINDOW_MS):
                judged_out("立ち話のあと外へ")
                clearB_t = None
            if t_last_judge != now and sB is None:
                lastA_off = now
            else:
                lastA_off = None
            startA = None

        # --- B が空いた瞬間 ---
        if not occB and startB is not None and b_done:
            if both_long:
                clearB_t = now
            startB = None
            b_done = False
        if not occB and startB is not None:
            gap = time.ticks_diff(sA, sB) if sA is not None else -1
            if (not in_refractory and t_last_judge != now and sA is not None and not a_done
                    and time.ticks_diff(now, sA) < WINDOW_MS
                    and (gap >= SHORT_LEAD_MS
                         or (0 < gap < SHORT_LEAD_MS and occA)
                         or (gap == 0 and occA and (pend_out or time.ticks_diff(now, sB) >= 160)))):
                judged_out("B→A %dms" % gap)
                lastA_off = None
                if occA:
                    a_done = True
            elif (not in_refractory and t_last_judge != now and not occA and sA is not None and not a_done
                    and DIFF_JUDGE and gap == 0 and 160 <= time.ticks_diff(now, sA) < WINDOW_MS
                    and ab_first_diff is not None and ab_last_diff is not None
                    and ab_first_diff - ab_last_diff >= 30 and (ab_first_diff >= 0 or ab_last_diff <= -20)):
                judged_out("B→A 同時")
                lastA_off = None
            elif both_long:
                clearB_t = now
            elif (clearA_t is not None and not occA and not in_refractory and not sway_lock
                    and time.ticks_diff(now, clearA_t) < WINDOW_MS):
                judged_in("立ち話のあと店内へ")
                clearA_t = None
            if t_last_judge != now and sA is None:
                lastB_off = now
            else:
                lastB_off = None
            startB = None

        if not (occA and occB):
            ab_first_diff = ab_last_diff = None
        if not occA and not occB:
            pend_in = pend_out = False

        if clearA_t is not None and time.ticks_diff(now, clearA_t) >= WINDOW_MS:
            clearA_t = None
        if clearB_t is not None and time.ticks_diff(now, clearB_t) >= WINDOW_MS:
            clearB_t = None

        # --- A・B が同時に遮られない通過（A が空いてから B が遮られた） ---
        if (occB and startB is None and lastA_off is not None
                and (not occA or (startA is None and time.ticks_diff(now, lastA_off) < SIMUL_GAP_MS))):
            if occA:
                pend_in = True
            elif not in_refractory and not sway_lock and time.ticks_diff(now, lastA_off) < GAP_MS:
                judged_in("A→B（すき間 %dms）" % time.ticks_diff(now, lastA_off))
                b_done = True
            lastA_off = None
        if (occA and startA is None and lastB_off is not None
                and (not occB or (startB is None and time.ticks_diff(now, lastB_off) < SIMUL_GAP_MS))):
            if occB:
                pend_out = True
            elif not in_refractory and time.ticks_diff(now, lastB_off) < GAP_MS:
                judged_out("B→A（すき間 %dms）" % time.ticks_diff(now, lastB_off))
                a_done = True
            lastB_off = None
        if lastA_off is not None and time.ticks_diff(now, lastA_off) >= GAP_MS:
            lastA_off = None
        if lastB_off is not None and time.ticks_diff(now, lastB_off) >= GAP_MS:
            lastB_off = None

        # --- 早め判定：A が先に遮られていて、B が遮られた瞬間に入店 ---
        if (EARLY_IN and occB and startB is None and startA is not None and not a_done
                and t_last_judge != now and not in_refractory and not sway_lock
                and time.ticks_diff(now, startA) >= SHORT_LEAD_MS
                and time.ticks_diff(now, startA) < WINDOW_MS):
            judged_in("A→B 早め %dms" % time.ticks_diff(now, startA))
            a_done = b_done = True
        elif (EARLY_IN and DIFF_JUDGE and occA and occB and startA is not None and startB is not None
                and not a_done and not b_done and t_last_judge != now and not in_refractory and not sway_lock
                and time.ticks_diff(startB, startA) == 0
                and 150 <= time.ticks_diff(now, startA) < WINDOW_MS
                and ab_first_diff is not None and ab_first_diff <= 0
                and ab_last_diff is not None and ab_last_diff >= 30
                and ab_last_diff - ab_first_diff >= 50):
            judged_in("A→B 早め（同時）%dms" % time.ticks_diff(now, startA))
            a_done = b_done = True

        # --- 逆向き判定の見送り用 ---
        if occA or occB:
            clear_since = None
        else:
            if clear_since is None:
                clear_since = now
            elif time.ticks_diff(now, clear_since) >= OPP_CLEAR_MS:
                gap_ok = True

        # --- 通過ごとの記録 ---
        trace_step()

        # --- 先鳴らし ---
        if occB:
            lastB_seen = now
        elif lastB_seen is not None and time.ticks_diff(now, lastB_seen) >= PRE_QUIET_MS:
            lastB_seen = None
        if (PRE_RING and occA and startA is None and not occB and pre_t is None
                and lastB_seen is None and t_last_judge is None and not in_quiet_hours()):
            chime()
            pre_t = now
            pre_cnt[0] += 1
            tr_res.append("先鳴らし" + ("(試験)" if TEST_MODE else ""))
        if pre_t is not None and time.ticks_diff(now, pre_t) >= PRE_KEEP_MS:
            pre_t = None
            pre_cnt[2] += 1
            log_event("空振り", "先鳴らししたが入店にならず")

        # --- 遮られ始めを記録 ---
        if occA and startA is None:
            startA = now
            if t_last_judge is not None and time.ticks_diff(now, t_last_judge) < 250:
                a_done = True
        if occB and startB is None:
            startB = now
            if t_last_judge is not None and time.ticks_diff(now, t_last_judge) < 250:
                b_done = True

        # --- 日付が変わったら今日の件数を昨日へ ---
        if clock_ok():
            d = jst()[2]
            if today is None:
                today = d
            elif d != today:
                today = d
                y_in, y_out = in_count, out_count
                in_count = out_count = 0
                log_event("日替り", "昨日 入%d / 出%d" % (y_in, y_out))

        # --- Wi-Fi 監視（登録されている2つのWi-Fiのうち電波がある方へ自動再接続） ---
        if HAS_NET and wifi_candidates():
            if not wifi_ok():
                led.value((now // 500) % 2)
            if mono() - last_wifi_check > 30:
                last_wifi_check = mono()
                if not wifi_ok():
                    log_event("Wi-Fi", "再接続を試行")
                    if wifi_connect():
                        udp_setup()
                        if web_sock is None:
                            web_setup()
            if not clock_ok() and mono() - last_ntp_try > 300 and wifi_ok():
                last_ntp_try = mono()
                try:
                    ntptime.settime()
                    log_event("時刻", "時刻合わせができました")
                except Exception:
                    pass
                wd_feed()

        # --- センサーの受信が5秒以上途絶えたら UART を自動で開き直す ---
        uart_recover(now)

        # --- 基準距離の取り直し（定期 or 状態ページから） ---
        if occA or occB:
            idle_since = mono()
            if cal_a:
                del cal_a[:]; del cal_b[:]
            if occ_since is None:
                occ_since = mono()
            elif mono() - occ_since > STATIC_S:
                baseA, baseB, _blk = calibrate((baseA, baseB), accept=True)
                last_calib = mono()
                occ_since = None
                prev_loop_ms = time.ticks_ms()
        else:
            occ_since = None
            if time.ticks_diff(now, last_cal_sample_ms) >= 50:
                last_cal_sample_ms = now
                cal_a.append(dA); cal_b.append(dB)
                if len(cal_a) > CALIB_SAMPLES:
                    cal_a.pop(0); cal_b.pop(0)
            if recal_req:
                recal_req = False
                baseA, baseB, _blk = calibrate((baseA, baseB))
                last_calib = mono() - (RECALIB_S - 60 if _blk else 0)
                prev_loop_ms = time.ticks_ms()
            elif mono() - last_calib > RECALIB_S and mono() - idle_since > 30 and len(cal_a) >= CALIB_SAMPLES:
                baseA, baseB, _blk = base_from([x for x in cal_a if x], [x for x in cal_b if x], len(cal_a), (baseA, baseB))
                last_calib = mono() - (RECALIB_S - 60 if _blk else 0)

        # --- 起動直後（2秒後・5秒後）に USB シリアル（Thonny / 診断ツール）へ 1秒あたり件数を2回だけ出力 ---
        if _boot_diag_step < 2:
            _bd_ms = time.ticks_diff(now, _boot_diag_t0)
            if (_boot_diag_step == 0 and _bd_ms >= 2100) or (_boot_diag_step == 1 and _bd_ms >= 5100):
                _boot_diag_step += 1
                _hza, _hzb = _pair_logical(u_hz)
                _cea, _ceb = _pair_logical(u_cerr)
                _ooa, _oob = _pair_logical(u_oor)
                _ip = wlan().ifconfig()[0] if wifi_ok() else "-"
                print("[TSD10診断] A:%d件/秒(%s,err=%d,65535=%d) | B:%d件/秒(%s,err=%d,65535=%d) | IP:%s" % (
                    _hza, ("%dmm" % dA) if dA else ("65535" if logical_raw(0) == 65535 else "--"), _cea, _ooa,
                    _hzb, ("%dmm" % dB) if dB else ("65535" if logical_raw(1) == 65535 else "--"), _ceb, _oob,
                    _ip))

        # --- 状態ページ ---
        web_poll()
        hb_poll()
        wd_feed()
        if reboot_req:
            log_event("再起動", "状態ページから")
            time.sleep_ms(500)
            machine.reset()
        ota_mark_ok(mono())

        time.sleep_ms(SAMPLE_MS)
except KeyboardInterrupt:
    wd_stop()
    raise
