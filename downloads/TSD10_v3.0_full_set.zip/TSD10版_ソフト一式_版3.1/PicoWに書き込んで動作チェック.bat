@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

set "PYEXE="
set "PYARG="
python -c "import sys" >nul 2>nul
if not errorlevel 1 set "PYEXE=python"
if not defined PYEXE (
    py -3 -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PYEXE=py"
        set "PYARG=-3"
    )
)
if not defined PYEXE (
    if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PYEXE=%LOCALAPPDATA%\Python\bin\python.exe"
)
if not defined PYEXE (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if exist "%%~fD\python.exe" set "PYEXE=%%~fD\python.exe"
    )
)
if not defined PYEXE (
    echo [ERROR] Python not found on this PC.
    echo Open Chrome or Edge to flash Pico W directly in your browser:
    echo   https://msmttng.github.io/nyuten-tsd10-manual/flash.html
    echo.
    pause
    exit /b 1
)

"%PYEXE%" %PYARG% -c "import serial" >nul 2>nul
if errorlevel 1 (
    echo Installing pyserial...
    "%PYEXE%" %PYARG% -m pip install pyserial
)

"%PYEXE%" %PYARG% -c "import glob,runpy,sys; p=glob.glob('*/flash_and_check_tsd10.py')[0]; sys.argv=[p]+sys.argv[1:]; runpy.run_path(p, run_name='__main__')" %*
if "%~1"=="" (
    echo.
    pause
)
