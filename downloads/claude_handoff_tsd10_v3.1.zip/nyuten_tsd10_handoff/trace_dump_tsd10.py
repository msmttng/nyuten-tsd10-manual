# -*- coding: utf-8 -*-
"""
TSD10版（版3.0 / 版3.1以降）および VL53版（版2.5以降）両対応の読み取り専用・通過記録ダンプツール
※ Pico の動作・カウント・チャイム鳴動には一切影響を与えません（GET /s, /wcfg, /trace のみ使用）。

使い方:
  python trace_dump_tsd10.py 192.168.1.20
  python trace_dump_tsd10.py 192.168.100.2
"""
import json
import sys
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ip = sys.argv[1] if len(sys.argv) > 1 else "192.168.1.20"


def get_json(path):
    url = "http://%s%s" % (ip, path)
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def main():
    s = get_json("/s")
    is_tsd = ("hza" in s) or ("ora" in s)
    kind = "TSD10 LiDAR版" if is_tsd else "VL53L0X版"
    mode_str = "試験モード(鳴らさず記録のみ)" if s.get("testm") else "本番モード(チャイム鳴動ON)"

    print("=== センサー箱 状態サマリー (%s / %s) ===" % (ip, kind))
    print("  版番号      : %s  [%s]" % (s.get("ver"), mode_str))
    print("  接続Wi-Fi   : %s  (RSSI: %s dBm / 稼働: %s秒)" % (
        s.get("wssid") or "(未取得)", s.get("rssi"), s.get("up")
    ))
    print("  本日カウント: 入店 %s 回 / 退店 %s 回  (昨日: 入 %s / 退 %s)" % (
        s.get("in"), s.get("out"), s.get("yin", 0), s.get("yout", 0)
    ))
    if "pre_n" in s:
        print("  先鳴らし内訳: 合計 %s 回 (入店確定 %s / 5秒空振り %s)" % (
            s.get("pre_n", 0), s.get("pre_hit", 0), s.get("pre_miss", 0)
        ))
    print("  距離 A(ドア): 現在 %s mm / 基準 %s mm / 遮り=%s" % (
        s.get("da"), s.get("ba"), s.get("oa")
    ))
    print("  距離 B(店内): 現在 %s mm / 基準 %s mm / 遮り=%s  (感度drop=%smm)" % (
        s.get("db"), s.get("bb"), s.get("ob"), s.get("drop")
    ))
    if is_tsd:
        print("  UART通信 A  : %s 件/秒 (チェックサム失敗=%s, 65535測距外=%s)" % (
            s.get("hza"), s.get("ea"), s.get("ora")
        ))
        print("  UART通信 B  : %s 件/秒 (チェックサム失敗=%s, 65535測距外=%s)" % (
            s.get("hzb"), s.get("eb"), s.get("orb")
        ))

    ch = s.get("ch") or {}
    print("  チャイム箱  : 生存=%s / 版=%s / 音量=%s / 曲=%s / 受けた・鳴らした・失敗・省略=%s" % (
        ch.get("ok"), ch.get("ver"), ch.get("vol"), ch.get("trk"), ch.get("cnt")
    ))

    # 版3.1以降の Wi-Fi スロット登録状況（SSID名と有無のみ・パスワードは返らない仕様）
    try:
        wcfg = get_json("/wcfg")
        slots = wcfg.get("w") or []
        slot_desc = ", ".join(
            "#%d=%s(%s)" % (idx + 1, row[0] or "未登録", "PW済" if row[1] else "PW空")
            for idx, row in enumerate(slots)
        )
        print("  登録Wi-Fi枠 : %s" % slot_desc)
    except Exception:
        pass

    lst = get_json("/trace")
    print("\n=== 通過波形記録 (%d 件) ===" % len(lst))
    for i, _meta in enumerate(lst):
        d = get_json("/trace?i=%d" % i)
        unit = int(d.get("unit_mm") or d.get("unit") or (25 if is_tsd else 10))
        b = bytes.fromhex(d.get("hex", ""))
        print(
            "\n#%d 時刻=%s 判定=%s 反応=%s サンプル数=%d (単位=%dmm) 基準A=%s B=%s"
            % (i, d.get("t"), d.get("res"), d.get("seen"), len(b) // 4, unit, d.get("ba"), d.get("bb"))
        )
        t_ms = 0
        for k in range(0, len(b), 4):
            dt, a, bb, f = b[k:k + 4]
            t_ms += dt * 10
            a_str = "  --" if a == 0 else "%4d" % (a * unit)
            b_str = "  --" if bb == 0 else "%4d" % (bb * unit)
            occ_str = "%s%s" % ("A" if (f & 1) else ".", "B" if (f & 2) else ".")
            print("  %5dms  A=%smm  B=%smm  [%s]" % (t_ms, a_str, b_str, occ_str))


if __name__ == "__main__":
    main()
