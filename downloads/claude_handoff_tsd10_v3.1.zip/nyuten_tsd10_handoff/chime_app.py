# -*- coding: utf-8 -*-
# 入店チャイム チャイム箱（Pico WH + DFPlayer Mini + 小型スピーカー）
# Pico には app.mpy（このファイルを mpy-cross で変換したもの）として入れる。main.py は起動役、Wi-Fi は wifi_secret.py
# LAN の UDP "CHIME IN <seq>" を受けて microSD の mp3 を鳴らす。センサー箱へ10秒ごとに「生きてるよ」を送る。
# 必ず UTF-8（BOMなし）で保存すること。
#
# 配線:
#   Pico VBUS(5V, 40番) → DFPlayer VCC      Pico GND(38番) → DFPlayer GND
#   Pico GP0 (1番ピン) → 1kΩ → DFPlayer RX   Pico GP1 (2番ピン) ← DFPlayer TX
#   DFPlayer SPK_1 / SPK_2 → 8Ω スピーカー
#   microSD: /mp3/0001.mp3, 0002.mp3 … にチャイム音（番号はセンサー箱のページで選ぶ）

APP_ID = "nyuten-chime"
APP_NAME = "チャイム箱"
APP_TAG = "@@VER:2.4|2026-10-23 15:40@@"   # 版と作成日時（更新ページで表示。ここだけ書き換える）
# 2.4: 受けた・鳴らした・失敗・間隔で省略 の回数をセンサー箱へ知らせる（鳴らし漏れの切り分け用）
# 2.3: Antigravity のレビュー指摘を反映（6日以上の休み明けに鳴らない・同じ入店で2回鳴る・Wi-Fi が戻らないときの再起動・
#      SD 挿し直し後の表示・更新中の電源断・ページの安全対策）
VERSION, BUILD = APP_TAG[6:-2].split("|")

import network, socket, time, json
from machine import UART, Pin

WIFI_SSID = ""
WIFI_PASS = ""
try:
    from wifi_secret import WIFI_SSID, WIFI_PASS   # パスワードは別ファイル（更新しても消えない）
except ImportError:
    pass
UDP_PORT = 5005
HB_PORT = 5006          # センサー箱へ「生きてるよ」を送る先
HB_EVERY_S = 10
VOLUME = 20             # 0〜30（センサー箱のページから変更）
TRACK = 1               # /mp3/0001.mp3
DEDUP_MS = 10000        # 同じ番号（seq）の通知はこの間1回だけ鳴らす（再送・遅れて届いた分を無視）
MIN_INTERVAL_MS = 1000
SD_OK = False
NTRACKS = 0
CONF = "chime.json"
CNT = [0, 0, 0, 0]      # 起動から：入店の通知を受けた・鳴らした・鳴らせなかった・間隔が短くて省略

try:
    with open(CONF) as f:
        _c = json.load(f)
        VOLUME = max(0, min(30, int(_c.get("vol", VOLUME))))
        TRACK = max(1, min(99, int(_c.get("trk", TRACK))))
except Exception:
    try:
        with open("vol.txt") as f:
            VOLUME = max(0, min(30, int(f.read().strip())))
    except Exception:
        pass


def conf_save():
    try:
        with open(CONF, "w") as f:
            json.dump({"vol": VOLUME, "trk": TRACK}, f)
    except Exception:
        pass


_mono_s = 0
_mono_ms = 0
_mono_last = time.ticks_ms()


def mono():
    """起動からの秒数。時刻合わせ（NTP）で時計が飛んでも狂わない。ループで頻繁に呼ぶこと"""
    global _mono_s, _mono_ms, _mono_last
    n = time.ticks_ms()
    d = time.ticks_diff(n, _mono_last)
    _mono_last = n
    if d > 0:
        _mono_ms += d
        _mono_s += _mono_ms // 1000
        _mono_ms %= 1000
    return _mono_s


led = Pin("LED", Pin.OUT)
uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

# ---------------------------------------------------------------- 見張り（固まったら自動で再起動）
import os, machine
from machine import Timer
WD_TIMEOUT_MS = 30000      # これだけ動きが止まったら再起動
_wd_last = time.ticks_ms()
_wd_timer = None


def wd_feed():
    global _wd_last
    _wd_last = time.ticks_ms()


def _wd_check(t):
    if time.ticks_diff(time.ticks_ms(), _wd_last) > WD_TIMEOUT_MS:
        try:
            with open("wd_reset.txt", "a") as f:
                f.write("%d\n" % time.time())
        except Exception:
            pass
        machine.reset()


def wd_start():
    global _wd_timer
    wd_feed()
    _wd_timer = Timer(-1)
    _wd_timer.init(period=2000, mode=Timer.PERIODIC, callback=_wd_check)


def wd_stop():
    if _wd_timer is not None:
        _wd_timer.deinit()


# ---------------------------------------------------------------- プログラム更新（ブラウザから）
def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def ota_receive(cl, buf):
    """POST /upload の本文（.mpy）を app_new.mpy に保存。(成功?, メッセージ) を返す。
    大きなメモリを一度に使わないよう、少しずつ受け取りながら中身を確かめる"""
    import gc
    gc.collect()
    while b"\r\n\r\n" not in buf:
        if len(buf) > 4096:
            return False, "見出しが長すぎます"
        wd_feed()
        more = cl.recv(512)
        if not more:
            return False, "受信が途中で切れました（見出し）"
        buf += more
    head, body = buf.split(b"\r\n\r\n", 1)
    n = 0
    for line in head.split(b"\r\n"):
        if line.lower().startswith(b"content-length:"):
            n = int(line.split(b":")[1])
    if n <= 0 or n > 120000:
        return False, "ファイルの大きさが正しくありません（%d）" % n
    idb = APP_ID.encode()
    found_id = False
    tag = b""
    tail = b""
    got = 0
    first = b""
    with open("app_new.mpy", "wb") as f:
        chunk = body
        while True:
            if chunk:
                f.write(chunk)
                got += len(chunk)
                if len(first) < 4:
                    first = (first + chunk)[:4]
                win = tail + chunk                 # 区切れ目をまたいでも見つかるように前の末尾をつなぐ
                if not found_id and idb in win:
                    found_id = True
                if not tag:
                    i = win.find(b"@@VER:")
                    j = win.find(b"@@", i + 6) if i >= 0 else -1
                    if j > 0:
                        tag = win[i + 6:j]
                tail = win[-80:]
            if got >= n:
                break
            wd_feed()
            chunk = cl.recv(min(1024, n - got))
            if not chunk:
                break
    gc.collect()
    if got != n:
        os.remove("app_new.mpy")
        return False, "途中で切れました（%d / %d バイト）。もう一度送ってください" % (got, n)
    if first[:1] != b"M":
        os.remove("app_new.mpy")
        return False, "形式が違います（.mpy のファイルを選んでください）"
    if not found_id:
        os.remove("app_new.mpy")
        return False, "%s用のプログラムではありません。ファイルを確かめてください" % APP_NAME
    v = tag.decode().split("|") if tag else ["不明", "不明"]
    return True, "受け取りました：版 %s（%s 作成）。「更新を適用」を押すと切り替わります" % (v[0], v[1] if len(v) > 1 else "不明")


def _tag_of(data):
    i = data.find(b"@@VER:")
    j = data.find(b"@@", i + 6) if i >= 0 else -1
    if i < 0 or j < 0:
        return ("不明", "不明")
    v = data[i + 6:j].decode().split("|")
    return (v[0], v[1] if len(v) > 1 else "不明")


def _tag_file(fn):
    """ファイルを少しずつ読んで版の印を探す"""
    tail = b""
    with open(fn, "rb") as f:
        while True:
            c = f.read(1024)
            if not c:
                break
            w = tail + c
            if b"@@VER:" in w and w.find(b"@@", w.find(b"@@VER:") + 6) > 0:
                return _tag_of(w)
            tail = w[-80:]
    return ("不明", "不明")


def now_str():
    t = time.localtime(time.time() + 9 * 3600)
    if t[0] < 2024:
        return "時刻不明"
    return "%d/%d %02d:%02d" % (t[1], t[2], t[3], t[4])


def ota_info():
    """更新欄に出す文：今の版・作成日時・最後に更新した日時・未適用のファイル"""
    s = "今の版 <b>%s</b>（%s 作成）" % (VERSION, BUILD)
    try:
        with open("app_updated.txt") as f:
            s += "<br>最後に更新：" + f.read().strip()
    except OSError:
        s += "<br>最後に更新：記録なし（Thonny で入れた版）"
    if _exists("crash.txt") and _exists("app_bad.mpy"):
        s += "<br><span style='color:var(--hot)'>前回の更新は起動に失敗したため、自動で元の版に戻しました</span>"
    if _exists("app_new.mpy"):
        try:
            v = _tag_file("app_new.mpy")
            s += "<br><span style='color:var(--hot)'>受け取り済み・未適用：版 %s（%s 作成）</span>" % v
        except Exception:
            pass
    return s


def ota_apply():
    # 途中で電源が切れても困らない順番：①「正常」の印を先に消す ②入れ替え。
    # app.mpy が無い状態で止まっても、main.py が app_new.mpy / app_prev.mpy から立て直す
    if not _exists("app_new.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    try:
        v = _tag_file("app_new.mpy")
        with open("app_updated.txt", "w") as f:
            f.write("%s　版 %s → %s" % (now_str(), VERSION, v[0]))
    except Exception:
        pass
    if _exists("crash.txt"):
        os.remove("crash.txt")
    if _exists("app_prev.mpy"):
        os.remove("app_prev.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_prev.mpy")
    os.rename("app_new.mpy", "app.mpy")
    return True


def ota_rollback():
    if not _exists("app_prev.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    try:
        with open("app_updated.txt", "w") as f:
            f.write("%s　前の版に戻した" % now_str())
    except Exception:
        pass
    return True


_ok_marked = False


def ota_mark_ok(uptime_s):
    """起動して60秒動けたら「この版は正常」と記録（main.py の自動戻しの判断に使う）"""
    global _ok_marked
    if _ok_marked or uptime_s < 60:
        return
    _ok_marked = True
    try:
        if not _exists("app_ok.flag"):
            with open("app_ok.flag", "w") as f:
                f.write(VERSION)
    except Exception:
        pass
    launcher_update()


# @@LAUNCHER-BEGIN（sync_launcher.py が main.py の中身をここへ写す。手で直さない）
LAUNCHER = """# -*- coding: utf-8 -*-
# 入店チャイム 起動役（センサー箱・チャイム箱 共通）。Pico に main.py として保存する。
# 本体のプログラムは app.mpy。更新後の app.mpy が起動に失敗したら、自動で前の版（app_prev.mpy）に戻す。
# 起動役 版 2（2026-10-23）：更新の途中で電源が切れたときの立て直し、更新直後の部品不足でも前の版に戻す
# 必ず UTF-8（BOMなし）で保存すること。
import os, sys, time, machine


def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def _crash(e):
    try:
        with open("crash.txt", "w") as f:
            sys.print_exception(e, f)
    except Exception:
        pass


def _rollback():
    # 更新したばかり（まだ「正常」の印が無い）で、前の版が残っていれば戻す
    if _exists("app_ok.flag") or not _exists("app_prev.mpy"):
        return False
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    return True


# 更新の途中で電源が切れて app.mpy が無いときの立て直し
if not (_exists("app.mpy") or _exists("app.py")):
    if _exists("app_new.mpy"):
        os.rename("app_new.mpy", "app.mpy")
        print("更新の途中だったので、新しい版の適用を済ませました")
    elif _exists("app_prev.mpy"):
        os.rename("app_prev.mpy", "app.mpy")
        print("app.mpy が無かったので、前の版を使います")

try:
    if not (_exists("app.mpy") or _exists("app.py")):
        print("app.mpy がありません。Thonny の「表示」→「ファイル」で app.mpy を Pico に入れてください")
        print("（名前が sensor_app.mpy / chime_app.mpy のままなら、右クリック →「リネーム」で app.mpy に）")
        raise SystemExit
    import app
except (KeyboardInterrupt, SystemExit):
    raise
except ImportError as e:
    if _rollback():
        _crash(e)
        print("新しい版に必要なファイルが無いため（%s）、前の版に戻して再起動します" % e)
        time.sleep(5)
        machine.reset()
    # 部品ファイルが足りないときは、再起動を繰り返さずに止める（Thonny で直せるように）
    print("必要なファイルが Pico にありません:", e)
    print("センサー箱なら vl53l0x.py、両方とも wifi_secret.py が入っているか確認してください")
    raise SystemExit
except Exception as e:
    sys.print_exception(e)
    _crash(e)
    if _rollback():
        print("新しい版で起動できなかったため、前の版に戻して再起動します")
    else:
        print("エラーで止まったため、5秒後に再起動します")
    time.sleep(5)
    machine.reset()
"""
# @@LAUNCHER-END


def launcher_update():
    """起動役 main.py を、この版に入っている最新のものに入れ替える（Thonny 無しで main.py も更新するため）。
    この版が60秒正常に動いたあとにだけ呼ぶ。一時ファイルに書いてから名前を変えるので、途中で電源が切れても壊れない"""
    try:
        try:
            with open("main.py") as f:
                if f.read() == LAUNCHER:
                    return
        except OSError:
            pass
        with open("main.tmp", "w") as f:
            f.write(LAUNCHER)
        try:
            os.rename("main.tmp", "main.py")
        except OSError:
            os.remove("main.py")
            os.rename("main.tmp", "main.py")
        print("起動役 main.py を新しくしました")
    except Exception as e:
        print("main.py の更新に失敗:", e)


def http_send(cl, body, ctype="application/json"):
    data = body.encode() if isinstance(body, str) else body
    head = ("HTTP/1.0 200 OK\r\nContent-Type: %s\r\nCache-Control: no-store\r\n"
            "Content-Length: %d\r\nConnection: close\r\n\r\n" % (ctype, len(data)))
    cl.send(head.encode())
    mv = memoryview(data)
    i = 0
    while i < len(data):
        k = cl.send(mv[i:i + 1024])
        if not k:
            break
        i += k


OTA_HTML = """<div class="c"><details><summary><b>プログラム更新</b>　<small>版 %s</small></summary>
<small>%s</small><br>
<small>新しい %s 用のファイル（.mpy）を選んで「送る」→「更新を適用」。起動に失敗したら自動で前の版に戻ります。</small><br>
<input type="file" id="up" accept=".mpy" style="margin-top:8px;max-width:100%%"><br>
<button onclick="upl()">送る</button><button onclick="if(confirm('新しい版に切り替えて再起動しますか？'))apl('/apply')">更新を適用</button>
<button onclick="if(confirm('ひとつ前の版に戻して再起動しますか？'))apl('/rollback')">前の版に戻す</button>
<br><small id="um"></small></details></div>
<script>
function upl(){var f=document.getElementById('up').files[0],m=document.getElementById('um');if(!f){m.textContent='ファイルを選んでください';return}
window.PAUSE=1;var x=new XMLHttpRequest();x.open('POST','/upload');x.timeout=60000;
x.upload.onprogress=function(e){if(e.lengthComputable)m.textContent='送信中… '+Math.round(e.loaded/e.total*100)+'%%'};
x.onload=function(){window.PAUSE=0;try{m.textContent=JSON.parse(x.responseText).msg}catch(e){m.textContent='返事が読めません: '+x.status}};
x.onerror=function(){window.PAUSE=0;m.textContent='送信に失敗しました（Wi-Fi が切れたか、箱が応答しません）。ページを再読み込みしてもう一度'};
x.ontimeout=function(){window.PAUSE=0;m.textContent='時間切れです。もう一度送ってください'};
m.textContent='送信中…';x.send(f)}
function apl(p){var m=document.getElementById('um');fetch(p,{method:'POST'}).then(function(r){return r.json()}).then(function(r){m.textContent=r.msg;if(r.ok)setTimeout(function(){location.reload()},25000)})}
</script>"""


ERR = {1: "準備中", 2: "スリープ中", 3: "通信エラー", 4: "チェックサム", 5: "曲番号が範囲外",
       6: "曲が見つからない", 7: "SD挿入エラー", 8: "SD読み取り失敗", 10: "スリープに入った"}


def df_cmd(cmd, p=0, wait=150):
    # 応答あり（feedback=1）で送り、DFPlayer の返事を返す。診断で鳴った方式と同じ
    buf = bytearray([0x7E, 0xFF, 0x06, cmd, 0x01, (p >> 8) & 0xFF, p & 0xFF, 0, 0, 0xEF])
    chk = (-sum(buf[1:7])) & 0xFFFF
    buf[7] = (chk >> 8) & 0xFF
    buf[8] = chk & 0xFF
    uart.read()                  # 古い受信データを捨てる
    uart.write(buf)
    time.sleep_ms(wait)
    raw = uart.read()
    out = []
    i = 0
    while raw and i + 9 < len(raw):
        if raw[i] == 0x7E and raw[i + 9] == 0xEF:
            out.append((raw[i + 3], (raw[i + 5] << 8) | raw[i + 6]))
            i += 10
        else:
            i += 1
    return out


def df_init():
    r0 = df_cmd(0x0C, 0, 3000)   # DFPlayer をリセットして起動を待つ（診断と同じ手順）
    r = df_cmd(0x06, VOLUME)     # 音量
    print("DFPlayer:", "OK" if r else "返事なし（配線を確認）")
    global SD_OK, NTRACKS
    sd = [p for c, p in r0 if c == 0x3F]
    SD_OK = bool(sd and (sd[0] & 0x02))
    if SD_OK:
        n = [p for c, p in df_cmd(0x48) if c == 0x48]
        NTRACKS = n[0] if n else 0
        print("SDカード: OK  曲の数:", NTRACKS)
    else:
        NTRACKS = 0
        print("SDカード: 見つかりません → 奥までカチッと挿さっているか、FAT32 か確認")


def play_track(n):
    # まず /mp3/000n.mp3、見つからなければ SD の n 曲目（フォルダ無関係）を再生
    global SD_OK, NTRACKS
    if NTRACKS and n > NTRACKS:
        print("  音 %d は SD にありません（%d曲）→ 1番で鳴らします" % (n, NTRACKS))
        n = 1                                  # 入っていない番号を選んでも無音にしない
    for cmd, label in ((0x12, "mp3フォルダ"), (0x03, "SDの曲順")):
        r = df_cmd(cmd, n, 300)
        errs = [p for c, p in r if c == 0x40]
        if r and not errs:
            if cmd == 0x03:
                print("  ※ mp3/%04d.mp3 が見つからず、SD の %d 曲目で再生しました" % (n, n))
            if not SD_OK:                      # SD を挿し直したあと鳴った → 表示も「OK」に戻す
                SD_OK = True
                cnt = [q for k, q in df_cmd(0x48) if k == 0x48]
                NTRACKS = cnt[0] if cnt else NTRACKS
                print("  SD カードが読めるようになりました（%d曲）" % NTRACKS)
            return True
        if not r:                            # 返事なし → DFPlayer を起動し直して次へ
            print("  返事なし → DFPlayer を再起動")
            df_init()
        else:
            print("  %s で再生失敗:" % label, [ERR.get(e, e) for e in errs])
            if 1 in errs or 7 in errs or 8 in errs:
                SD_OK = False
                print("  → SD カードが読めていません。SD を奥までカチッと挿し直してください")
    return False


def wifi():
    try:
        import rp2
        rp2.country("JP")
    except Exception:
        pass
    w = network.WLAN(network.STA_IF)
    w.active(True)
    try:
        w.config(pm=0xa11140)    # 省電力オフ（接続が安定する）
    except Exception:
        pass
    tries = 0
    while not w.isconnected():
        tries += 1
        if tries > 12:                  # 約3分つながらない → Wi-Fi 部品ごと立て直すため再起動
            print("Wi-Fi に3分つながらないため再起動します")
            time.sleep(1)
            machine.reset()
        if tries > 1:
            w.active(False); time.sleep_ms(300); w.active(True)   # Wi-Fi 部品を入れ直してから再試行
        w.connect(WIFI_SSID, WIFI_PASS)
        for _ in range(30):
            if w.isconnected():
                break
            led.toggle(); wd_feed(); time.sleep(0.5)
    led.off()
    print("WiFi:", w.ifconfig()[0])
    try:
        import ntptime
        ntptime.settime()          # 更新日時の記録用
    except Exception:
        pass
    return w



PAGE = """<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>チャイム箱</title><style>
:root{--bg:#f4f3ef;--fg:#222;--mut:#8a8884;--card:#fff;--acc:#1d9e75;--hot:#d85a30;--trk:#e6e4de}
@media(prefers-color-scheme:dark){:root{--bg:#1a1a19;--fg:#eee;--mut:#9a9890;--card:#262624;--trk:#3a3a38}}
body{margin:0;padding:16px;font-family:-apple-system,system-ui,sans-serif;background:var(--bg);color:var(--fg)}
.c{background:var(--card);border-radius:14px;padding:14px;margin-bottom:12px}small{color:var(--mut);font-size:13px}
button{font-size:15px;padding:10px 12px;border-radius:10px;border:1px solid var(--trk);background:var(--card);color:var(--fg);margin:8px 6px 0 0}
</style></head><body>
<div class="c"><b>チャイム箱</b><br><small id="st">読み込み中…</small><br>
<button onclick="fetch('/test',{method:'POST'})">試しに鳴らす</button></div>
<script>function u(){if(window.PAUSE)return;fetch('/s',{cache:'no-store'}).then(function(r){return r.json()}).then(function(s){
document.getElementById('st').innerHTML=(s.cnt?'起動から 受けた '+s.cnt[0]+'・鳴らした '+s.cnt[1]+'・失敗 '+s.cnt[2]+'・間隔で省略 '+s.cnt[3]+'<br>':'')+'音量 '+s.vol+'・音 '+s.trk+'・SD '+(s.sd?'OK（'+s.n+'曲）':'読めない')+'<br>版 '+s.ver+'・稼働 '+Math.floor(s.up/60)+'分<br>音量と音はセンサー箱のページの「調整」で変えます'})}
setInterval(u,3000);u();</script><!--OTA--></body></html>"""

web_sock = None
reboot_req = False
POST_ONLY = ("/test", "/apply", "/rollback")


def web_setup():
    global web_sock
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", 80))
        s.listen(2)
        s.setblocking(False)
        web_sock = s
    except Exception as e:
        print("ページ起動失敗:", e)


def web_poll():
    global reboot_req
    if web_sock is None:
        return
    try:
        cl, _ = web_sock.accept()
    except OSError:
        return
    try:
        cl.settimeout(3)
        req = cl.recv(1024)
        if not req:
            return
        line = req.split(b"\r\n", 1)[0].decode()
        parts = line.split(" ")
        path = (parts[1] if len(parts) > 1 else "/").split("?")[0]
        if path in POST_ONLY and not line.startswith("POST"):
            # 鳴らす・更新など状態を変える操作は POST だけ（ブラウザの先読みや履歴から勝手に動かないように）
            http_send(cl, json.dumps({"ok": 0, "msg": "この操作はページのボタンから行ってください"}))
        elif path == "/s":
            http_send(cl, json.dumps({"vol": VOLUME, "trk": TRACK, "sd": SD_OK, "n": NTRACKS,
                                      "ver": VERSION, "up": mono(), "cnt": CNT}))
        elif path == "/test":
            play_track(TRACK)
            http_send(cl, '{"ok":1}')
        elif path == "/upload" and line.startswith("POST"):
            try:
                ok, msg = ota_receive(cl, req)
            except Exception as e:
                ok, msg = False, "受信中にエラー: %r（もう一度送ってください）" % (e,)
                try:
                    os.remove("app_new.mpy")
                except OSError:
                    pass
            print("更新:", msg)
            http_send(cl, json.dumps({"ok": ok, "msg": msg}))
        elif path == "/apply":
            ok = ota_apply()
            http_send(cl, json.dumps({"ok": ok, "msg": "新しい版で再起動します。25秒ほどで再表示します" if ok else "先にファイルを送ってください"}))
            reboot_req = ok
        elif path == "/rollback":
            ok = ota_rollback()
            http_send(cl, json.dumps({"ok": ok, "msg": "前の版に戻して再起動します" if ok else "前の版がありません"}))
            reboot_req = ok
        else:
            import gc
            gc.collect()                # 大きなページを組み立てる前にメモリを整理
            http_send(cl, PAGE.replace("<!--OTA-->", OTA_HTML % (VERSION, ota_info(), APP_NAME)), "text/html; charset=utf-8")
    except Exception as e:
        print("ページ処理エラー:", e)
    finally:
        try:
            cl.close()
        except Exception:
            pass


hb_sock = None
hb_t = None


def hb_send():
    """センサー箱へ ALIVE CHIME <sd> <vol> <trk> <曲数> <版>"""
    global hb_sock, hb_t
    if hb_t is not None and mono() - hb_t < HB_EVERY_S:
        return
    hb_t = mono()
    try:
        if hb_sock is None:
            hb_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            hb_sock.setsockopt(socket.SOL_SOCKET, 0x20, 1)   # SO_BROADCAST
        msg = "ALIVE CHIME %d %d %d %d %s %d %d %d %d" % ((1 if SD_OK else 0, VOLUME, TRACK, NTRACKS, VERSION) + tuple(CNT))
        hb_sock.sendto(msg.encode(), ("255.255.255.255", HB_PORT))
    except Exception as e:
        print("生存通知の送信失敗:", e)
        try:
            hb_sock.close()             # 作り直す前に閉じる（使い捨てると枠が尽きる）
        except Exception:
            pass
        hb_sock = None


df_init()
w = wifi()
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", UDP_PORT))
sock.settimeout(0.1)
web_setup()
print("受信待機 UDP/%d" % UDP_PORT)

last_seq = None
last_seq_t = None       # 最後に受けた seq の時刻（ticks）。長い休み明けの桁あふれを避けるため、古くなったら None
last_play_t = None      # 最後に鳴らした時刻（ticks）

wd_start()
try:
    while True:
        wd_feed()
        mono()
        web_poll()
        hb_send()
        if reboot_req:
            time.sleep_ms(500)
            machine.reset()
        ota_mark_ok(mono())
        t = time.ticks_ms()
        if last_seq_t is not None and time.ticks_diff(t, last_seq_t) >= DEDUP_MS:
            last_seq_t = None
        if last_play_t is not None and time.ticks_diff(t, last_play_t) >= MIN_INTERVAL_MS:
            last_play_t = None
        try:
            data, addr = sock.recvfrom(128)
        except OSError:
            if not w.isconnected():
                w = wifi()
            continue
        try:
            p = data.decode().split()
        except Exception:
            continue
        if len(p) < 2 or p[0] != "CHIME":
            continue
        if p[1] in ("VOL", "TRK") and len(p) >= 3:       # センサー箱のページから音量・音を変更
            try:
                v = int(p[2])
            except ValueError:
                continue
            test = len(p) >= 4 and p[3] == "T"
            if p[1] == "VOL":
                v = max(0, min(30, v))
                if v != VOLUME:
                    VOLUME = v
                    df_cmd(0x06, VOLUME)
                    conf_save()
                    print("音量を変更:", VOLUME)
            else:
                v = max(1, min(99, v))
                if v != TRACK:
                    TRACK = v
                    conf_save()
                    print("音を変更:", TRACK)
            if test:
                play_track(TRACK)                          # 試しに1回鳴らす
            hb_t = None                                    # すぐ新しい状態を知らせる
            continue
        if p[1] != "IN":
            continue
        try:
            seq = int(p[2]) if len(p) > 2 else None
        except ValueError:
            seq = None
        now = time.ticks_ms()
        if seq is not None and seq == last_seq and last_seq_t is not None:
            continue                                       # 同じ入店の再送（センサー箱は最大6発送る）
        last_seq, last_seq_t = seq, now
        CNT[0] += 1
        if last_play_t is not None:
            CNT[3] += 1
            continue                                       # 鳴らしたばかり
        last_play_t = now
        print("IN from", addr[0])
        led.on(); ok = play_track(TRACK); time.sleep_ms(200); led.off()
        CNT[1 if ok else 2] += 1
        last_seq_t = time.ticks_ms()      # 重複除けは鳴らし終えた時刻から数える（DFPlayer の立て直しで遅れても2回鳴らない）
except KeyboardInterrupt:
    wd_stop()     # Thonny で止めたときは見張りも止める
    raise
