# -*- coding: utf-8 -*-
"""
TSD10版 3.1 ファームウェア (sensor_app.py) のデスクトップ単体・結合シミュレーションテスト（全13項目）
MicroPython の machine / time.ticks_ms / socket / network をモックし、
実際の main loop と UART 4バイトフレーム処理・Wi-Fi 2件自動切替・Wi-Fi OTA更新・UART自動復旧を検証する。
"""
import binascii
import json
import os
import sys
import time as real_time
import types

_HERE = os.path.dirname(os.path.abspath(__file__))

# ---- MicroPython 互換モック環境を構築 ----
sim_ms = [1000]


def ticks_ms():
    return sim_ms[0] & 0x3FFFFFFF


def ticks_add(t, delta):
    return (t + delta) & 0x3FFFFFFF


def ticks_diff(t1, t2):
    d = (t1 - t2) & 0x3FFFFFFF
    if d >= 0x20000000:
        d -= 0x40000000
    return d


def sleep_ms(ms):
    sim_ms[0] += ms
    # 起動時の calibrate ループ中に 20ms ごとに壁フレームを供給できるようフック呼び出し
    if _auto_feed_fn[0] is not None:
        _auto_feed_fn[0](ms)


real_time.ticks_ms = ticks_ms
real_time.ticks_add = ticks_add
real_time.ticks_diff = ticks_diff
real_time.sleep_ms = sleep_ms
real_time.sleep = lambda s: sleep_ms(int(s * 1000))
real_time.localtime = real_time.gmtime  # MicroPython の time.localtime() は UTC 基準（JST変換はコード側 +TZ_OFFSET）

_auto_feed_fn = [None]


def make_tsd10_frame(dist_mm):
    b1 = dist_mm & 0xFF
    b2 = (dist_mm >> 8) & 0xFF
    cs = (~(b1 + b2)) & 0xFF
    return bytes((0x5C, b1, b2, cs))


# データシート例 5C 02 11 EC -> 0x1102 = 4354 mm の検算
assert make_tsd10_frame(0x1102) == bytes((0x5C, 0x02, 0x11, 0xEC)), "データシート例と不一致"
assert make_tsd10_frame(0xFFFF) == bytes((0x5C, 0xFF, 0xFF, 0x01)), "65535フレーム検算不一致"


class FakePin:
    OUT = 1
    IN = 0

    def __init__(self, pin_id, mode=0, pull=0, value=0):
        self.pin_id = pin_id
        self.val = value

    def on(self):
        self.val = 1

    def off(self):
        self.val = 0

    def toggle(self):
        self.val ^= 1

    def value(self, v=None):
        if v is not None:
            self.val = int(bool(v))
        return self.val


class FakeUART:
    instances = {}

    def __init__(self, bus, baudrate=460800, tx=None, rx=None, rxbuf=1024):
        self.bus = bus
        self.baudrate = baudrate
        self.tx = tx
        self.rx = rx
        self.rxbuf = rxbuf
        self.buf = bytearray()
        FakeUART.instances[bus] = self

    def feed(self, data: bytes):
        self.buf.extend(data)
        if len(self.buf) > self.rxbuf:
            del self.buf[:len(self.buf) - self.rxbuf]

    def any(self):
        return len(self.buf)

    def readinto(self, mv):
        n = min(len(mv), len(self.buf))
        if n > 0:
            mv[:n] = self.buf[:n]
            del self.buf[:n]
        return n


class FakeTimer:
    PERIODIC = 1

    def __init__(self, tid):
        self.tid = tid

    def init(self, period=1000, mode=1, callback=None):
        self.cb = callback

    def deinit(self):
        pass


class StopMainLoop(BaseException):
    pass


# machine モジュール
mod_machine = types.ModuleType("machine")
mod_machine.Pin = FakePin
mod_machine.UART = FakeUART
mod_machine.PWM = FakePin
mod_machine.Timer = FakeTimer
mod_machine.reset = lambda: None
sys.modules["machine"] = mod_machine

# ubinascii モジュール
mod_ubinascii = types.ModuleType("ubinascii")
mod_ubinascii.hexlify = binascii.hexlify
sys.modules["ubinascii"] = mod_ubinascii

# network / ntptime / urequests / socket モック
sent_udp = []
hb_incoming = []
web_incoming = []
web_responses = []


class FakeSocket:
    AF_INET = 2
    SOCK_DGRAM = 2
    SOCK_STREAM = 1
    SOL_SOCKET = 1
    SO_REUSEADDR = 4

    def __init__(self, af=2, stype=2):
        self.stype = stype
        self.port = None
        self.req_data = b""
        self.resp_data = bytearray()

    def setsockopt(self, *args):
        pass

    def bind(self, addr):
        self.port = addr[1]

    def listen(self, n):
        pass

    def setblocking(self, flag):
        pass

    def settimeout(self, t):
        pass

    def sendto(self, data, addr):
        sent_udp.append((data.decode(), addr))

    def recvfrom(self, n):
        if self.port == 5006 and hb_incoming:
            return hb_incoming.pop(0)
        raise OSError("EAGAIN")

    def accept(self):
        if web_incoming:
            req_bytes = web_incoming.pop(0)
            cl = FakeSocket(2, 1)
            cl.req_data = req_bytes
            web_responses.append(cl)
            return cl, ("192.168.1.99", 54321)
        raise OSError("EAGAIN")

    def recv(self, n):
        if not self.req_data:
            return b""
        out = self.req_data[:n]
        self.req_data = self.req_data[n:]
        return out

    def send(self, mv):
        b = bytes(mv)
        self.resp_data.extend(b)
        return len(b)

    def close(self):
        pass


mod_socket = types.ModuleType("socket")
for attr in ("AF_INET", "SOCK_DGRAM", "SOCK_STREAM", "SOL_SOCKET", "SO_REUSEADDR"):
    setattr(mod_socket, attr, getattr(FakeSocket, attr))
mod_socket.socket = FakeSocket
sys.modules["socket"] = mod_socket

hostnames_set = []
mod_network = types.ModuleType("network")
mod_network.STA_IF = 0
mod_network.hostname = lambda h: hostnames_set.append(h)


class FakeWLAN:
    connected = True
    cur_ssid = "TEST_SSID"
    scan_results = [(b"SHOP_WIFI_2G", b"\x00" * 6, 6, -48, 3, 1)]
    connect_calls = []

    def active(self, v=None):
        return True

    def config(self, *args, **kw):
        if args and args[0] == "ssid":
            return FakeWLAN.cur_ssid
        return None

    def isconnected(self):
        return FakeWLAN.connected

    def disconnect(self):
        FakeWLAN.connected = False

    def scan(self):
        return list(FakeWLAN.scan_results)

    def connect(self, s, p):
        FakeWLAN.connect_calls.append((s, p))
        # スキャンで見えている SSID なら即座に接続成功を再現
        vis_names = [x[0].decode() for x in FakeWLAN.scan_results]
        if s in vis_names or s == "TEST_SSID":
            FakeWLAN.connected = True
            FakeWLAN.cur_ssid = s

    def ifconfig(self):
        return ("192.168.1.188", "255.255.255.0", "192.168.1.1", "8.8.8.8")

    def status(self, k):
        return -52


mod_network.WLAN = lambda mode: FakeWLAN()
sys.modules["network"] = mod_network

mod_ntptime = types.ModuleType("ntptime")
mod_ntptime.settime = lambda: None
sys.modules["ntptime"] = mod_ntptime

mod_urequests = types.ModuleType("urequests")
sys.modules["urequests"] = mod_urequests

mod_wifi_secret = types.ModuleType("wifi_secret")
mod_wifi_secret.WIFI_SSID = "TEST_SSID"
mod_wifi_secret.WIFI_PASS = "DUMMY"
sys.modules["wifi_secret"] = mod_wifi_secret

# 一時作業ディレクトリで動かす（settings.json 等が汚れないよう）
import tempfile
work_dir = tempfile.mkdtemp(prefix="tsd10_sim_")
os.chdir(work_dir)

# 起動中の calibrate() の間、壁距離 A=1870mm, B=2450mm を 20ms ごとに供給し、
# メインループに入ったら1周目で一旦止めてステップ実行テストに切り替える
_boot_phase = [True]
_acc_ms = [0]


def _boot_feeder(ms):
    _acc_ms[0] += ms
    while _acc_ms[0] >= 20:
        _acc_ms[0] -= 20
        if 1 in FakeUART.instances:
            FakeUART.instances[1].feed(make_tsd10_frame(1870))  # 物理0 = UART1 = ドア側A
        if 0 in FakeUART.instances:
            FakeUART.instances[0].feed(make_tsd10_frame(2450))  # 物理1 = UART0 = 店内側B
    if not _boot_phase[0]:
        raise StopMainLoop()


_auto_feed_fn[0] = _boot_feeder

# sensor_app.py を読み込んで起動シーケンスを完了させる（同フォルダまたは隣接の ソース/ を自動探索）
_CAND_SRCS = [
    os.path.join(_HERE, "sensor_app.py"),
    os.path.join(_HERE, "ソース", "sensor_app.py"),
    os.path.abspath(os.path.join(_HERE, "..", "ソース", "sensor_app.py")),
]
SRC_PATH = next((p for p in _CAND_SRCS if os.path.exists(p)), _CAND_SRCS[0])
with open(SRC_PATH, "r", encoding="utf-8") as f:
    code_src = f.read()

# while True の最初の sleep_ms(SAMPLE_MS) で抜けられるよう _boot_phase を切り替え
orig_wd_start = "wd_start()\n"
assert orig_wd_start in code_src
instrumented = code_src.replace(orig_wd_start, "wd_start()\n_enter_main_cb()\n", 1)

ns = {"__name__": "__main__", "_enter_main_cb": lambda: _boot_phase.__setitem__(0, False)}
try:
    exec(compile(instrumented, "sensor_app.py", "exec"), ns)
except StopMainLoop:
    pass

_auto_feed_fn[0] = None

# ==== 検証 1: 起動直後の初期値・キャリブレーション・ホスト名 ====
assert ns["TEST_MODE"] == 1, "初期値は試験モード(1)であるべき"
assert ns["SWAP_AB"] == 0, "初期値は SWAP_AB=0 であるべき"
assert hostnames_set[-1] == "nyuten-sensor2", f"試験モード時のホスト名が不正: {hostnames_set}"
assert ns["baseA"] == 1870, f"A基準距離が不正: {ns['baseA']}"
assert ns["baseB"] == 2450, f"B基準距離(2000mm超の棚)が不正: {ns['baseB']}"
print(f"[OK] 1. 起動・基準取得 OK (baseA={ns['baseA']}mm, baseB={ns['baseB']}mm, host={hostnames_set[-1]})")

# ==== 検証 2: 分割フレーム・ゴミ混入・データ内0x5C・チェックサムエラー・50Hz計測 ====
uA = FakeUART.instances[1]  # ドア側A
uB = FakeUART.instances[0]  # 店内側B
uA.buf.clear()
uB.buf.clear()
ns["u_ok_sec"][:] = [0, 0]
ns["u_cerr"][:] = [0, 0]
ns["u_oor"][:] = [0, 0]
ns["u_hz_t"] = sim_ms[0]

# 1秒間（50フレーム × 20ms = 1000ms）供給。途中でフレーム分割と壊れたチェックサムフレーム、距離に0x5C(92)を含む値(0x055C = 1372mm -> 壁側 0x075C = 1884mm)を混ぜる
bad_frame = bytes((0x5C, 0x10, 0x20, 0x00))  # 正しいCSは ~(0x30)&0xFF = 0xCF なので不一致
uA.feed(b"\x99\xAA" + bad_frame)  # 先頭ゴミ2バイト＋チェックサム異常1件
for step in range(50):
    fA = make_tsd10_frame(1884)  # 下位バイトが 0x5C (= 1884 = 0x075C)！
    fB = make_tsd10_frame(2450)
    # わざと1バイト＋3バイトに分割して流し込む
    uA.feed(fA[:1])
    sim_ms[0] += 5
    ns["uart_poll_all"](ticks_ms())
    uA.feed(fA[1:])
    uB.feed(fB)
    sim_ms[0] += 15
    ns["uart_poll_all"](ticks_ms())

assert ns["u_hz"] == [50, 50], f"50件/秒にならない: {ns['u_hz']}"
assert ns["u_cerr"] == [1, 0], f"チェックサムエラー数が不正: {ns['u_cerr']}"
assert ns["logical_mm"](0) == 1884, f"0x5Cを含む距離(1884mm)の復元失敗: {ns['logical_mm'](0)}"
print(f"[OK] 2. UARTパーサー検証 OK (hz={ns['u_hz']}, cerr={ns['u_cerr']}, 0x5Cデータ値=1884mm)")

# ==== 検証 3: 傘などの1〜2フレーム単発反応の無視 (HIT_STREAK=3) ====
# Aの閾値 = min(1870-250=1620, RANGE_A_MM=1420) = 1420mm
assert ns["_phys_thr"](0) == 1420
for _ in range(2):  # 2フレームだけ 1000mm（人未満）
    uA.feed(make_tsd10_frame(1000))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
assert ns["logical_occ"](0) is False, "2フレームではまだ人ありにならないはず"
# 3フレーム目で壁(1870mm)に戻る → リセットされるはず
uA.feed(make_tsd10_frame(1870))
sim_ms[0] += 20
ns["uart_poll_all"](ticks_ms())
assert ns["u_streak"][0] == 0 and ns["logical_occ"](0) is False
print("[OK] 3. 細い物（2フレーム以下の単発遮り）無視フィルタ OK")

# ==== 検証 4: 腕振りの途切れ保持 (手 70ms[4回] → すき間 80ms[4回] → 胴 200ms[10回]) ====
occ_history = []
# 手: 4フレーム (80ms) 1100mm
for _ in range(4):
    uA.feed(make_tsd10_frame(1100))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
    occ_history.append(ns["logical_occ"](0))
assert occ_history == [False, False, True, True], f"3回目からTrueのはず: {occ_history}"

# すき間: 4フレーム (80ms < HOLD_CLEAR_MS=140ms) 壁 1870mm
gap_occ = []
for _ in range(4):
    uA.feed(make_tsd10_frame(1870))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
    gap_occ.append(ns["logical_occ"](0))
assert all(gap_occ), f"80msの腕振りすき間で途切れてしまった: {gap_occ}"

# 胴: 6フレーム (120ms) 1100mm
torso_occ = []
for _ in range(6):
    uA.feed(make_tsd10_frame(1100))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
    torso_occ.append(ns["logical_occ"](0))
assert all(torso_occ)

# 通過完了後、壁(1870mm)が 160ms (>=140ms) 続くと解除される
for _ in range(8):
    uA.feed(make_tsd10_frame(1870))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
assert ns["logical_occ"](0) is False, "140ms経過後に解除されるはず"
print("[OK] 4. 腕振りのすき間保持（HOLD_CLEAR_MS=140ms）＆通過後解除 OK")

# ==== 検証 5: 65535（測距外）は人ありと決めつけず、人あり中なら200ms保って人なしへ戻る ====
# 誰もいないときに 65535 が連続で来ても occ=False のまま
for _ in range(15):
    uA.feed(make_tsd10_frame(0xFFFF))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
assert ns["logical_occ"](0) is False, "静止時の65535で人ありになってはいけない"

# 人あり状態にしてから 65535 を送る → 180ms時点ではTrue、220ms時点でFalseに戻る
for _ in range(3):
    uA.feed(make_tsd10_frame(1100))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
assert ns["logical_occ"](0) is True
for step in range(11):  # 11 * 20ms = 220ms
    uA.feed(make_tsd10_frame(0xFFFF))
    sim_ms[0] += 20
    ns["uart_poll_all"](ticks_ms())
    if step == 7:  # 160ms (<200ms)
        assert ns["logical_occ"](0) is True, "200ms未満では保持されるはず"
assert ns["logical_occ"](0) is False, "65535が200ms続いたら人なしに戻るはず"
print("[OK] 5. 65535（測距外）の200ms保持＆人なし自動復帰（故障時ロック防止）OK")

# ==== 検証 6: メインループ結合テスト（試験モードでの入店 A→B・チャイム箱保護・状態ページ HTML/JSON） ====
# ループの1周分を実行するヘルパー（while True の中身を取り出して実行）
loop_body_src = code_src.split("try:\n    while True:\n", 1)[1].rsplit("except KeyboardInterrupt:", 1)[0]
loop_lines = [line[8:] if line.startswith("        ") else line for line in loop_body_src.splitlines()]
# 末尾の time.sleep_ms(SAMPLE_MS) を除いて手動で時刻を進める
loop_lines = [l for l in loop_lines if "time.sleep_ms(SAMPLE_MS)" not in l]
loop_code = compile("\n".join(loop_lines), "loop_body", "exec")


def step_world(mm_a, mm_b, duration_ms):
    elapsed = 0
    while elapsed < duration_ms:
        if elapsed % 20 == 0:
            uA.feed(make_tsd10_frame(mm_a))
            uB.feed(make_tsd10_frame(mm_b))
        sim_ms[0] += 5
        elapsed += 5
        exec(loop_code, ns)


# まず200ms静止（壁）
ns["prev_loop_ms"] = ticks_ms()
step_world(1870, 2450, 300)
sent_udp.clear()

# チャイム箱からの生存通知（音量15・曲2 ＝ センサー箱の既定20・1と違う値）を受信させる
hb_incoming.append((b"ALIVE CHIME 1 15 2 5 2.4 10 10 0 0", ("192.168.1.55", 5006)))
step_world(1870, 2450, 20)
assert len(sent_udp) == 0, f"試験モード中にチャイム箱の音量・曲を上書き送信してはいけない: {sent_udp}"

# 入店シミュレーション: A遮り(300ms) → A+B重なり(200ms) → Bのみ遮り(200ms) → 空き(1200ms で /trace 確定)
in_before = ns["in_count"]
step_world(1100, 2450, 300)   # ドア側Aに人が入る
step_world(1100, 1200, 200)   # 店内側Bにも入る（早め判定）
step_world(1870, 1200, 200)   # Aが空く
step_world(1870, 2450, 1200)  # Bも空いて1秒経過 → trace保存

assert ns["in_count"] == in_before + 1, f"入店カウントが増えていない: {ns['in_count']}"
assert len(sent_udp) == 0, f"試験モード中にCHIME INを送ってはいけない: {sent_udp}"
assert len(ns["traces"]) >= 1, "通過記録(/trace)が保存されていない"
print(f"[OK] 6. 試験モード入店判定 OK (in_count={ns['in_count']}, UDP送信数=0, trace件数={len(ns['traces'])})")

# 状態ページ HTML (/), JSON (/s, /cfg, /trace?i=0), /test (試験モードブロック) を検証
for req in (
    b"GET / HTTP/1.0\r\n\r\n",
    b"GET /s HTTP/1.0\r\n\r\n",
    b"GET /cfg HTTP/1.0\r\n\r\n",
    b"GET /trace?i=0 HTTP/1.0\r\n\r\n",
    b"POST /test HTTP/1.0\r\n\r\n",
):
    web_incoming.append(req)
    step_world(1870, 2450, 10)

html_resp = web_responses[0].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8")
assert "センサー（TSD10 LiDAR）" in html_resp and "試験モード中" in html_resp
s_json = json.loads(web_responses[1].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert s_json["testm"] == 1 and s_json["ba"] == 1870 and s_json["bb"] == 2450
cfg_json = json.loads(web_responses[2].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
cfg_keys = [row[0] for row in cfg_json]
assert "testm" in cfg_keys and "hold" in cfg_keys and "streak" in cfg_keys
tr_json = json.loads(web_responses[3].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert tr_json["unit_mm"] == 25 and len(tr_json["hex"]) > 8
test_btn_json = json.loads(web_responses[4].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert test_btn_json["ok"] == 0 and len(sent_udp) == 0
print("[OK] 7. Web状態ページ HTML / JSON (/s, /cfg, /trace, /test保護) 検証 OK")

# ==== 検証 8: 本番モード (testm=0) ＋営業時間内なら UDP CHIME IN が送信されること ====
# 現在時刻が夜間(19時以降)だと営業時間外静音になるため、平日12:00 JST (UTC 03:00) に時計を固定して検証
real_time.time = lambda: 1793329200  # 2026-10-29 (木) 12:00:00 JST
web_responses.clear()
web_incoming.append(b"POST /set?testm=0 HTTP/1.0\r\n\r\n")
step_world(1870, 2450, 2000)  # 不感時間(1200ms)も経過させる
assert ns["TEST_MODE"] == 0 and not ns["in_quiet_hours"]()

step_world(1100, 2450, 300)   # 先鳴らしで CHIME IN が飛ぶ！
step_world(1100, 1200, 200)
step_world(1870, 2450, 600)
assert any(msg.startswith("CHIME IN ") for msg, _ in sent_udp), f"本番モードでCHIME INが送られていない: {sent_udp}"
print(f"[OK] 8. 本番モード切替後の UDP CHIME IN 送信検証 OK (送信パケット例: {sent_udp[0]})")

# ==== 検証 9: 退店 (B→A) ではチャイムを鳴らさず out_count だけ増えること ====
step_world(1870, 2450, 2000)
sent_udp.clear()
out_before = ns["out_count"]
step_world(1870, 1200, 300)   # 店内側Bに先に入る
step_world(1100, 1200, 200)   # ドア側Aにも入る
step_world(1100, 2450, 200)   # Bが先に空く → OUT確定
step_world(1870, 2450, 600)
assert ns["out_count"] == out_before + 1, f"退店カウントが増えていない: {ns['out_count']}"
assert len(sent_udp) == 0, f"退店でチャイムが鳴ってしまった: {sent_udp}"
print(f"[OK] 9. 退店（B→A）無音カウント検証 OK (out_count={ns['out_count']}, UDP送信数=0)")

# ==== 検証 10: ループが 100ms 以上止まった後の古い途中状態リセット ====
step_world(1870, 2450, 2000)
step_world(1100, 2450, 100)   # Aに入りかけ (startA がセットされる)
assert ns["startA"] is not None
# Wi-Fi再接続などで 350ms ループが止まった状況を再現（その間に古いBフレームと最後の壁フレームが溜まる）
uA.feed(make_tsd10_frame(1870))
uB.feed(make_tsd10_frame(1200) + make_tsd10_frame(2450))
sim_ms[0] += 350
in_before = ns["in_count"]
exec(loop_code, ns)
assert ns["startA"] is None and ns["startB"] is None and ns["in_count"] == in_before
print("[OK] 10. 100ms超のループ停止後のバッファ一掃＆途中状態リセット検証 OK")

# ==== 検証 11: Wi-Fi 2件登録（ブラウザ /wcfg・/wset 特殊記号保持・パスワード非露出・電波スキャン自動切替） ====
web_responses.clear()
web_incoming.append(b"GET /wcfg HTTP/1.0\r\n\r\n")
step_world(1870, 2450, 10)
wcfg0 = json.loads(web_responses[-1].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert wcfg0["w"][0] == ["TEST_SSID", 1] and wcfg0["w"][1] == ["", 0]
assert "DUMMY" not in web_responses[-1].resp_data.decode("utf-8"), "パスワードがGET応答に漏れてはいけない"

# Wi-Fi①のパスワードは空欄（既存維持）のまま、Wi-Fi②にお店のWi-Fi（特殊記号入りパスワード）を追加保存
special_pw = 'Shop&Pass=123+45%"#'
payload_bytes = json.dumps({"s1": "TEST_SSID", "p1": "", "s2": "SHOP_WIFI_2G", "p2": special_pw}).encode("utf-8")
post_wset = (
    f"POST /wset HTTP/1.0\r\nContent-Type: application/json\r\nContent-Length: {len(payload_bytes)}\r\n\r\n".encode("utf-8")
    + payload_bytes
)
web_incoming.append(post_wset)
step_world(1870, 2450, 10)
wset_res = json.loads(web_responses[-1].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert wset_res["ok"] == 1, f"/wset 保存失敗: {wset_res}"

# パスワードが setlog や /s に一切露出せず、内部スロットには正確に保存されていること
slots_now = ns["wifi_slots"]()
assert slots_now[0] == ["TEST_SSID", "DUMMY"], f"Wi-Fi①の既存パスワードが維持されていない: {slots_now[0]}"
assert slots_now[1] == ["SHOP_WIFI_2G", special_pw], f"Wi-Fi②の特殊記号パスワード不一致: {slots_now[1]}"
for row in ns["setlog_read"]():
    assert special_pw not in row and "DUMMY" not in row

# 場所をお店へ移動した想定：Wi-Fi切断 → スキャンで SHOP_WIFI_2G だけ見えている状態で wifi_connect() を呼ぶと一発で2つ目に接続！
FakeWLAN.connected = False
FakeWLAN.connect_calls.clear()
FakeWLAN.scan_results = [(b"SHOP_WIFI_2G", b"\x00" * 6, 6, -45, 3, 1)]
assert ns["wifi_connect"]() is True
assert FakeWLAN.connect_calls[0] == ("SHOP_WIFI_2G", special_pw), f"見えている2つ目のWi-Fiが最優先されていない: {FakeWLAN.connect_calls}"
assert ns["wifi_cur_ssid"] == "SHOP_WIFI_2G"
print("[OK] 11. Wi-Fi 2件登録（特殊記号保持・パスワード非露出・電波スキャン自動切替）検証 OK")

# ==== 検証 12: 机上片側遮り中(>1.5秒)でも固まらない Wi-Fi 経由 OTA アップデート（実物 .mpy チャンク転送＆適用） ====
# 机上で A だけが 600mm のモニターを 2.5秒間 ずっと見ている（occA=True, occB=False）状態を再現
step_world(600, 2450, 2500)
assert ns["occA"] is True and ns["occB"] is False

_CAND_MPYS = [
    os.path.join(_HERE, "センサー箱_TSD10版3.1.mpy"),
    os.path.join(_HERE, "sensor_tsd10_v3.1.mpy"),
    os.path.join(_HERE, "app.mpy"),
    os.path.abspath(os.path.join(_HERE, "..", "更新ファイル", "センサー箱_TSD10版3.1.mpy")),
    os.path.abspath(os.path.join(_HERE, "..", "TSD10_センサー箱に入れる", "app.mpy")),
]
mpy_path = next((p for p in _CAND_MPYS if os.path.exists(p)), _CAND_MPYS[0])
with open(mpy_path, "rb") as f:
    real_mpy = f.read()
# ダミーの現行 app.mpy を置いておく
with open("app.mpy", "wb") as f:
    f.write(b"M\x06\x00\x1fOLD_V3.0_DUMMY_nyuten-sensor-tsd10_@@VER:3.0|2026-10-30 21:00@@")

upload_req = (
    f"POST /upload HTTP/1.0\r\nContent-Length: {len(real_mpy)}\r\n\r\n".encode("utf-8")
    + real_mpy
)
web_responses.clear()
web_incoming.append(upload_req)
step_world(600, 2450, 15)  # 片側遮り中でも 1.5秒超えていれば即応答する！
assert len(web_responses) == 1, "片側が1.5秒以上遮られている机上状態でWeb/OTAが応答しなかった"
up_json = json.loads(web_responses[-1].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert up_json["ok"] is True and "3.1" in up_json["msg"], f"OTAアップロード失敗: {up_json}"

web_incoming.append(b"POST /apply HTTP/1.0\r\n\r\n")
step_world(600, 2450, 15)
ap_json = json.loads(web_responses[-1].resp_data.split(b"\r\n\r\n", 1)[1].decode("utf-8"))
assert ap_json["ok"] is True and ns["reboot_req"] is True
assert os.path.exists("app_prev.mpy") and open("app.mpy", "rb").read() == real_mpy
assert os.path.exists("wifi_extra.json"), "OTA適用後に登録済み2件のWi-Fi設定が消えてはいけない"
ns["reboot_req"] = False
print(f"[OK] 12. Wi-Fi経由 OTA 更新（実物 {len(real_mpy):,} bytes .mpy 転送・適用・設定維持・机上遮り時即応答）検証 OK")

# ==== 検証 13: センサー無応答時の UART 自動再初期化（uart_recover）＆復帰記録 ====
step_world(1870, 2450, 500)
old_uart_a = FakeUART.instances[1]
# センサーAだけ6秒間フレームが途絶えた状態を再現
for _ in range(300):  # 300 * 20ms = 6000ms
    uB.feed(make_tsd10_frame(2450))
    sim_ms[0] += 20
    exec(loop_code, ns)
assert ns["u_down"][0] is True and FakeUART.instances[1] is not old_uart_a, "UART1が自動再初期化されていない"
# 新しい UART インスタンスにフレームが再び届くと自動復帰する
uA = FakeUART.instances[1]
step_world(1870, 2450, 200)
assert ns["u_down"][0] is False and ns["dA"] == 1870
print("[OK] 13. UART 無応答時の自動再初期化（uart_recover）＆自動復帰検証 OK")

print("\n=== 全13項目の単体・結合シミュレーションテスト 100% 合格 ===")
