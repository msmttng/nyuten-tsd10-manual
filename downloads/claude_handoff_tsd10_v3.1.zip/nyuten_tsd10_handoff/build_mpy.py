# -*- coding: utf-8 -*-
"""
TSD10版 センサー箱 ビルドスクリプト
- main.py の内容を sensor_app.py の LAUNCHER 定数へ同期確認
- mpy-cross (-b 6.1 -msmall-int-bits=31) で app.mpy と OTA用 .mpy を生成
  （※ Windows 版 mpy-cross.exe の日本語パス制限を回避するため一時ASCIIパス経由で変換）
- TSD10_センサー箱に入れる/ フォルダに app.mpy, main.py, wifi_secret.py を揃える
"""
import os
import shutil
import subprocess
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_HERE) == "ソース":
    BASE_DIR = os.path.dirname(_HERE)  # TSD10版_箱
    SRC_DIR = _HERE
    DEPLOY_DIR = os.path.join(BASE_DIR, "TSD10_センサー箱に入れる")
    OTA_DIR = os.path.join(BASE_DIR, "更新ファイル")
    PROJECT_ROOT = os.path.dirname(BASE_DIR)  # 入店チャイム
    WIFI_SECRET_SRC = os.path.join(PROJECT_ROOT, "v2_センサー箱に入れる", "wifi_secret.py")
else:
    # フラットな引き継ぎフォルダ (nyuten_tsd10_handoff 等) で実行された場合
    BASE_DIR = _HERE
    SRC_DIR = _HERE
    DEPLOY_DIR = _HERE
    OTA_DIR = _HERE
    WIFI_SECRET_SRC = ""

SRC_APP = os.path.join(SRC_DIR, "sensor_app.py")
SRC_MAIN = os.path.join(SRC_DIR, "main.py")


def build():
    os.makedirs(DEPLOY_DIR, exist_ok=True)
    os.makedirs(OTA_DIR, exist_ok=True)

    with open(SRC_MAIN, "r", encoding="utf-8") as f:
        main_txt = f.read()
    with open(SRC_APP, "r", encoding="utf-8") as f:
        app_txt = f.read()

    # BOM が混入していないか確認
    assert not main_txt.startswith("\ufeff"), "main.py に BOM が付いています"
    assert not app_txt.startswith("\ufeff"), "sensor_app.py に BOM が付いています"

    # LAUNCHER の中身を main.py と一致させる
    marker_b = '# @@LAUNCHER-BEGIN（main.py と同じ内容を保持）\nLAUNCHER = """'
    marker_e = '"""\n# @@LAUNCHER-END'
    ib = app_txt.find(marker_b)
    ie = app_txt.find(marker_e)
    if ib >= 0 and ie > ib:
        new_app = app_txt[:ib + len(marker_b)] + main_txt + app_txt[ie:]
        if new_app != app_txt:
            with open(SRC_APP, "w", encoding="utf-8", newline="\n") as f:
                f.write(new_app)
            app_txt = new_app
            print("LAUNCHER を main.py と同期しました")

    # 版番号を読み取る
    i1 = app_txt.find("@@VER:")
    i2 = app_txt.find("@@", i1 + 6)
    ver = app_txt[i1 + 6:i2].split("|")[0]

    # 一時 ASCII パスで mpy-cross を実行
    tmp_dir = tempfile.mkdtemp(prefix="tsd10_mpy_")
    try:
        tmp_py = os.path.join(tmp_dir, "sensor_app.py")
        tmp_mpy = os.path.join(tmp_dir, "app.mpy")
        shutil.copyfile(SRC_APP, tmp_py)
        cmd = [
            sys.executable, "-m", "mpy_cross",
            "-b", "6.1",
            "-msmall-int-bits=31",
            "-s", "sensor_app.py",
            "-o", tmp_mpy,
            tmp_py,
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            print("mpy-cross エラー:", res.stderr, file=sys.stderr)
            sys.exit(1)

        with open(tmp_mpy, "rb") as f:
            mpy_bytes = f.read()

        # ヘッダと識別タグを検証
        assert mpy_bytes[:4] == b"M\x06\x00\x1f", f"不正な mpy ヘッダ: {mpy_bytes[:4]!r}"
        assert b"nyuten-sensor-tsd10" in mpy_bytes, "APP_ID が mpy 内に見つかりません"
        assert b"@@VER:" in mpy_bytes, "版タグが mpy 内に見つかりません"

        dst_app_mpy = os.path.join(DEPLOY_DIR, "app.mpy")
        dst_ota_mpy = os.path.join(OTA_DIR, f"センサー箱_TSD10版{ver}.mpy")
        shutil.copyfile(tmp_mpy, dst_app_mpy)
        shutil.copyfile(tmp_mpy, dst_ota_mpy)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    # main.py を配置（フラット構成で同一パスの場合はスキップ）
    dst_main = os.path.join(DEPLOY_DIR, "main.py")
    if os.path.abspath(SRC_MAIN) != os.path.abspath(dst_main):
        shutil.copyfile(SRC_MAIN, dst_main)

    # wifi_secret.py を中身を読まずにそのままファイルコピー
    dst_wifi = os.path.join(DEPLOY_DIR, "wifi_secret.py")
    if WIFI_SECRET_SRC and os.path.exists(WIFI_SECRET_SRC):
        shutil.copyfile(WIFI_SECRET_SRC, dst_wifi)
        wifi_note = "コピー完了（中身は非表示）"
    else:
        wifi_note = "スキップ（フラット構成または元ファイルなし）"

    print(f"ビルド成功: TSD10版 {ver}")
    print(f"  app.mpy : {dst_app_mpy} ({len(mpy_bytes):,} bytes, header={list(mpy_bytes[:4])})")
    print(f"  OTA用   : {dst_ota_mpy}")
    print(f"  main.py : {dst_main}")
    print(f"  Wi-Fi   : {wifi_note}")


if __name__ == "__main__":
    build()
