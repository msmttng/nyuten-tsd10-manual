# CLAUDE.md — 入店チャイム センサー箱 TSD10版（r4 / 版3.1）

このフォルダを扱う際は、まず同階層の **`CLAUDE_HANDOVER_TSD10.md`** を全文読んでから作業を開始してください。

## 1. 最重要ルール（文字コード・安全・本番保護）

1. **文字コード（文字化け防止・絶対厳守）**
   - `.py` `.md` `.html` `.json` はすべて **UTF-8（BOM なし）・改行 LF（`\n`）** で保存すること。
   - PowerShell 5.1 の `Set-Content` / `Out-File` / `>` リダイレクトは文字化けするため**使用禁止**。
   - Python から `open(path, "w", encoding="utf-8", newline="\n")` で書き出し、編集後は必ず以下の文字化け検査を通すこと：
     ```powershell
     python -X utf8 -c "import sys,pathlib; bad=['\ufffd','\u7e5d','\u7e67','\u8b41','\u8737']; [print(p, 'NG' if any(b in pathlib.Path(p).read_text(encoding='utf-8') for b in bad) else 'OK') for p in sys.argv[1:]]" sensor_app.py
     ```
2. **機密保護**
   - 実運用用の `wifi_secret.py` や Pico 内の `wifi_extra.json`（Wi-Fi パスワード）は**絶対に読んだり表示したり Git / ZIP に含めたりしないこと**。
3. **実機・店頭機器の安全保護**
   - 読み取り系（`GET /`, `/s`, `/cfg`, `/wcfg`, `/trace`, `/trace?i=N`）は自由に実行してよい。
   - 状態変更・再起動・OTA 適用系（`POST /set`, `/wset`, `/recal`, `/test`, `/reset`, `/reboot`, `/upload`, `/apply`, `/rollback`）は**必ず事前にユーザーの了承を得てから実行すること**（`/apply` は1回のみ実行し、失敗時に連打しない）。
   - 店舗で現行 VL53L0X 本番機（`192.168.100.2`）と並べて並行試験する間は、TSD10版は必ず **`TEST_MODE = 1`（試験モード ON・ホスト名 `nyuten-sensor2`・本番チャイム箱 `192.168.100.6` を鳴らさない）** を維持すること。
4. **コード変更前のバックアップとピンポイント編集**
   - `sensor_app.py` を編集する前は `_backups/sensor_app.py.YYYYMMDD_bak` にコピーを残し、未読のまま上書きしないこと。

## 2. よく使うコマンド（検証・ビルド・記録取得）

- **全13項目の単体・結合シミュレーションテスト（実機不要・約1秒）**:
  ```powershell
  python -X utf8 test_tsd10_firmware.py
  ```
- **`.mpy` ビルド（`main.py` 同期 ＋ `mpy-cross -b 6.1 -msmall-int-bits=31` ＋ ヘッダ `M\x06\x00\x1f` 検証）**:
  ```powershell
  python -X utf8 build_mpy.py
  ```
- **稼働中の TSD10 センサー箱から状態＆25mm単位の通過波形を読む（読み取り専用）**:
  ```powershell
  python -X utf8 trace_dump_tsd10.py 192.168.1.20
  ```
- **Wi-Fi 経由 OTA 更新（ユーザーの了承後のみ実行）**:
  ```powershell
  curl.exe -s -m 10 http://192.168.1.20/s
  curl.exe -s -m 60 -H "Expect:" -H "Content-Type: application/octet-stream" --data-binary "@更新ファイル/センサー箱_TSD10版3.1.mpy" http://192.168.1.20/upload
  curl.exe -s -m 10 -X POST http://192.168.1.20/apply
  ```
