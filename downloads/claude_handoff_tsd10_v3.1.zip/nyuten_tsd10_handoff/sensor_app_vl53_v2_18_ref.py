# -*- coding: utf-8 -*-
# 入店チャイム センサー箱  Raspberry Pi Pico WH + VL53L0X（ToF測距、〜2m）x2
# Pico には app.mpy（このファイルを mpy-cross で変換したもの）として入れる。main.py は起動役、Wi-Fi は wifi_secret.py
# 1つの小箱に2つのToFセンサーを約10cm離して入れ、通路を横から測る。
# 外側(A)→内側(B)の順に通過したときだけチャイム（LAN経由）。B→A(退店)は無音でカウント。
# iPhone 等のブラウザで http://<このPicoのIP>/ を開くと状態ページが見られる。
# 必ず UTF-8（BOMなし）で保存すること。
#
# 依存: vl53l0x.py （MicroPython用ドライバ）を Pico に同じ階層で置く
#       https://github.com/kevinmcaleer/vl53l0x  の vl53l0x.py（start/read/set_measurement_timing_budget を使用）

APP_ID = "nyuten-sensor"
APP_NAME = "センサー箱"
APP_TAG = "@@VER:2.18|2026-10-28 15:45@@"   # 版と作成日時（更新ページで表示。ここだけ書き換える）
# 2.18: ドア側Aが約1.3mより先の人を見逃す → センサーを「遠距離モード」（VCSEL 18/14）にする（調整の lr：0=しない 1=Aだけ 2=A・B両方）
# 2.17: 出ていく人が店内側Bに映ってから数秒ドア付近にいると、ドア側Aで先鳴らししてしまった（10/28 14:49・15:03）→ Bが反応してから5秒は先鳴らししない（調整で変更可）
# 2.16: 10分ごとの基準の取り直しで約4秒センサーを見ていなかった（その間の入店を逃す）→ ふだんの測定値から計算し、止まらないようにする
# 2.15: 先鳴らし（ドア側 A に人が入った瞬間に鳴らす。数えるのは今までどおり B まで確かめてから）
# 2.14: 状態ページを起動時に bytes にしておき、組み立てずに分けて送る（長く動かすとメモリが細切れになり、ページが開けなくなる対策）
# 2.13: 調整の「保存」は変えた項目だけ送る（古い画面から保存して他の設定が昔の値に戻るのを防ぐ）。鳴らす時間を平日・土曜とも 8:45 からに
# 2.7: 壁が測れるようになり A・B が同時に反応しやすくなったため、距離差で向きを推測する判定を既定で止める（出る人で鳴る対策）。
#      同じ人の通過中に逆向きの判定が続けて出ないようにする
# 2.6: 営業時間（平日9〜19時・土曜9〜15時・日曜休み）の外はチャイムを鳴らさない、A・B同時検知/同時解除・すき間2重カウント/AB重なり後のすき間誤発火防止・センサー前での揺れ誤発火防止・通信/LED待ち排除・JS構文エラー修正
# 2.5: 通過ごとの自動記録（/trace）、前に人がいるときは基準を変えない、チャイム箱の鳴らした回数を表示
# 2.4: Antigravity のレビュー指摘を反映（2人続けて入店・6日以上の休み明け・ゆっくり通過・測定時間の設定・
#      更新中の電源断・センサー不調からの自動復旧・時刻合わせの遅れ・状態ページの安全対策）
VERSION, BUILD = APP_TAG[6:-2].split("|")

from machine import Pin, I2C, PWM
import time
from vl53l0x import VL53L0X

try:
    import network, urequests, ntptime, socket, json
    HAS_NET = True
except ImportError:
    HAS_NET = False

# ===== 設定 =====
# 2026-10-23 配線変更（差し込み不良対策で線を入れ替えたまま使う）:
# センサーA（外側・ドア側）: I2C1  SDA=GP6(9番ピン) SCL=GP7(10番ピン)
# センサーB（内側・店内側）: I2C0  SDA=GP4(6番ピン) SCL=GP5(7番ピン)
# 電源: A・B とも 3V3(36番ピン)、GND は A=38番 / B=33番
# ※2つのI2Cバスに分けるので VL53L0X のアドレス変更が不要
PIN_BUZZER = 16
PIN_LED = "LED"

WINDOW_MS = 1500       # 先に遮られた方から後の方までの許容時間（通過判定）
REFRACTORY_MS = 1200   # 判定後の不感時間
# 両方を WINDOW_MS より長く覆っていたら「立ち話・ゆっくり通過」とみなし、空いた順で判定する
SAMPLE_MS = 10         # ループの休み（測距そのものに約33〜50ms かかる）
TIMING_BUDGET_US = 50000   # 1回の測距時間。長いほど遠くまで安定（20000=高速・約1.2m、33000=標準、50000=壁175cm向け）
                           # ※2.3 までは部品ファイルの不具合でこの値が効いていなかった（約33msのまま）。2.4 から本当に反映
SIGNAL_LIMIT_MCPS = 0.06   # 弱い反射も採用する下限。0.25（初期値）→0.10 で約1.5m、0.06 で約2m まで届く
DROP_MM = 250          # 基準距離からこれ以上縮んだら「人がいる」
GAP_MS = 700           # A が空いてから B が遮られるまでの許容（手や細身の人で A・B が同時に遮られない場合）
SHORT_LEAD_MS = 100    # 2.10: 先に反応した側の「先行」がこれより短いときは、空いた順で確かめてから判定する（光が重なって向きを取り違える対策）
SIMUL_GAP_MS = 200     # 2.8: 片方が一瞬反応して空いた直後に A・B が同時に反応したとき、先に反応した側を先とみなす許容
NO_TARGET_MM = 1700    # 向かいの壁が測れないときに使う仮の基準（壁までの実際の距離に近い値。スマホから変更可）
MIN_VALID_MM = 40      # これ未満は異常値として無視
MAX_VALID_MM = 2000    # これ超は異常値として無視（VL53L0X は約2mまで）
CALIB_SAMPLES = 60     # 起動時に基準距離を取る回数（誰もいない状態で起動する）
RECALIB_S = 600        # 10分ごとに静止時の基準距離を取り直す

CHIME_MS = 350
PASSIVE_BUZZER = False
CHIME_HZ = 2000
LOCAL_BUZZER = False   # 本体のブザーを鳴らす場合 True。遠隔スピーカーのみなら False
QUIET_HOURS = []       # 日本時間で指定。例 [(20, 9)] = 20時〜翌9時は鳴らさない
TZ_OFFSET = 9 * 3600   # 日本時間（NTP は UTC で入るため）

WIFI_SSID = ""     # 机上テスト用。薬局に設置するときは薬局の Wi-Fi 名に変える
WIFI_PASS = ""         # ← ここにパスワードを入れる
try:
    from wifi_secret import WIFI_SSID, WIFI_PASS   # パスワードは別ファイル（更新しても消えない）
except ImportError:
    pass
HOSTNAME = "nyuten-sensor"   # ルーターの DHCP 一覧に出る名前
EVENT_URL = ""         # ログ送信先（GAS等）。空なら送らない

# 遠隔チャイム: LAN内にUDPで "CHIME IN" を投げる。受信側（チャイム箱）が音を鳴らす
UDP_TARGET = "255.255.255.255"  # ブロードキャスト。特定の受信機だけなら "192.168.1.50" 等
UDP_PORT = 5005
UDP_REPEAT = 3         # 取りこぼし対策で同じパケットを複数回送る


# ---------------------------------------------------------------- スマホから変えられる設定
# 状態ページの「調整」で変えた値は settings.json に保存され、次の起動でも使われる
CFG = {   # キー: (変数名, 型, 最小, 最大, 表示名)
    "swap":   ("SWAP_AB", int, 0, 1, "A と B の配線を入れ替える（1=GP4/5 がドア側）"),
    "drop":   ("DROP_MM", int, 50, 800, "感度（mm 縮んだら人）"),
    "wall":   ("NO_TARGET_MM", int, 300, 2000, "壁が測れないときの基準 mm"),
    "rangea": ("RANGE_A_MM", int, 0, 2000, "A が反応する一番奥 mm（0=制限なし）"),
    "rangeb": ("RANGE_B_MM", int, 0, 2000, "B が反応する一番奥 mm（0=制限なし。奥の椅子に反応しないように）"),
    "window": ("WINDOW_MS", int, 300, 5000, "通過の許容時間 ms"),
    "gap":    ("GAP_MS", int, 0, 3000, "A→B のすき間の許容 ms"),
    "refr":   ("REFRACTORY_MS", int, 300, 5000, "連続で鳴らさない時間 ms"),
    "budget": ("TIMING_BUDGET_US", int, 20000, 200000, "1回の測定時間 µs（再起動で反映）"),
    "signal": ("SIGNAL_LIMIT_MCPS", float, 0.01, 0.5, "弱い反射の下限（再起動で反映）"),
    "lr":     ("LONG_RANGE", int, 0, 2, "遠距離モード（0=しない 1=ドア側Aだけ 2=A・B両方。再起動で反映）"),
    "early":  ("EARLY_IN", int, 0, 1, "早め判定（1=店内側に入った瞬間に鳴らす）"),
    "pre":    ("PRE_RING", int, 0, 1, "先鳴らし（1=ドア側 A に入った瞬間に鳴らす。数えるのは B で確かめてから）"),
    "preq":   ("PRE_QUIET_MS", int, 0, 20000, "先鳴らしを控える時間 ms（店内側Bが反応してからこの間はドア側で先鳴らししない）"),
    "diff":   ("DIFF_JUDGE", int, 0, 1, "A・B同時のとき距離差で向きを推測（0=しない）"),
    "vol":    ("CHIME_VOL", int, 0, 30, "チャイム音量 0〜30"),
    "trk":    ("CHIME_TRK", int, 1, 99, "チャイムの音（SD の曲番号）"),
}
# 2.9: 調整の表示順と見出し（MicroPython の dict は順番が保たれないため、ここで決める）
CFG_GROUPS = (
    ("取り付け", ("swap",)),
    ("感度・見る範囲", ("drop", "rangea", "rangeb", "wall")),
    ("判定", ("pre", "preq", "early", "window", "gap", "refr", "diff")),
    ("チャイム", ("vol", "trk")),
    ("上級（ふだんは変えない・再起動で反映）", ("budget", "signal", "lr")),
)
QUIET_FROM, QUIET_TO = -1, -1
# 営業時間（日本時間）。この外は鳴らさない。開始=終了ならその曜日は休み。
# 2.9: 営業時間は変わらないので固定（状態ページの「調整」からは変えられない）。変えるときはここを直して更新する
# 2.12: 分まで指定できるように (時, 分) で書く
OPEN_WD, CLOSE_WD = (8, 45), (19, 0)     # 月〜金
OPEN_SAT, CLOSE_SAT = (8, 45), (15, 0)   # 土
OPEN_SUN, CLOSE_SUN = (0, 0), (0, 0)     # 日（休み）
CHIME_VOL = 20
EARLY_IN = 1
PRE_RING = 1            # 2.15: 先鳴らし
LONG_RANGE = 1          # 2.18: 遠距離モード（1=ドア側Aだけ）
PRE_QUIET_MS = 5000     # 2.17: B が反応してからこの時間は先鳴らししない（出ていく人がドア付近にとどまる対策）
PRE_KEEP_MS = 5000      # 2.15: 先鳴らしのあと、この時間内に入店と判定されなければ「空振り」
SWAP_AB = 1             # 2.11: 1 のとき、I2C0（GP4/5）の基板をドア側 A、I2C1（GP6/7）を店内側 B として扱う（配線を逆に付けた箱用）
RANGE_A_MM = 0          # 2.8: これより奥のものには反応しない（0=制限なし）
RANGE_B_MM = 0          # 2.8: B を店内側へ傾けて付け直したら 1200 にする（向かいの壁から50cm の椅子に座った人に反応しないように）
DIFF_JUDGE = 0          # 2.7: A・B が同時に反応したとき、距離の差で向きを推測する（外れやすいので既定はしない）
CHIME_TRK = 1
CFG_FILE = "settings.json"


def cfg_apply(d):
    global QUIET_HOURS
    changed = []
    for k, v in d.items():
        if k not in CFG:
            continue
        name, typ, lo, hi, _ = CFG[k]
        try:
            v = typ(v)
        except Exception:
            continue
        v = max(lo, min(hi, v))
        if globals()[name] != v:
            globals()[name] = v
            changed.append(k)
    QUIET_HOURS = [(QUIET_FROM, QUIET_TO)] if QUIET_FROM >= 0 and QUIET_TO >= 0 else []
    return changed


def cfg_load():
    try:
        import json as _j
        with open(CFG_FILE) as f:
            cfg_apply(_j.load(f))
    except Exception:
        pass


SETLOG_FILE = "setlog.txt"   # 2.9: 設定を変えた記録（いつ・どの端末から・何を）。直近10件を残す


def setlog_add(line):
    try:
        try:
            with open(SETLOG_FILE) as f:
                rows = f.read().split("\n")
        except OSError:
            rows = []
        rows = [r for r in rows if r][-9:] + [line]
        with open(SETLOG_FILE, "w") as f:
            f.write("\n".join(rows))
    except Exception as e:
        print("設定の記録に失敗:", e)


def setlog_read():
    try:
        with open(SETLOG_FILE) as f:
            return [r for r in f.read().split("\n") if r][::-1]
    except OSError:
        return []


def cfg_save():
    try:
        import json as _j
        with open(CFG_FILE, "w") as f:
            _j.dump({k: globals()[CFG[k][0]] for k in CFG}, f)
    except Exception as e:
        print("設定の保存に失敗:", e)


WEB_PORT = 80          # 状態ページ
EVENT_KEEP = 20        # 状態ページに出す直近の判定件数
# ===== 設定ここまで =====

_mono_s = 0
_mono_ms = 0
_mono_last = time.ticks_ms()


def mono():
    """起動からの秒数。時刻合わせ（NTP）で時計が飛んでも狂わない。ループで頻繁に呼ぶこと"""
    global _mono_s, _mono_ms, _mono_last
    n = time.ticks_ms()
    d = time.ticks_diff(n, _mono_last)
    _mono_last = n
    if d > 0:
        _mono_ms += d
        _mono_s += _mono_ms // 1000
        _mono_ms %= 1000
    return _mono_s


def clock_ok():
    return time.localtime()[0] >= 2024      # 時刻合わせ（NTP）が済んでいるか


led = Pin(PIN_LED, Pin.OUT)
if PASSIVE_BUZZER:
    buzzer = PWM(Pin(PIN_BUZZER)); buzzer.duty_u16(0)
else:
    buzzer = Pin(PIN_BUZZER, Pin.OUT); buzzer.off()

def i2c_unstick(sda, scl):
    # 途中で止められたセンサーが SDA を握ったままのことがあるので、SCL を9回たたいて解放する
    s = Pin(sda, Pin.IN, Pin.PULL_UP)
    c = Pin(scl, Pin.OPEN_DRAIN, value=1)
    for _ in range(9):
        c.value(0); time.sleep_us(10); c.value(1); time.sleep_us(10)


# ---- 測定時間（timing budget）の設定 ----
# 部品ファイル vl53l0x.py の set_measurement_timing_budget はレジスタの読み方に誤りがあり、
# 50000 では何もせず、約103000 以上では設定を壊す（2026-10-23 Antigravity レビューで判明）。
# そこで Pololu 製ライブラリ（VL53L0X.cpp）と同じ計算をここで行う。vl53l0x.py は変えない（更新はこのファイルだけで済む）
def _vcsel(t, reg):
    return (t._register(reg) + 1) << 1              # 0x50=事前測定 / 0x70=本測定 の VCSEL 周期（PCLK）


def _macro_ns(pclks):
    return ((2304 * pclks * 1655) + 500) // 1000


def _mclks_to_us(mclks, pclks):
    m = _macro_ns(pclks)
    return ((mclks * m) + 500) // 1000


def _us_to_mclks(us, pclks):
    m = _macro_ns(pclks)
    return ((us * 1000) + (m // 2)) // m


def _dec_timeout(v):
    return ((v & 0xFF) << ((v & 0xFF00) >> 8)) + 1


def _enc_timeout(mclks):
    if mclks <= 0:
        return 0
    ls = mclks - 1
    ms = 0
    while ls & 0xFFFFFF00:
        ls >>= 1
        ms += 1
    return (ms << 8) | (ls & 0xFF)


def _steps(t):
    sc = t._register(0x01)                           # SYSTEM_SEQUENCE_CONFIG
    en = {"tcc": (sc >> 4) & 1, "dss": (sc >> 3) & 1, "msrc": (sc >> 2) & 1,
          "pre": (sc >> 6) & 1, "final": (sc >> 7) & 1}
    pre_p = _vcsel(t, 0x50)
    msrc_us = _mclks_to_us(t._register(0x46) + 1, pre_p)
    pre_mclks = _dec_timeout(t._register(0x51, struct='>H'))
    pre_us = _mclks_to_us(pre_mclks, pre_p)
    fin_p = _vcsel(t, 0x70)
    fin_mclks = _dec_timeout(t._register(0x71, struct='>H'))
    if en["pre"]:
        fin_mclks -= pre_mclks
    fin_us = _mclks_to_us(fin_mclks, fin_p)
    return en, msrc_us, pre_mclks, pre_us, fin_p, fin_us


def _overhead(en, msrc_us, pre_us, start):
    used = start + 960
    if en["tcc"]:
        used += msrc_us + 590
    if en["dss"]:
        used += 2 * (msrc_us + 690)
    elif en["msrc"]:
        used += msrc_us + 660
    if en["pre"]:
        used += pre_us + 660
    return used


def get_budget(t):
    """センサーに今設定されている1回の測定時間（µs）"""
    en, msrc_us, _, pre_us, _, fin_us = _steps(t)
    used = _overhead(en, msrc_us, pre_us, 1910)
    if en["final"]:
        used += fin_us + 550
    return used


def set_budget(t, budget_us):
    """1回の測定時間を設定。できなければ False（そのときはセンサーの初期値のまま）"""
    if budget_us < 20000:
        return False
    en, msrc_us, pre_mclks, pre_us, fin_p, _ = _steps(t)
    if not en["final"]:
        return False
    used = _overhead(en, msrc_us, pre_us, 1910) + 550
    if used > budget_us:
        return False
    mclks = _us_to_mclks(budget_us - used, fin_p)
    if en["pre"]:
        mclks += pre_mclks
    t._register(0x71, _enc_timeout(mclks), struct='>H')   # FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI（2バイト）
    return True


def set_vcsel(t, final, pclks):
    """2.18: VCSEL 周期を変える（Pololu VL53L0X.cpp の setVcselPulsePeriod と同じ手順。部品ファイルの同名関数は誤りがあるので使わない）"""
    en, msrc_us, pre_mclks, pre_us, fin_p, fin_us = _steps(t)
    reg = (pclks >> 1) - 1
    if not final:                                   # 事前測定（pre-range）
        t._register(0x57, {12: 0x18, 14: 0x30, 16: 0x40, 18: 0x50}[pclks])   # PRE_RANGE_CONFIG_VALID_PHASE_HIGH
        t._register(0x56, 0x08)                                              # PRE_RANGE_CONFIG_VALID_PHASE_LOW
        t._register(0x50, reg)                                               # PRE_RANGE_CONFIG_VCSEL_PERIOD
        t._register(0x51, _enc_timeout(_us_to_mclks(pre_us, pclks)), struct='>H')
        m = _us_to_mclks(msrc_us, pclks)
        t._register(0x46, 255 if m > 256 else m - 1)                         # MSRC_CONFIG_TIMEOUT_MACROP
    else:                                           # 本測定（final range）
        ph, w, to, lim = {8: (0x10, 0x02, 0x0C, 0x30), 10: (0x28, 0x03, 0x09, 0x20),
                          12: (0x38, 0x03, 0x08, 0x20), 14: (0x48, 0x03, 0x07, 0x20)}[pclks]
        t._register(0x48, ph)                       # FINAL_RANGE_CONFIG_VALID_PHASE_HIGH
        t._register(0x47, 0x08)                     # FINAL_RANGE_CONFIG_VALID_PHASE_LOW
        t._register(0x32, w)                        # GLOBAL_CONFIG_VCSEL_WIDTH
        t._register(0x30, to)                       # ALGO_PHASECAL_CONFIG_TIMEOUT
        t._register(0xFF, 0x01)
        t._register(0x30, lim)                      # ALGO_PHASECAL_LIM（ページ1）
        t._register(0xFF, 0x00)
        t._register(0x70, reg)                      # FINAL_RANGE_CONFIG_VCSEL_PERIOD
        m = _us_to_mclks(fin_us, pclks)
        if en["pre"]:
            m += pre_mclks
        t._register(0x71, _enc_timeout(m), struct='>H')


def long_range(t):
    """2.18: 遠距離モード（事前 18・本 14 PCLK）。そのあと測定時間を入れ直し、位相の校正をやり直す"""
    set_vcsel(t, False, 18)
    set_vcsel(t, True, 14)
    set_budget(t, TIMING_BUDGET_US)
    sc = t._register(0x01)
    t._register(0x01, 0x02)
    try:
        t._calibrate(0x00)                          # performSingleRefCalibration(0)
    finally:
        t._register(0x01, sc)


TOF_BUS = ((1, 6, 7), (0, 4, 5))   # A=I2C1 GP6/GP7、B=I2C0 GP4/GP5
budget_now = [0, 0]                # センサーに実際に入っている測定時間 µs（状態ページに表示）
lr_on = [False, False]             # 2.18: 遠距離モードになっているか（物理の番号）


def tof_open(i):
    """センサー1台を1回だけ初期化する（失敗したら OSError など）"""
    bus, sda, scl = TOF_BUS[i]
    i2c_unstick(sda, scl)
    i2c = I2C(bus, sda=Pin(sda), scl=Pin(scl), freq=100000)   # プルアップ無しのため 100kHz
    found = i2c.scan()
    if 0x29 not in found:
        raise OSError("見つからない scan=%s" % found)
    t = VL53L0X(i2c)
    t._register(0x44, int(SIGNAL_LIMIT_MCPS * 128), struct='>H')   # 弱い反射の下限（長距離向け）
    logical = (1 - i) if SWAP_AB else i              # 0=ドア側A
    lr_on[i] = False
    if LONG_RANGE == 2 or (LONG_RANGE == 1 and logical == 0):
        try:
            long_range(t)
            lr_on[i] = True
        except Exception as e:
            print("遠距離モードの設定に失敗（ふつうのモードで続ける）:", e)
    try:
        set_budget(t, TIMING_BUDGET_US)
        budget_now[i] = get_budget(t)
    except Exception as e:
        print("測定時間の設定に失敗（初期値のまま）:", e)
    t.start()
    return t


def init_tof(i, name, wiring):
    # センサーが応答するまで何度でも試す（止まらずに原因を表示）
    n = 0
    while True:
        n += 1
        try:
            t = tof_open(i)
            print("センサー%s: OK（測定時間 %.1fms）" % (name, budget_now[i] / 1000))
            return t
        except Exception as e:
            print("センサー%s が応答しません（%d回目）: %s" % (name, n, e))
            if n == 1:
                print("  → 配線を確認: %s" % wiring)
                print("  → 直らなければ USB を抜いて5秒待ち、挿し直す（センサーの電源を入れ直す）")
            for _ in range(10):
                led.toggle(); time.sleep_ms(100)
            led.off()


cfg_load()
tofA = init_tof(0, "A(ドア側)", "SDA=9番(GP6) SCL=10番(GP7) GND=33番か38番 +V=36番")
tofB = init_tof(1, "B(店内側)", "SDA=6番(GP4) SCL=7番(GP5) GND=33番か38番 +V=36番")
tofs = [tofA, tofB]


# ---------------------------------------------------------------- 見張り（固まったら自動で再起動）
import os, machine
from machine import Timer
WD_TIMEOUT_MS = 30000      # これだけ動きが止まったら再起動
_wd_last = time.ticks_ms()
_wd_timer = None


def wd_feed():
    global _wd_last
    _wd_last = time.ticks_ms()


def _wd_check(t):
    if time.ticks_diff(time.ticks_ms(), _wd_last) > WD_TIMEOUT_MS:
        try:
            with open("wd_reset.txt", "a") as f:
                f.write("%d\n" % time.time())
        except Exception:
            pass
        machine.reset()


def wd_start():
    global _wd_timer
    wd_feed()
    _wd_timer = Timer(-1)
    _wd_timer.init(period=2000, mode=Timer.PERIODIC, callback=_wd_check)


def wd_stop():
    if _wd_timer is not None:
        _wd_timer.deinit()


# ---------------------------------------------------------------- プログラム更新（ブラウザから）
def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def ota_receive(cl, buf):
    """POST /upload の本文（.mpy）を app_new.mpy に保存。(成功?, メッセージ) を返す。
    大きなメモリを一度に使わないよう、少しずつ受け取りながら中身を確かめる"""
    import gc
    gc.collect()
    while b"\r\n\r\n" not in buf:
        if len(buf) > 4096:
            return False, "見出しが長すぎます"
        wd_feed()
        more = cl.recv(512)
        if not more:
            return False, "受信が途中で切れました（見出し）"
        buf += more
    head, body = buf.split(b"\r\n\r\n", 1)
    n = 0
    for line in head.split(b"\r\n"):
        if line.lower().startswith(b"content-length:"):
            n = int(line.split(b":")[1])
    if n <= 0 or n > 120000:
        return False, "ファイルの大きさが正しくありません（%d）" % n
    idb = APP_ID.encode()
    found_id = False
    tag = b""
    tail = b""
    got = 0
    first = b""
    with open("app_new.mpy", "wb") as f:
        chunk = body
        while True:
            if chunk:
                f.write(chunk)
                got += len(chunk)
                if len(first) < 4:
                    first = (first + chunk)[:4]
                win = tail + chunk                 # 区切れ目をまたいでも見つかるように前の末尾をつなぐ
                if not found_id and idb in win:
                    found_id = True
                if not tag:
                    i = win.find(b"@@VER:")
                    j = win.find(b"@@", i + 6) if i >= 0 else -1
                    if j > 0:
                        tag = win[i + 6:j]
                tail = win[-80:]
            if got >= n:
                break
            wd_feed()
            chunk = cl.recv(min(1024, n - got))
            if not chunk:
                break
    gc.collect()
    if got != n:
        os.remove("app_new.mpy")
        return False, "途中で切れました（%d / %d バイト）。もう一度送ってください" % (got, n)
    if first[:1] != b"M":
        os.remove("app_new.mpy")
        return False, "形式が違います（.mpy のファイルを選んでください）"
    if not found_id:
        os.remove("app_new.mpy")
        return False, "%s用のプログラムではありません。ファイルを確かめてください" % APP_NAME
    v = tag.decode().split("|") if tag else ["不明", "不明"]
    return True, "受け取りました：版 %s（%s 作成）。「更新を適用」を押すと切り替わります" % (v[0], v[1] if len(v) > 1 else "不明")


def _tag_of(data):
    i = data.find(b"@@VER:")
    j = data.find(b"@@", i + 6) if i >= 0 else -1
    if i < 0 or j < 0:
        return ("不明", "不明")
    v = data[i + 6:j].decode().split("|")
    return (v[0], v[1] if len(v) > 1 else "不明")


def _tag_file(fn):
    """ファイルを少しずつ読んで版の印を探す"""
    tail = b""
    with open(fn, "rb") as f:
        while True:
            c = f.read(1024)
            if not c:
                break
            w = tail + c
            if b"@@VER:" in w and w.find(b"@@", w.find(b"@@VER:") + 6) > 0:
                return _tag_of(w)
            tail = w[-80:]
    return ("不明", "不明")


def now_str():
    t = time.localtime(time.time() + 9 * 3600)
    if t[0] < 2024:
        return "時刻不明"
    return "%d/%d %02d:%02d" % (t[1], t[2], t[3], t[4])


def ota_info():
    """更新欄に出す文：今の版・作成日時・最後に更新した日時・未適用のファイル"""
    s = "今の版 <b>%s</b>（%s 作成）" % (VERSION, BUILD)
    try:
        with open("app_updated.txt") as f:
            s += "<br>最後に更新：" + f.read().strip()
    except OSError:
        s += "<br>最後に更新：記録なし（Thonny で入れた版）"
    if _exists("crash.txt") and _exists("app_bad.mpy"):
        s += "<br><span style='color:var(--hot)'>前回の更新は起動に失敗したため、自動で元の版に戻しました</span>"
    if _exists("app_new.mpy"):
        try:
            v = _tag_file("app_new.mpy")
            s += "<br><span style='color:var(--hot)'>受け取り済み・未適用：版 %s（%s 作成）</span>" % v
        except Exception:
            pass
    return s


def ota_apply():
    # 途中で電源が切れても困らない順番：①「正常」の印を先に消す ②入れ替え。
    # app.mpy が無い状態で止まっても、main.py が app_new.mpy / app_prev.mpy から立て直す
    if not _exists("app_new.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    try:
        v = _tag_file("app_new.mpy")
        with open("app_updated.txt", "w") as f:
            f.write("%s　版 %s → %s" % (now_str(), VERSION, v[0]))
    except Exception:
        pass
    if _exists("crash.txt"):
        os.remove("crash.txt")
    if _exists("app_prev.mpy"):
        os.remove("app_prev.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_prev.mpy")
    os.rename("app_new.mpy", "app.mpy")
    return True


def ota_rollback():
    if not _exists("app_prev.mpy"):
        return False
    if _exists("app_ok.flag"):
        os.remove("app_ok.flag")
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    try:
        with open("app_updated.txt", "w") as f:
            f.write("%s　前の版に戻した" % now_str())
    except Exception:
        pass
    return True


_ok_marked = False


def ota_mark_ok(uptime_s):
    """起動して60秒動けたら「この版は正常」と記録（main.py の自動戻しの判断に使う）"""
    global _ok_marked
    if _ok_marked or uptime_s < 60:
        return
    _ok_marked = True
    try:
        if not _exists("app_ok.flag"):
            with open("app_ok.flag", "w") as f:
                f.write(VERSION)
    except Exception:
        pass
    launcher_update()


# @@LAUNCHER-BEGIN（sync_launcher.py が main.py の中身をここへ写す。手で直さない）
LAUNCHER = """# -*- coding: utf-8 -*-
# 入店チャイム 起動役（センサー箱・チャイム箱 共通）。Pico に main.py として保存する。
# 本体のプログラムは app.mpy。更新後の app.mpy が起動に失敗したら、自動で前の版（app_prev.mpy）に戻す。
# 起動役 版 2（2026-10-23）：更新の途中で電源が切れたときの立て直し、更新直後の部品不足でも前の版に戻す
# 必ず UTF-8（BOMなし）で保存すること。
import os, sys, time, machine


def _exists(fn):
    try:
        os.stat(fn)
        return True
    except OSError:
        return False


def _crash(e):
    try:
        with open("crash.txt", "w") as f:
            sys.print_exception(e, f)
    except Exception:
        pass


def _rollback():
    # 更新したばかり（まだ「正常」の印が無い）で、前の版が残っていれば戻す
    if _exists("app_ok.flag") or not _exists("app_prev.mpy"):
        return False
    if _exists("app_bad.mpy"):
        os.remove("app_bad.mpy")
    if _exists("app.mpy"):
        os.rename("app.mpy", "app_bad.mpy")
    os.rename("app_prev.mpy", "app.mpy")
    return True


# 更新の途中で電源が切れて app.mpy が無いときの立て直し
if not (_exists("app.mpy") or _exists("app.py")):
    if _exists("app_new.mpy"):
        os.rename("app_new.mpy", "app.mpy")
        print("更新の途中だったので、新しい版の適用を済ませました")
    elif _exists("app_prev.mpy"):
        os.rename("app_prev.mpy", "app.mpy")
        print("app.mpy が無かったので、前の版を使います")

try:
    if not (_exists("app.mpy") or _exists("app.py")):
        print("app.mpy がありません。Thonny の「表示」→「ファイル」で app.mpy を Pico に入れてください")
        print("（名前が sensor_app.mpy / chime_app.mpy のままなら、右クリック →「リネーム」で app.mpy に）")
        raise SystemExit
    import app
except (KeyboardInterrupt, SystemExit):
    raise
except ImportError as e:
    if _rollback():
        _crash(e)
        print("新しい版に必要なファイルが無いため（%s）、前の版に戻して再起動します" % e)
        time.sleep(5)
        machine.reset()
    # 部品ファイルが足りないときは、再起動を繰り返さずに止める（Thonny で直せるように）
    print("必要なファイルが Pico にありません:", e)
    print("センサー箱なら vl53l0x.py、両方とも wifi_secret.py が入っているか確認してください")
    raise SystemExit
except Exception as e:
    sys.print_exception(e)
    _crash(e)
    if _rollback():
        print("新しい版で起動できなかったため、前の版に戻して再起動します")
    else:
        print("エラーで止まったため、5秒後に再起動します")
    time.sleep(5)
    machine.reset()
"""
# @@LAUNCHER-END


def launcher_update():
    """起動役 main.py を、この版に入っている最新のものに入れ替える（Thonny 無しで main.py も更新するため）。
    この版が60秒正常に動いたあとにだけ呼ぶ。一時ファイルに書いてから名前を変えるので、途中で電源が切れても壊れない"""
    try:
        try:
            with open("main.py") as f:
                if f.read() == LAUNCHER:
                    return
        except OSError:
            pass
        with open("main.tmp", "w") as f:
            f.write(LAUNCHER)
        try:
            os.rename("main.tmp", "main.py")
        except OSError:
            os.remove("main.py")
            os.rename("main.tmp", "main.py")
        log_event("更新", "起動役 main.py を新しくしました")
    except Exception as e:
        print("main.py の更新に失敗:", e)


OTA_HTML = """<div class="c"><details><summary><b>プログラム更新</b>　<small>版 %s</small></summary>
<small>%s</small><br>
<small>新しい %s 用のファイル（.mpy）を選んで「送る」→「更新を適用」。起動に失敗したら自動で前の版に戻ります。</small><br>
<input type="file" id="up" accept=".mpy" style="margin-top:8px;max-width:100%%"><br>
<button onclick="upl()">送る</button><button onclick="if(confirm('新しい版に切り替えて再起動しますか？'))apl('/apply')">更新を適用</button>
<button onclick="if(confirm('ひとつ前の版に戻して再起動しますか？'))apl('/rollback')">前の版に戻す</button>
<br><small id="um"></small></details></div>
<script>
function upl(){var f=document.getElementById('up').files[0],m=document.getElementById('um');if(!f){m.textContent='ファイルを選んでください';return}
window.PAUSE=1;var x=new XMLHttpRequest();x.open('POST','/upload');x.timeout=60000;
x.upload.onprogress=function(e){if(e.lengthComputable)m.textContent='送信中… '+Math.round(e.loaded/e.total*100)+'%%'};
x.onload=function(){window.PAUSE=0;try{m.textContent=JSON.parse(x.responseText).msg}catch(e){m.textContent='返事が読めません: '+x.status}};
x.onerror=function(){window.PAUSE=0;m.textContent='送信に失敗しました（Wi-Fi が切れたか、箱が応答しません）。ページを再読み込みしてもう一度'};
x.ontimeout=function(){window.PAUSE=0;m.textContent='時間切れです。もう一度送ってください'};
m.textContent='送信中…';x.send(f)}
function apl(p){var m=document.getElementById('um');fetch(p,{method:'POST'}).then(function(r){return r.json()}).then(function(r){m.textContent=r.msg;if(r.ok)setTimeout(function(){location.reload()},25000)})}
</script>"""


# ---------------------------------------------------------------- 時刻・ログ
def jst():
    return time.localtime(time.time() + TZ_OFFSET)


def hhmmss():
    t = jst()
    return "%02d:%02d:%02d" % (t[3], t[4], t[5])


events = []   # [時刻, 種別, メモ] 新しい順


def log_event(kind, note=""):
    events.insert(0, [hhmmss(), kind, note])
    if len(events) > EVENT_KEEP:
        events.pop()
    print(kind, note)


# ---------------------------------------------------------------- UDP（チャイム送信）
udp_sock = None
seq = 0


def udp_setup():
    global udp_sock
    if not HAS_NET:
        return
    if udp_sock is not None:
        try:
            udp_sock.close()        # 再接続のたびに古いソケットを閉じる（使い捨てると枠が尽きる）
        except Exception:
            pass
        udp_sock = None
    try:
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, 0x20, 1)  # SO_BROADCAST
    except Exception as e:
        print("UDP初期化失敗:", e)
        udp_sock = None


def send_cmd(text):
    if udp_sock is None:
        return
    for _ in range(UDP_REPEAT):
        try:
            udp_sock.sendto(text.encode(), (UDP_TARGET, UDP_PORT))
        except Exception as e:
            print("UDP送信失敗:", e)
        time.sleep_ms(20)


def send_chime(kind):
    """受信機へ "CHIME IN <seq>" を送る。seq は受信側の重複排除用"""
    global seq
    if udp_sock is None:
        return
    seq += 1
    msg = ("CHIME %s %d" % (kind, seq)).encode()
    targets = [UDP_TARGET]
    try:
        if chime_t is not None and mono() - chime_t < 60:
            targets.insert(0, chime_info["ip"])   # チャイム箱へ直接（一斉送信より遅れが少ない）
    except Exception:
        pass
    for i in range(UDP_REPEAT):
        for ip in targets:
            try:
                udp_sock.sendto(msg, (ip, UDP_PORT))
            except Exception as e:
                print("UDP送信失敗:", e)
        if i < UDP_REPEAT - 1:
            time.sleep_ms(5)


led_off_t = None


def chime():
    global led_off_t
    led.on()
    send_chime("IN")
    if not LOCAL_BUZZER:
        led_off_t = time.ticks_add(time.ticks_ms(), 100)
        return
    if PASSIVE_BUZZER:
        buzzer.freq(CHIME_HZ); buzzer.duty_u16(32768)
        time.sleep_ms(CHIME_MS); buzzer.duty_u16(0)
    else:
        buzzer.on(); time.sleep_ms(CHIME_MS); buzzer.off()
    led.off()


def in_quiet_hours():
    if clock_ok():                       # 時刻が合っているときだけ営業時間で判断（不明なら鳴らす）
        t = jst()
        wd = t[6]                        # 0=月 … 5=土 6=日
        o, c = (OPEN_SUN, CLOSE_SUN) if wd == 6 else (OPEN_SAT, CLOSE_SAT) if wd == 5 else (OPEN_WD, CLOSE_WD)
        now_m = t[3] * 60 + t[4]
        if not (o[0] * 60 + o[1] <= now_m < c[0] * 60 + c[1]):
            return True
    if not QUIET_HOURS:
        return False
    h = jst()[3]
    for s, e in QUIET_HOURS:
        if (s <= e and s <= h < e) or (s > e and (h >= s or h < e)):
            return True
    return False


# ---------------------------------------------------------------- Wi-Fi
def wlan():
    return network.WLAN(network.STA_IF) if HAS_NET else None


def wifi_connect():
    if not HAS_NET or not WIFI_SSID:
        return False
    try:
        network.hostname(HOSTNAME)
    except Exception:
        pass
    try:
        import rp2
        rp2.country("JP")
    except Exception:
        pass
    w = wlan(); w.active(True)
    try:
        w.config(pm=0xa11140)    # 省電力オフ（接続が安定する）
    except Exception:
        pass
    if not w.isconnected():
        w.connect(WIFI_SSID, WIFI_PASS)
        for _ in range(30):
            if w.isconnected():
                break
            led.toggle()
            wd_feed()
            time.sleep(0.5)
        led.off()
    if w.isconnected():
        print("WiFi:", w.ifconfig()[0], " → iPhone で http://%s/ を開く" % w.ifconfig()[0])
        try:
            ntptime.settime()
        except Exception as e:
            print("NTP失敗:", e)
        return True
    print("WiFi接続失敗")
    return False


def wifi_ok():
    try:
        return HAS_NET and wlan().isconnected()
    except Exception:
        return False


def post_event(kind):
    if not EVENT_URL or not HAS_NET:
        return
    try:
        t = jst()
        ts = "%04d-%02d-%02d %02d:%02d:%02d" % t[:6]
        r = urequests.post(EVENT_URL, json={"event": kind, "time_jst": ts,
                                            "in": in_count, "out": out_count})
        r.close()
    except Exception as e:
        print("送信失敗:", e)


# ---------------------------------------------------------------- 測距
tof_err = [0, 0]        # 通信エラーが続いた回数（範囲外＝壁が遠い、とは区別する）
tof_fix_t = [-10, -10]  # 最後に立て直しを試みた時刻（mono 秒）
TOF_ERR_MAX = 20        # これだけ続けて通信エラーならセンサーを初期化し直す


def read_mm(i):
    """i=0 がドア側 A、1 が店内側 B（論理番号）。SWAP_AB=1 なら物理のセンサーを入れ替えて読む"""
    if SWAP_AB:
        i = 1 - i
    try:
        d = tofs[i].read()
        tof_err[i] = 0
        return d if MIN_VALID_MM <= d <= MAX_VALID_MM else None
    except Exception:
        tof_err[i] += 1
        return None


def tof_recover():
    """通信エラーが続くセンサーを、止めずに初期化し直す（10秒に1回まで）"""
    for i in (0, 1):
        if tof_err[i] < TOF_ERR_MAX or mono() - tof_fix_t[i] < 10:
            continue
        tof_fix_t[i] = mono()
        name = "AB"[i]
        try:
            tofs[i] = tof_open(i)
            tof_err[i] = 0
            log_event("センサー", "%s を初期化し直しました（通信エラーが続いたため）" % name)
        except Exception as e:
            log_event("センサー", "%s が応答しません: %s（配線・差し込みを確認）" % (name, e))
        wd_feed()


def median(xs):
    xs = sorted(xs); n = len(xs)
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) // 2


def calibrate(prev=None, accept=False):
    """基準距離を取る。prev=(今の基準A, 今の基準B)。
    壁の設定（NO_TARGET_MM）より大きく手前の値が出たら「前に人や物がいる」とみなし、基準を変えない（2.5）。
    accept=True（2分以上ずっと遮られている＝置き物）のときは、その距離をそのまま基準にする"""
    a, b = [], []
    for i in range(CALIB_SAMPLES):
        da, db = read_mm(0), read_mm(1)
        if da: a.append(da)
        if db: b.append(db)
        led.value(i % 2)            # 速い点滅＝基準取得中
        wd_feed()                   # センサー不調で1回1秒以上かかっても見張りに止められないように
        time.sleep_ms(SAMPLE_MS)
    led.off()
    return base_from(a, b, CALIB_SAMPLES, prev, accept)


def base_from(a, b, n, prev=None, accept=False):
    """2.16: 測定値の並び（有効な値だけ）から基準を決める。n はサンプル数（測れなかった回も含む）"""
    ba = median(a) if len(a) >= n // 3 else NO_TARGET_MM
    bb = median(b) if len(b) >= n // 3 else NO_TARGET_MM
    limit = 0 if accept else NO_TARGET_MM - 2 * DROP_MM   # これより近い基準は「前に人がいた」とみなす
    blocked = ""
    if ba < limit:
        blocked += "A%d" % ba
        ba = prev[0] if prev and prev[0] >= limit else NO_TARGET_MM
    if bb < limit:
        blocked += " B%d" % bb
        bb = prev[1] if prev and prev[1] >= limit else NO_TARGET_MM
    note = "A=%dmm B=%dmm" % (ba, bb)
    who = ("A" if len(a) < n // 3 else "") + ("B" if len(b) < n // 3 else "")
    if who:
        note += "（%s は向かいが測れず仮の値。2m以内に壁や物を置く）" % who
    if blocked:
        note += "（前に人か物があった：%smm → 基準は変えず1分後に取り直し）" % blocked.strip()
    if accept:
        note += "（2分以上ずっと遮られているので、置き物とみなしてこの距離を基準にしました）"
    log_event("基準", note)
    return ba, bb, bool(blocked)


# ---------------------------------------------------------------- 状態ページ
PAGE = """<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>入店センサー</title><style>
:root{--bg:#f4f3ef;--fg:#222;--mut:#8a8884;--card:#fff;--acc:#1d9e75;--hot:#d85a30;--trk:#e6e4de}
@media(prefers-color-scheme:dark){:root{--bg:#1a1a19;--fg:#eee;--mut:#9a9890;--card:#262624;--trk:#3a3a38}}
body{margin:0;padding:16px;font-family:-apple-system,system-ui,sans-serif;background:var(--bg);color:var(--fg)}
.c{background:var(--card);border-radius:14px;padding:14px;margin-bottom:12px}
.n{display:flex}.n div{flex:1;text-align:center}.n b{display:block;font-size:44px;font-weight:600}
.lb{display:flex;justify-content:space-between;font-size:15px;margin-top:8px}
.bar{height:22px;background:var(--trk);border-radius:6px;position:relative;margin:6px 0}
.f{height:100%;border-radius:6px;background:var(--acc);transition:width .2s}.f.on{background:var(--hot)}
.th{position:absolute;top:-4px;bottom:-4px;width:2px;background:var(--fg)}
small{color:var(--mut);font-size:13px}ul{list-style:none;padding:0;margin:6px 0 0}
li{display:flex;gap:10px;padding:5px 0;border-top:1px solid var(--trk);font-size:14px}
li span:first-child{color:var(--mut);width:64px}.IN{color:var(--acc);font-weight:600}
button{font-size:15px;padding:10px 12px;border-radius:10px;border:1px solid var(--trk);background:var(--card);color:var(--fg);margin:8px 6px 0 0}
#dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--acc);margin-right:6px}
</style></head><body>
<div class="c n"><div><small>今日の入店</small><b id="in">-</b></div><div><small>退店</small><b id="out">-</b></div></div>
<div class="c"><b>センサー</b>
<div class="lb"><span>A 外側</span><span id="ta"></span></div><div class="bar"><div class="f" id="fa"></div><div class="th" id="ha"></div></div>
<div class="lb"><span>B 内側</span><span id="tb"></span></div><div class="bar"><div class="f" id="fb"></div><div class="th" id="hb"></div></div>
<small>棒が短い＝近くに人。縦線より短くなると「検知」</small><br><small id="tm"></small></div>
<div class="c"><b>チャイム箱</b>　<small id="chs">確認中…</small></div>
<div class="c"><b>最近の判定</b><ul id="ev"></ul></div>
<div class="c"><small><span id="dot"></span><span id="st">接続中…</span></small><br>
<button onclick="go('/test')">チャイム試験</button><button onclick="go('/recal')">基準を取り直す</button>
<button onclick="if(confirm('今日の件数を0に戻しますか？'))go('/reset')">件数リセット</button><br><small id="gm"></small></div>
<div class="c"><details id="adj" ontoggle="if(this.open)lc()"><summary><b>調整</b>　<small>変えたら「保存」。すぐ反映・電源を切っても残ります</small></summary>
<small>鳴らす時間（固定）：平日 8:45〜19:00・土曜 8:45〜15:00・日曜 休み。この外は数えるだけで鳴らしません</small>
<div id="cf"></div>
<button onclick="save()">保存</button><button onclick="if(confirm('センサー箱を再起動しますか？'))P('/reboot')">再起動</button>
<br><small id="cmsg">「感度」は数字を小さくすると敏感に（例 250→150）。「再起動で反映」の項目は保存後に再起動。</small>
<br><small><b>設定を変えた記録</b></small><ul id="slog" style="font-size:12px;margin:4px 0 0 0;padding-left:16px"></ul></details></div>
<script>
function $(i){return document.getElementById(i)}
function E(s){return String(s).replace(/[&<>"']/g,function(c){return '&#'+c.charCodeAt(0)+';'})}
function P(p){return fetch(p,{method:'POST'})}
function go(p){P(p).then(function(r){return r.json()}).then(function(r){$('gm').textContent=r.msg||''}).catch(function(){}).then(u)}
function bar(k,d,b,dr,o){var m=Math.max(b,1);$('f'+k).style.width=Math.min(100,(d||m)/m*100)+'%';
$('f'+k).className='f'+(o?' on':'');$('h'+k).style.left=Math.max(0,(b-dr)/m*100)+'%';
$('t'+k).textContent=(d?d+' mm':'-- mm')+'（基準 '+b+'）'+(o?' ●検知':'')}
function hm(s){var h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+'時間':'')+m+'分'}
function u(){if(window.PAUSE)return;fetch('/s',{cache:'no-store'}).then(function(r){return r.json()}).then(function(s){
$('in').textContent=s.in;$('out').textContent=s.out;
bar('a',s.a,s.ba,s.da||s.drop,s.oa);bar('b',s.b,s.bb,s.db||s.drop,s.ob);
$('ev').innerHTML=s.ev.map(function(e){return '<li><span>'+E(e[0])+'</span><span class="'+(e[1]=='IN'?'IN':'')+'">'+E(e[1])+'</span><span>'+E(e[2])+'</span></li>'}).join('')||'<li><span>まだありません</span></li>';
$('tm').textContent='1回の測定時間 A '+(s.tb[0]/1000).toFixed(1)+'ms・B '+(s.tb[1]/1000).toFixed(1)+'ms';
var c=s.ch;$('chs').innerHTML=!c?'まだ応答がありません（チャイム箱の電源・Wi-Fi を確認）':(c.age>40?'<span style="color:var(--hot)">● 応答なし（'+c.age+'秒前が最後）</span>':'<span style="color:var(--acc)">● 接続中</span>')+(c?'　音量 '+E(c.vol)+'・音 '+E(c.trk)+'・SD '+(c.sd?'OK（'+E(c.n)+'曲）':'<span style="color:var(--hot)">読めない</span>')+(c.cnt?'<br>起動から 受けた '+c.cnt[0]+'・鳴らした '+c.cnt[1]+'・失敗 '+c.cnt[2]+'・間隔で省略 '+c.cnt[3]:'')+'<br><a href="http://'+E(c.ip)+'/" style="color:var(--mut)">チャイム箱のページ（'+E(c.ip)+'・版 '+E(c.ver)+'）</a>':'');
$('dot').style.background='var(--acc)';
$('st').innerHTML=s.ip+'　Wi-Fi '+(s.rssi===null?'--':s.rssi+'dBm')+'　稼働 '+hm(s.up)+'<br>昨日 入'+s.yin+' / 出'+s.yout+(s.quiet?'　営業時間外（鳴らさない）':'');
}).catch(function(){$('dot').style.background='var(--hot)';$('st').textContent='センサー箱に接続できません'})}
function lc(){fetch('/cfg',{cache:'no-store'}).then(function(r){return r.json()}).then(function(c){
var g0='';$('cf').innerHTML=c.map(function(x){var h='';if(x[3]&&x[3]!==g0){g0=x[3];h='<div style="margin:10px 0 2px;font-weight:bold;font-size:13px">'+E(x[3])+'</div>'}return h+'<div class="lb" style="align-items:center"><span>'+E(x[2])+'</span><input id="k_'+E(x[0])+'" value="'+E(x[1])+'" data-o="'+E(x[1])+'" inputmode="decimal" style="width:90px;font-size:16px;padding:6px;border-radius:8px;border:1px solid var(--trk);background:var(--bg);color:var(--fg);text-align:right"></div>'}).join('')});
fetch('/setlog',{cache:'no-store'}).then(function(r){return r.json()}).then(function(l){$('slog').innerHTML=l.map(function(x){return '<li>'+E(x)+'</li>'}).join('')||'<li>まだありません</li>'})}
function save(){var q=[];document.querySelectorAll('#cf input').forEach(function(i){if(i.value!==i.getAttribute('data-o'))q.push(i.id.slice(2)+'='+encodeURIComponent(i.value))});
if(!q.length){$('cmsg').textContent='変更はありません';return}
P('/set?'+q.join('&')).then(function(r){return r.json()}).then(function(r){$('cmsg').textContent=r.changed.length?'保存しました：'+r.changed.join('・')+(r.reboot?'（再起動すると反映）':''):'変更はありません';lc();u()})}
setInterval(u,500);u();lc();
</script><!--OTA--></body></html>"""
# 2.14: 起動直後（メモリがきれいなうち）に bytes に変えておく。表示のたびに大きな文字列を作らない
PAGE_A, PAGE_B = (x.encode() for x in PAGE.split("<!--OTA-->"))
del PAGE

HB_PORT = 5006               # チャイム箱からの「生きてるよ」を受ける
hb_sock = None
chime_t = None              # 最後に応答があった時刻
chime_info = {}
chime_down = False


def hb_setup():
    global hb_sock
    if not HAS_NET:
        return
    try:
        hb_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        hb_sock.bind(("0.0.0.0", HB_PORT))
        hb_sock.setblocking(False)
    except Exception as e:
        print("生存確認の受信準備に失敗:", e)


def hb_poll():
    """ALIVE CHIME <sd> <vol> <trk> <曲数> <版>"""
    global chime_t, chime_info, chime_down
    if hb_sock is None:
        return
    try:
        data, addr = hb_sock.recvfrom(128)
    except OSError:
        data = None
    if data:
        try:
            p = data.decode().split()
            if len(p) >= 7 and p[0] == "ALIVE" and p[1] == "CHIME":
                chime_info = {"ip": addr[0], "sd": p[2] == "1", "vol": int(p[3]), "trk": int(p[4]),
                              "n": int(p[5]), "ver": p[6]}
                if len(p) >= 11:        # チャイム箱 2.4 以降：受けた・鳴らした・失敗・間隔で省略 の回数
                    chime_info["cnt"] = [int(x) for x in p[7:11]]
                if chime_down or chime_t is None:
                    log_event("チャイム箱", ("復帰" if chime_down else "接続") + " %s" % addr[0])
                chime_down = False
                chime_t = mono()
                if not chime_info["sd"]:
                    pass
                # 音量・音がスマホの設定と違えば合わせる（チャイム箱を入れ替えたときなど）
                if chime_info["vol"] != CHIME_VOL:
                    send_cmd("CHIME VOL %d" % CHIME_VOL)
                if chime_info["trk"] != CHIME_TRK:
                    send_cmd("CHIME TRK %d" % CHIME_TRK)
        except Exception:
            pass
    if chime_t is not None and not chime_down and mono() - chime_t > 40:
        chime_down = True
        log_event("チャイム箱", "応答なし（電源・Wi-Fi を確認）")


web_sock = None
recal_req = False
reboot_req = False


def web_setup():
    global web_sock
    if not HAS_NET:
        return
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", WEB_PORT))
        s.listen(2)
        s.setblocking(False)
        web_sock = s
    except Exception as e:
        print("状態ページ起動失敗:", e)


def thr(base, rng):
    """この距離より近ければ「人がいる」。基準−感度 と 反応する一番奥 の近い方"""
    t = base - DROP_MM
    return t if not rng or rng >= t else rng


def _mem_free():
    try:
        import gc
        return gc.mem_free()
    except Exception:
        return -1


def status_json():
    rssi = None
    ip = "-"
    try:
        w = wlan()
        if w.isconnected():
            ip = w.ifconfig()[0]
            rssi = w.status("rssi")
    except Exception:
        pass
    return json.dumps({
        "a": dA or 0, "b": dB or 0, "ba": baseA, "bb": baseB, "drop": DROP_MM,
        "da": baseA - thr(baseA, RANGE_A_MM), "db": baseB - thr(baseB, RANGE_B_MM),
        "oa": occA, "ob": occB, "in": in_count, "out": out_count,
        "yin": y_in, "yout": y_out, "up": mono(), "tb": (budget_now[::-1] if SWAP_AB else budget_now),
        "rssi": rssi, "ip": ip, "quiet": in_quiet_hours(), "ev": events,
        "ver": VERSION, "werr": web_err[0], "mem": _mem_free(), "pre": pre_cnt, "lr": (lr_on[::-1] if SWAP_AB else lr_on),
        "ch": (None if chime_t is None else dict(chime_info, age=mono() - chime_t)),
    })


def send_all(cl, data):
    mv = memoryview(data)
    i = 0
    while i < len(data):
        n = cl.send(mv[i:i + 1024])
        if not n:
            break
        i += n


web_err = [0]
POST_ONLY = ("/set", "/apply", "/rollback", "/reboot", "/test", "/recal", "/reset")


def web_poll():
    """1回のループで最大1接続だけ処理する（判定を止めないため短時間で返す）"""
    global recal_req, in_count, out_count, reboot_req
    if web_sock is None or ((occA or occB) and not both_long):
        return
    try:
        cl, addr = web_sock.accept()
    except OSError:
        return
    try:
        cl.settimeout(3)
        req = cl.recv(1024)
        if not req:
            return
        line = req.split(b"\r\n", 1)[0].decode()
        parts = line.split(" ")
        path = parts[1] if len(parts) > 1 else "/"
        query = ""
        if "?" in path:
            path, query = path.split("?", 1)
        ctype = "application/json"
        if path in POST_ONLY and not line.startswith("POST"):
            # 設定や再起動など状態を変える操作は POST だけ（ブラウザの先読みや履歴から勝手に動かないように）
            body = json.dumps({"ok": 0, "msg": "この操作は状態ページのボタンから行ってください"})
        elif path == "/s":
            body = status_json()
        elif path == "/trace":
            # 通過ごとの記録。/trace で一覧、/trace?i=0 で1件の中身（16進）
            import ubinascii
            if query.startswith("i="):
                k = int(query[2:])
                if 0 <= k < len(traces):
                    t = traces[k]
                    body = json.dumps({"t": t[0], "res": t[2], "seen": t[3], "ba": t[4], "bb": t[5],
                                       "hex": ubinascii.hexlify(t[1]).decode()})
                else:
                    body = "{}"
            else:
                body = json.dumps([[t[0], t[2], t[3], len(t[1]) // 4] for t in traces])
        elif path == "/cfg":
            body = json.dumps([[k, globals()[CFG[k][0]], CFG[k][4], g] for g, ks in CFG_GROUPS for k in ks if k in CFG])
        elif path == "/setlog":
            body = json.dumps(setlog_read())
        elif path == "/set":
            d = {}
            for kv in query.split("&"):
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    d[k] = v.replace("%2E", ".").replace("%2D", "-")
            changed = cfg_apply(d)
            if changed:
                cfg_save()
                who = addr[0] if addr else "?"
                what = "、".join("%s=%s" % (k, globals()[CFG[k][0]]) for k in changed)
                log_event("設定", "%s（%s から）" % (what, who))
                t = jst()
                setlog_add("%d/%d %02d:%02d %s から %s" % (t[1], t[2], t[3], t[4], who, what))
                if "vol" in changed:
                    send_cmd("CHIME VOL %d T" % CHIME_VOL)
                if "trk" in changed:
                    send_cmd("CHIME TRK %d T" % CHIME_TRK)
                if "wall" in changed:
                    recal_req = True        # 仮の基準を変えたら取り直して反映
            body = json.dumps({"changed": [CFG[k][4] for k in changed],
                               "reboot": any(k in ("budget", "signal", "lr") for k in changed)})
        elif path == "/upload" and line.startswith("POST"):
            try:
                ok, msg = ota_receive(cl, req)
            except Exception as e:
                ok, msg = False, "受信中にエラー: %r（もう一度送ってください）" % (e,)
                try:
                    os.remove("app_new.mpy")
                except OSError:
                    pass
            log_event("更新", msg)
            body = json.dumps({"ok": ok, "msg": msg})
        elif path == "/apply":
            ok = ota_apply()
            body = json.dumps({"ok": ok, "msg": "新しい版で再起動します。25秒ほどで再表示します" if ok else "先にファイルを送ってください"})
            if ok:
                log_event("更新", "新しい版を適用")
                reboot_req = True
        elif path == "/rollback":
            ok = ota_rollback()
            body = json.dumps({"ok": ok, "msg": "前の版に戻して再起動します" if ok else "前の版がありません"})
            if ok:
                reboot_req = True
        elif path == "/reboot":
            reboot_req = True
            body = '{"ok":1}'
        elif path == "/test":
            send_chime("IN")
            log_event("試験", "チャイム試験を送信")
            body = '{"ok":1}'
        elif path == "/recal":
            recal_req = True
            body = '{"ok":1}'
        elif path == "/reset":
            in_count = out_count = 0
            log_event("リセット", "件数を0に")
            body = '{"ok":1}'
        else:
            import gc
            gc.collect()
            mid = (OTA_HTML % (VERSION, ota_info(), APP_NAME)).encode()
            head = ("HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\n"
                    "Content-Length: %d\r\nConnection: close\r\n\r\n" % (len(PAGE_A) + len(mid) + len(PAGE_B))).encode()
            for part in (head, PAGE_A, mid, PAGE_B):
                send_all(cl, part)
            return
        data = body.encode()
        body = None
        head = ("HTTP/1.0 200 OK\r\nContent-Type: %s\r\nCache-Control: no-store\r\n"
                "Content-Length: %d\r\nConnection: close\r\n\r\n" % (ctype, len(data))).encode()
        if len(data) <= 2048:
            send_all(cl, head + data)
        else:
            send_all(cl, head)
            send_all(cl, data)
    except Exception as e:
        if isinstance(e, MemoryError):
            web_err[0] += 1             # 2.14: メモリ不足で返せなかった回数（状態に出す）
    finally:
        try:
            cl.close()
        except Exception:
            pass


# ---------------------------------------------------------------- 起動
wifi_connect()
udp_setup()
web_setup()
hb_setup()
dA = dB = None
occA = occB = False
in_count = out_count = 0
y_in = y_out = 0
baseA, baseB, _blk = calibrate()
last_calib = mono() - (RECALIB_S - 60 if _blk else 0)
last_wifi_check = mono()
last_ntp_try = mono()
today = jst()[2] if clock_ok() else None     # 時刻合わせ前は日付を決めない（合った瞬間の誤った日替りを防ぐ）
log_event("起動", "入店チャイム センサー箱 版%s" % VERSION)
_lr = lr_on[::-1] if SWAP_AB else lr_on
if LONG_RANGE:
    log_event("センサー", "遠距離モード A:%s B:%s（測定時間 A %.1fms / B %.1fms）" % (
        "入" if _lr[0] else "切", "入" if _lr[1] else "切",
        (budget_now[1] if SWAP_AB else budget_now[0]) / 1000, (budget_now[0] if SWAP_AB else budget_now[1]) / 1000))

# ---- 判定ロジック ----
# 「先に遮られた側が空いた瞬間」に、もう一方が後から遮られていれば通過と確定する。
#  ・A→B の順で A が空いた = 入店（チャイム）
#  ・B→A の順で B が空いた = 退店（無音）
#  両方を WINDOW_MS より長く覆っていた（立ち話・ゆっくり通過）→ 空いた順で判定（A→B の順で空けば入店、B→A なら退店）
#  A の前に立ち止まってから入店 → A が空いた時に B が遮られ始めて間もなければ入店
#  早め判定（EARLY_IN）：A が先に遮られていて B が遮られた瞬間に入店。その A・B の遮りは「数え済み」として扱う
t_last_judge = None          # 最後に判定した時刻（不感時間が過ぎたら None。長い休み明けの桁あふれ対策）
startA = startB = None      # 遮られ始めた時刻（遮られていない時は None）
a_done = b_done = False     # 今の A／B の遮りは早め判定で数え済み（同じ通過を二重に数えない）
clearA_t = clearB_t = None  # 立ち話のあとに空いた時刻（空いた順で判定するため）
lastA_off = lastB_off = None  # 判定せずに空いた時刻（A・B が重ならない通過の判定用）
pend_in = pend_out = False    # 2.10: 一瞬の先ぶれのあと A・B 同時に反応した。空いた順で確かめてから判定する
ab_first_diff = ab_last_diff = None  # A・B 同時遮り中の距離差（dA - dB）の最初と最後（同時開始・同時解除の向き判定用）
idle_since = mono()
cal_a, cal_b = [], []        # 2.16: 誰もいない間の最近の測定値（None を含む）。定期の基準計算に使う
pre_t = None                 # 2.15: 先鳴らしした時刻（入店の判定で使い終わるか、空振りで None）
lastB_seen = None            # 2.15: B が最後に反応していた時刻（PRE_QUIET_MS たったら None）
pre_cnt = [0, 0, 0]          # 2.15: 先鳴らし [回数, 入店になった, 空振り]
occ_since = None             # ずっと遮られ始めた時刻（置き物の検出用）
STATIC_S = 120


# 2.7: 同じ人の通過中に「出た→入った」「入った→出た」と逆向きが続けて出るのを防ぐ。
# 前の判定から OPP_LOCK_MS 以内は、そのあと A・B とも OPP_CLEAR_MS 以上空いていなければ逆向きを数えない
OPP_LOCK_MS = 2500
OPP_CLEAR_MS = 400
last_kind = None
last_kind_t = 0
gap_ok = True
clear_since = None


def opp_blocked(kind):
    if last_kind is None or last_kind == kind or gap_ok:
        return False
    if time.ticks_diff(now, last_kind_t) >= OPP_LOCK_MS:
        return False
    return True


def _judged(kind):
    global last_kind, last_kind_t, gap_ok
    last_kind = kind; last_kind_t = now; gap_ok = False


def judged_in(note):
    global in_count, t_last_judge
    if opp_blocked("IN"):
        tr_res.append("(IN 見送り) " + note)
        t_last_judge = now
        return
    global pre_t
    _judged("IN")
    quiet = in_quiet_hours()
    if pre_t is not None:       # 2.15: もう先鳴らししてある → 鳴らさずに数えるだけ
        pre_t = None
        pre_cnt[1] += 1
        note += "（先鳴らし）"
    elif not quiet:
        chime()                 # 先に鳴らしてから記録（少しでも早く）
    in_count += 1; t_last_judge = now
    log_event("IN", note + ("（静音）" if quiet else ""))
    tr_res.append("IN " + note)
    post_event("in")


def judged_out(note):
    global out_count, t_last_judge
    if opp_blocked("OUT"):
        tr_res.append("(OUT 見送り) " + note)
        t_last_judge = now
        return
    _judged("OUT")
    out_count += 1; t_last_judge = now
    log_event("OUT", note)
    tr_res.append("OUT " + note)
    post_event("out")


# ---- 通過ごとの記録（2.5）：A・B のどちらかが遮られてから、両方空いて1秒たつまでの測定値を残す ----
# 1サンプル4バイト：前回からの時間(10ms単位), A(10mm単位,0=測れず), B, 遮り(1=A,2=B)
TRACE_KEEP = 12
TRACE_MAX = 250             # 1回の記録の上限（約12秒分）
traces = []                 # 新しい順 [開始時刻, 記録, 判定, 反応したセンサー, 基準A, 基準B]
tr_buf = None
tr_res = []
tr_prev = 0
tr_clear = None
tr_seen = 0
tr_start = ""


def _enc(d):
    return 0 if d is None else min(255, d // 10)


def trace_step():
    global tr_buf, tr_res, tr_prev, tr_clear, tr_seen, tr_start
    active = occA or occB
    if tr_buf is None:
        if not active:
            tr_res = []
            return
        tr_buf = bytearray(); tr_prev = now; tr_clear = None; tr_seen = 0; tr_start = hhmmss()
        tr_res = tr_res[-2:]    # 遮り始めと同じループで出た判定（早め判定など）
    if len(tr_buf) < TRACE_MAX * 4:
        dt = min(255, max(0, time.ticks_diff(now, tr_prev)) // 10)
        tr_prev = now
        tr_buf.extend(bytes((dt, _enc(dA), _enc(dB), (1 if occA else 0) | (2 if occB else 0))))
    tr_seen |= (1 if occA else 0) | (2 if occB else 0)
    if active:
        tr_clear = None
    elif tr_clear is None:
        tr_clear = now
    elif time.ticks_diff(now, tr_clear) > 1000:
        traces.insert(0, [tr_start, bytes(tr_buf), list(tr_res), tr_seen, baseA, baseB])
        if len(traces) > TRACE_KEEP:
            traces.pop()
        if not tr_res and tr_seen == 3:
            log_event("判定なし", "A・B とも反応したが判定できず（記録あり）")
        tr_buf = None
        tr_res = []


wd_start()
try:
    while True:
        now = time.ticks_ms()
        if led_off_t is not None and time.ticks_diff(now, led_off_t) >= 0:
            led.off()
            led_off_t = None
        mono()
        dA, dB = read_mm(0), read_mm(1)
        occA = dA is not None and dA < thr(baseA, RANGE_A_MM)
        occB = dB is not None and dB < thr(baseB, RANGE_B_MM)
        if t_last_judge is not None and time.ticks_diff(now, t_last_judge) >= REFRACTORY_MS:
            t_last_judge = None
        in_refractory = t_last_judge is not None
        sway_lock = (tr_buf is not None
                     and any(r.startswith("IN") for r in tr_res)
                     and any(r.startswith("OUT") for r in tr_res))

        if occA and occB:
            diff = dA - dB
            if ab_first_diff is None:
                ab_first_diff = diff
            ab_last_diff = diff

        sA, sB = startA, startB
        both_long = (sA is not None and sB is not None
                     and time.ticks_diff(now, sA) > WINDOW_MS
                     and time.ticks_diff(now, sB) > WINDOW_MS)

        # --- A が空いた瞬間 ---
        if not occA and startA is not None and a_done:
            # 早め判定で数え済みの通過。立ち話のあと B→A の順で空いた（店に入らず外へ戻った）ときだけ退店
            if (clearB_t is not None and not in_refractory
                    and time.ticks_diff(now, clearB_t) < WINDOW_MS):
                judged_out("入口で止まったあと外へ")
                clearB_t = None
            startA = None
            a_done = False
        if not occA and startA is not None:
            gap = time.ticks_diff(sB, sA) if sB is not None else -1
            if (not in_refractory and not sway_lock and sB is not None and not b_done
                    and time.ticks_diff(now, sB) < WINDOW_MS
                    and (gap >= SHORT_LEAD_MS
                         or (0 < gap < SHORT_LEAD_MS and occB)            # 2.10: 先行が短いときは B が残っていれば入店
                         or (gap == 0 and occB and (pend_in or time.ticks_diff(now, sA) >= 160)
                             and (not DIFF_JUDGE or ab_last_diff is None or ab_last_diff >= 0)))):
                judged_in(("A→B %dms" % gap) if gap < WINDOW_MS else "立ち止まり後に店内へ")
                if occB:
                    b_done = True
            elif (not in_refractory and not sway_lock and not occB and sB is not None and not b_done
                    and DIFF_JUDGE and gap == 0 and 160 <= time.ticks_diff(now, sB) < WINDOW_MS
                    and ab_first_diff is not None and ab_last_diff is not None
                    and ab_last_diff - ab_first_diff >= 50 and ab_first_diff <= 0 and ab_last_diff >= 30):
                judged_in("A→B 同時")
                b_done = True
            elif both_long:
                clearA_t = now          # 立ち話のあと A が先に空いた → B が続けて空けば入店
            elif (clearB_t is not None and not in_refractory
                    and time.ticks_diff(now, clearB_t) < WINDOW_MS):
                judged_out("立ち話のあと外へ")   # 立ち話のあと B→A の順で空いた → 退店
                clearB_t = None
            if t_last_judge != now and sB is None:
                lastA_off = now
            else:
                lastA_off = None
            startA = None

        # --- B が空いた瞬間 ---
        if not occB and startB is not None and b_done:
            # 早め判定で数え済みの遮り。ここでは退店と数えない（後ろに続く人を退店と取り違えないため）
            if both_long:
                clearB_t = now          # 入口で止まったあと B が先に空いた → A が続けて空けば外へ戻った
            startB = None
            b_done = False
        if not occB and startB is not None:
            gap = time.ticks_diff(sA, sB) if sA is not None else -1
            if (not in_refractory and t_last_judge != now and sA is not None and not a_done
                    and time.ticks_diff(now, sA) < WINDOW_MS
                    and (gap >= SHORT_LEAD_MS
                         or (0 < gap < SHORT_LEAD_MS and occA)            # 2.10: 先行が短いときは A が残っていれば退店
                         or (gap == 0 and occA and (pend_out or time.ticks_diff(now, sB) >= 160)))):
                judged_out("B→A %dms" % gap)
                lastA_off = None
                if occA:
                    a_done = True
            elif (not in_refractory and t_last_judge != now and not occA and sA is not None and not a_done
                    and DIFF_JUDGE and gap == 0 and 160 <= time.ticks_diff(now, sA) < WINDOW_MS
                    and ab_first_diff is not None and ab_last_diff is not None
                    and ab_first_diff - ab_last_diff >= 30 and (ab_first_diff >= 0 or ab_last_diff <= -20)):
                judged_out("B→A 同時")
                lastA_off = None
            elif both_long:
                clearB_t = now
            elif (clearA_t is not None and not occA and not in_refractory and not sway_lock
                    and time.ticks_diff(now, clearA_t) < WINDOW_MS):
                judged_in("立ち話のあと店内へ")    # 立ち話のあと A→B の順で空いた → 入店
                clearA_t = None
            if t_last_judge != now and sA is None:
                lastB_off = now
            else:
                lastB_off = None
            startB = None

        if not (occA and occB):
            ab_first_diff = ab_last_diff = None
        if not occA and not occB:
            pend_in = pend_out = False

        # 空いた順の保留は WINDOW_MS で破棄
        if clearA_t is not None and time.ticks_diff(now, clearA_t) >= WINDOW_MS:
            clearA_t = None
        if clearB_t is not None and time.ticks_diff(now, clearB_t) >= WINDOW_MS:
            clearB_t = None

        # --- A・B が同時に遮られない速い／細い通過（A が空いてから B が遮られた） ---
        # 2.8: A が一瞬先に反応→空いた直後に A・B が同時に反応した場合も「A が先」とみなす（12:09:42 の判定なし）
        if (occB and startB is None and lastA_off is not None
                and (not occA or (startA is None and time.ticks_diff(now, lastA_off) < SIMUL_GAP_MS))):
            if occA:
                pend_in = True          # 2.10: A・B 同時になった。A が先に空いて B が残れば入店
            elif not in_refractory and not sway_lock and time.ticks_diff(now, lastA_off) < GAP_MS:
                judged_in("A→B（すき間 %dms）" % time.ticks_diff(now, lastA_off))
                b_done = True
            lastA_off = None
        if (occA and startA is None and lastB_off is not None
                and (not occB or (startB is None and time.ticks_diff(now, lastB_off) < SIMUL_GAP_MS))):
            if occB:
                pend_out = True         # 2.10: A・B 同時になった。B が先に空いて A が残れば退店
            elif not in_refractory and time.ticks_diff(now, lastB_off) < GAP_MS:
                judged_out("B→A（すき間 %dms）" % time.ticks_diff(now, lastB_off))
                a_done = True
            lastB_off = None
        if lastA_off is not None and time.ticks_diff(now, lastA_off) >= GAP_MS:
            lastA_off = None
        if lastB_off is not None and time.ticks_diff(now, lastB_off) >= GAP_MS:
            lastB_off = None

        # --- 早め判定：A が先に遮られていて、B が遮られた瞬間に入店 ---
        if (EARLY_IN and occB and startB is None and startA is not None and not a_done
                and t_last_judge != now and not in_refractory and not sway_lock
                and time.ticks_diff(now, startA) >= SHORT_LEAD_MS      # 2.10: 先行が短いときは早め判定しない（空いた順で確かめる）
                and time.ticks_diff(now, startA) < WINDOW_MS):
            judged_in("A→B 早め %dms" % time.ticks_diff(now, startA))
            a_done = b_done = True
        elif (EARLY_IN and DIFF_JUDGE and occA and occB and startA is not None and startB is not None
                and not a_done and not b_done and t_last_judge != now and not in_refractory and not sway_lock
                and time.ticks_diff(startB, startA) == 0
                and 150 <= time.ticks_diff(now, startA) < WINDOW_MS
                and ab_first_diff is not None and ab_first_diff <= 0
                and ab_last_diff is not None and ab_last_diff >= 30
                and ab_last_diff - ab_first_diff >= 50):
            judged_in("A→B 早め（同時）%dms" % time.ticks_diff(now, startA))
            a_done = b_done = True

        # --- 逆向き判定の見送り用：A・B とも空いている時間を数える ---
        if occA or occB:
            clear_since = None
        else:
            if clear_since is None:
                clear_since = now
            elif time.ticks_diff(now, clear_since) >= OPP_CLEAR_MS:
                gap_ok = True

        # --- 通過ごとの記録 ---
        trace_step()

        # --- 2.15 先鳴らし：B がしばらく（PRE_QUIET_MS）静かなときに A が遮られ始めた → すぐ鳴らす（数えるのは判定のとき） ---
        #     出ていく人は B が先に反応するので鳴らない
        if occB:
            lastB_seen = now
        elif lastB_seen is not None and time.ticks_diff(now, lastB_seen) >= PRE_QUIET_MS:
            lastB_seen = None
        if (PRE_RING and occA and startA is None and not occB and pre_t is None
                and lastB_seen is None and t_last_judge is None and not in_quiet_hours()):
            chime()
            pre_t = now
            pre_cnt[0] += 1
            tr_res.append("先鳴らし")
        if pre_t is not None and time.ticks_diff(now, pre_t) >= PRE_KEEP_MS:
            pre_t = None
            pre_cnt[2] += 1
            log_event("空振り", "先鳴らししたが入店にならず")

        # --- 遮られ始めを記録 ---
        if occA and startA is None:
            startA = now
            if t_last_judge is not None and time.ticks_diff(now, t_last_judge) < 250:
                a_done = True
        if occB and startB is None:
            startB = now
            if t_last_judge is not None and time.ticks_diff(now, t_last_judge) < 250:
                b_done = True

        # --- 日付が変わったら今日の件数を昨日へ（時刻合わせが済んでから） ---
        if clock_ok():
            d = jst()[2]
            if today is None:
                today = d
            elif d != today:
                today = d
                y_in, y_out = in_count, out_count
                in_count = out_count = 0
                log_event("日替り", "昨日 入%d / 出%d" % (y_in, y_out))

        # --- Wi-Fi 監視（切れていたら30秒おきに再接続。LED は1秒点滅） ---
        if HAS_NET and WIFI_SSID:
            if not wifi_ok():
                led.value((now // 500) % 2)
            if mono() - last_wifi_check > 30:
                last_wifi_check = mono()
                if not wifi_ok():
                    log_event("Wi-Fi", "再接続を試行")
                    if wifi_connect():
                        udp_setup()
                        if web_sock is None:
                            web_setup()
            # 起動時に時刻合わせできなかったら、5分おきにやり直す
            if not clock_ok() and mono() - last_ntp_try > 300 and wifi_ok():
                last_ntp_try = mono()
                try:
                    ntptime.settime()
                    log_event("時刻", "時刻合わせができました")
                except Exception:
                    pass
                wd_feed()

        # --- センサーの通信エラーが続いたら初期化し直す ---
        tof_recover()

        # --- 基準距離の取り直し（定期 or 状態ページから） ---
        if occA or occB:
            idle_since = mono()
            if cal_a:
                del cal_a[:]; del cal_b[:]
            if occ_since is None:
                occ_since = mono()
            elif mono() - occ_since > STATIC_S:
                # 2分以上ずっと遮られている → 人ではなく置き物。その位置を基準にする（判定が止まりっぱなしを防ぐ）
                baseA, baseB, _blk = calibrate((baseA, baseB), accept=True)
                last_calib = mono()
                occ_since = None
        else:
            occ_since = None
            cal_a.append(dA); cal_b.append(dB)
            if len(cal_a) > CALIB_SAMPLES:
                cal_a.pop(0); cal_b.pop(0)
            if recal_req:
                recal_req = False
                baseA, baseB, _blk = calibrate((baseA, baseB))      # 状態ページから頼まれたときだけ、止めて測り直す
                last_calib = mono() - (RECALIB_S - 60 if _blk else 0)
            elif mono() - last_calib > RECALIB_S and mono() - idle_since > 30 and len(cal_a) >= CALIB_SAMPLES:
                # 2.16: 定期の取り直しは、ふだんの測定値から計算する（センサーを見ない時間を作らない）
                baseA, baseB, _blk = base_from([x for x in cal_a if x], [x for x in cal_b if x], len(cal_a), (baseA, baseB))
                last_calib = mono() - (RECALIB_S - 60 if _blk else 0)   # 人がいたら1分後にもう一度

        # --- 状態ページ ---
        web_poll()
        hb_poll()
        wd_feed()
        if reboot_req:
            log_event("再起動", "状態ページから")
            time.sleep_ms(500)
            machine.reset()
        ota_mark_ok(mono())

        time.sleep_ms(SAMPLE_MS)
except KeyboardInterrupt:
    wd_stop()     # Thonny で止めたときは見張りも止める
    raise
